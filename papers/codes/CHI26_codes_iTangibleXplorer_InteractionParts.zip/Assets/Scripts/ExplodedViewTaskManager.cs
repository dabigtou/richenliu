using UnityEngine;
using TMPro; 

public class ExplodedViewTaskManager : MonoBehaviour
{
    [Header("UI References")]
    public TextMeshProUGUI timerText;  
    public TextMeshProUGUI statusText; 

    [Header("Reference Script")]
    public explodedview sourceScript;

    private int currentStep = 1;

    private float timer = 0f;
    private bool isCompleted = false;

    void Start()
    {
        if (sourceScript == null)
        {
            return;
        }
        UpdateStatusUI();
    }

    void Update()
    {
        if (isCompleted || sourceScript == null) return;

        timer += Time.deltaTime;
        if (timerText != null) timerText.text = $"Time: {timer:F2}s";

        float currentDist = Vector3.Distance(
            sourceScript.imagetarget2.transform.position,
            sourceScript.ARcamera.transform.position
        );

        float threshold = sourceScript.distanceThreshold; 

        CheckProgress(currentDist, threshold);
    }

    void CheckProgress(float dist, float threshold)
    {
        switch (currentStep)
        {
            case 1: 
                if (dist <= threshold)
                {
                    currentStep++;
                    Debug.Log("Step 1 Done: Merged");
                    UpdateStatusUI();
                }
                break;

            case 2: 
                if (dist > threshold)
                {
                    CompleteTask();
                }
                break;
        }
    }

    void CompleteTask()
    {
        isCompleted = true;
        currentStep = 3;
        Debug.Log($"Exploded View Task Completed in {timer:F2}s");

        if (statusText != null)
        {
            statusText.text = "Success!";
            statusText.color = Color.green;
        }
    }

    void UpdateStatusUI()
    {
        if (statusText == null) return;
        statusText.color = Color.black; 

        switch (currentStep)
        {
            case 1:
                statusText.text = "Task 1: Move CLOSER";
                break;
            case 2:
                statusText.text = "Task 2: Move AWAY";
                break;
        }
    }
}