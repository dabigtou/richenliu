using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class showup : MonoBehaviour
{
    public GameObject obj;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void show()
    {
        obj.SetActive(true);
    }
    void disappear()
    {
        obj.SetActive(false);
    }
}
