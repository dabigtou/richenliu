﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System;
using System.Runtime.InteropServices;
using System.Collections.Specialized;
using InputTracking = UnityEngine.XR.InputTracking;
using Node = UnityEngine.XR.XRNode;

[RequireComponent(typeof(Camera))]
public class readAndDraw : MonoBehaviour
{
    public Shader renderFrontDepthShader;
    public Shader renderBackDepthShader;
    public Shader rayMarchShader;
    public Shader compositeShader;
    //public Shader volumeShader;
    public Camera _ppCamera = null;
    public LayerMask volumeLayer;

    private Texture3D _volumeBuffer;
    private Texture2D _transfunctionBuffer;
    public Material mat;
    private Material compos;
    public float section, isBall;
    public float xstart, xlength;
    public float ystart, ylength;
    public float ball_x, ball_y, ball_z, ball_r;
    public float ellipsoid_a, ellipsoid_b, ellipsoid_c;
    private const float PI = 3.141592f;
    public static bool isChanged = false;
    public float sensitive = 0.05f;

    void Awake()
    {
        mat = new Material(rayMarchShader);
        compos = new Material(compositeShader);

    }



    float cerp(float y0, float y1, float x)
    {
        return y0 + (y1 - y0) * (-2.0f * x * x * x + 3 * x * x);
    }
    public Color insertValue(Color c0, Color c1, float x0, float x1, float x)
    {
        float alpha = (x - x0) / (x1 - x0);
        Color c = new Color();
        c.r = cerp(c0.r, c1.r, alpha);
        c.g = cerp(c0.g, c1.g, alpha);
        c.b = cerp(c0.b, c1.b, alpha);
        c.a = cerp(c0.a, c1.a, alpha);
        return c;
    }
    // Start is called before the first frame update
    void Start()
    {
        //GameObject.Find("Cube").transform.localScale = new Vector3(1.0f * zoomNum, (float)sz[dataIndex, 1] / sz[dataIndex, 0] * zoomNum, (float)sz[dataIndex, 2] / sz[dataIndex, 0] * zoomNum);
        intensities = new float[sz[dataIndex, 0] * sz[dataIndex, 1] * sz[dataIndex, 2]];
        //lastPos = InputTracking.GetLocalPosition(Node.RightHand);
        //lastAngle = InputTracking.GetLocalRotation(Node.RightHand).eulerAngles;
        /*
        int scWidth = Screen.width;
        int scHeight = Screen.height;

        int designWidth = 800; //这个是设计分辨率
        int designHeight = 600;

        if (!(scWidth <= designWidth || scHeight <= designHeight))
            Screen.SetResolution(designWidth, designHeight, true);*/
        //int width = (int)(Screen.currentResolution.width * 0.5f);
        // int height = (int)(Screen.currentResolution.height * 0.5f);
        //Screen.SetResolution(width, height, true);
        //Color c = insertValue(new Color(0.1f, 0.1f, 0.1f, 0.1f), new Color(1, 1, 1, 1), 0.1f, 0.7f, 0.5f);
        //Debug.Log("测试：" + c.r.ToString() + c.g.ToString() + c.b.ToString() + c.a.ToString());
        //binLoadVolumeData();//10.29
        volumeTex();
        //Vector3 v1 = new Vector3(0.5f, 0, 0.5f);

        //Vector3 v2 = Quaternion.FromToRotation(Vector3.forward, v1).eulerAngles;

        //Debug.Log("欧拉角测试："+ v2);

    }
    private void OnDestroy()
    {
        if (_volumeBuffer != null)
        {
            Destroy(_volumeBuffer);
        }
    }
    private int m_count = 0;
    /*
    public Shader temp;
    public Material lineMaterial;
    void CreateLineMaterial()
    {
        lineMaterial = new Material(temp);
        lineMaterial.hideFlags = HideFlags.HideAndDontSave;
        lineMaterial.shader.hideFlags = HideFlags.HideAndDontSave;
        lineMaterial.SetPass(0);
    }
    
    void OnPostRender()
    {
        Vector3 v1 = GameObject.Find("IntroText").transform.position;
        Vector3 v2 = GameObject.Find("Cube").transform.position;
        Vector3 v3 = Camera.main.WorldToScreenPoint(v1);
        Vector3 v4 = Camera.main.WorldToScreenPoint(v2);
        Debug.Log(v3 + ":" + v4);
        GL.PushMatrix();
        CreateLineMaterial();
        GL.LoadOrtho();
        GL.Begin(GL.LINES);
        GL.Color(Color.black);
        GL.Vertex(new Vector2(v3.x/ Screen.width,v3.y/ Screen.height));
        GL.Vertex(new Vector2(v4.x / Screen.width, v4.y / Screen.height));
        GL.End();
        GL.PopMatrix();
    }*/
    Vector3 lastPos, currPos;
    Vector3 lastAngle, currAngle;
    float cccount = 0.01f;
    float deltaStart = 0.01f;
    float deltaStartDepth = 0.02f;
    public string[] annotations = new string[2]{
        "z:0.46-0.60:The five \nhand bones in the palm \nprotect other tissues \nz:0.67-0.77:The distribution \nof the two aorta \nis very clear",//POI：血管主要分布在此深度切片内，
        "z:0-0.01: 0.7-0.8: the left and right ears are distributed on both sides of the headz: 0.3-0.5: The nasal cavity, upper and lower jaw, throat, and skull are distributed in this section."//
    };

    void LateUpdate()
    {
        /*
        //GameObject.Find("Cube").transform.localScale = new Vector3(1.0f * zoomNum, 1.0f * zoomNum, 1.0f * zoomNum);
        if (section == -1)
        {
            Slicing();
        }
        else
        {
            if (OVRInput.GetDown(OVRInput.Button.One))
            {
                readAndDraw.zoomNum +=0.1f;
            }
            if (OVRInput.GetDown(OVRInput.Button.Two))
            {
                readAndDraw.zoomNum -=0.1f;
            }
            
        }
        */

    }

   /*public void Slicing()
    {
        tm.text = "Move the handle in and out \nto adjust the position of \nthe depth slicing.\nMove the handle left and right \nto adjust the position of \nthe vertical slicing" + "\n\n\n\n\n\n\n\nDepth Slicing Range\nStart:" + xstart + "\nThickness:" + xlength + "\nVertical Slicing Range\nStart" + ystart + "\nThickness:" + ylength;
        //
        //tm1.text = "Annotations:\n"+ "z:0.46-0.60:The five \nhand bones in the palm \nprotect other tissues. \nz:0.67-0.77:The distribution \nof the two aorta is very clear.";
        //tm1.text = "Annotations:\n" + "z:0-0.01: \nz:0.7-0.8: The left and right\n ears are distributed \non both sides of the head.\nz: 0.3-0.5: The nasal cavity,\n upper and lower jaw, \nthroat, and skull are\ndistributed in this slicing." ;
        tm1.text = "Annotations:\n" + "z:0.2-0.6: The distribution \nof the trachea and the structure\nof the lobes of the lung.\nz: 0.6-0.75: The distribution \nof lesions on the surface\nof the lung.";

        currPos = InputTracking.GetLocalPosition(Node.RightHand);
        if (currPos != lastPos)
        {
            if (currPos.z < lastPos.z - cccount)
            {
                ystart = System.Math.Min(1 - ylength, ystart + deltaStartDepth);
                lastPos = currPos;
            }
            else if (currPos.z > lastPos.z + cccount)
            {
                ystart = System.Math.Max(0, ystart - deltaStartDepth);
                lastPos = currPos;
            }
            if (currPos.x > lastPos.x + cccount)
            {
                xstart = System.Math.Min(1 - xlength, xstart + deltaStart);
                lastPos = currPos;
            }
            else if (currPos.x < lastPos.x - cccount)
            {
                xstart = System.Math.Max(0, xstart - deltaStart);
                lastPos = currPos;
            }
        }
        if (OVRInput.GetDown(OVRInput.Button.One))
        {
            xlength = System.Math.Max(0.01f, xlength - 0.005f);
            ylength = System.Math.Max(0.1f, ylength - 0.005f);
        }
        if (OVRInput.GetDown(OVRInput.Button.Two))
        {
            xlength = System.Math.Min(1, xlength + 0.005f);
            ylength = System.Math.Min(0.5f, ylength + 0.005f);
        }


    }*/
    int updateTime = 0;
    /// <summary>
    /// 只能挂在相机上，每帧渲染时调用
    /// </summary>
    /// <param name="source"></param>
    /// <param name="destination"></param>
    int QQCount = 0;
    public TextMesh tm1;
    public TextMesh tm;
    private void OnRenderImage(
        RenderTexture source,
        RenderTexture destination)
    {


        if (m_count % 10 == 0)
        {

            m_count %= 10;
            if (isChanged)
            {
                updateTime++;
                //LoadTFByTFEditor();
                LoadNonlinearTFByTFEditor();
                //binLoadVolumeData();10.29
                volumeTex();
                //LoadTf();
                //Read();
                transfunctionTex();
                if (updateTime >= 2)
                {
                    isChanged = false;
                    Cases.ready = true;
                    updateTime = 0;
                }
            }
            //mat.SetTexture("texVolume", _volumeBuffer);//设置3D纹理贴图
            mat.SetFloat("section", section);
            mat.SetFloat("isBall", isBall);
            mat.SetFloat("xstart", xstart);
            mat.SetFloat("xlength", xlength);
            mat.SetFloat("ystart", ystart);
            mat.SetFloat("ylength", ylength);
            mat.SetFloat("ball_x", ball_x);
            mat.SetFloat("ball_y", ball_y);
            mat.SetFloat("ball_z", ball_z);
            mat.SetFloat("ball_r", ball_r);
            mat.SetFloat("ellipsoid_a", ellipsoid_a);
            mat.SetFloat("ellipsoid_b", ellipsoid_b);
            mat.SetFloat("ellipsoid_c", ellipsoid_c);

            if (_ppCamera == null)
            {
                var go = new GameObject("PPCamera");
                _ppCamera = go.AddComponent<Camera>();
                _ppCamera.enabled = false;

                RotationTracker tracker = FindObjectOfType<RotationTracker>();
                if (tracker != null)
                {
                    tracker.SetTrackingTarget(go.transform);
                    Debug.Log("已成功将生成的 PPCamera 连接到旋转追踪器");
                }
                else
                {
                    Debug.LogWarning("未找到 RotationTracker 脚本，请检查场景！");
                }
            }

            _ppCamera.CopyFrom(GetComponent<Camera>());//模拟一个眼睛
            _ppCamera.clearFlags = CameraClearFlags.SolidColor;
            _ppCamera.backgroundColor = Color.white;
            _ppCamera.depthTextureMode |= DepthTextureMode.Depth;


            RenderTexture frontDepth = RenderTexture.GetTemporary(
                source.width,
                source.height,
                0,
                RenderTextureFormat.ARGBFloat
                );
            RenderTexture backDepth = RenderTexture.GetTemporary(
                source.width,
                source.height,
                0,
                RenderTextureFormat.ARGBFloat
                );
            RenderTexture volumeTarget = RenderTexture.GetTemporary(
                source.width,
                source.height,
                0
                );

            // Render depths
            _ppCamera.targetTexture = frontDepth;
            _ppCamera.RenderWithShader(renderFrontDepthShader, "RenderType");
            _ppCamera.targetTexture = backDepth;
            _ppCamera.RenderWithShader(renderBackDepthShader, "RenderType");

            mat.SetTexture("_FrontTex", frontDepth);
            mat.SetTexture("_BackTex", backDepth);//将正反向渲染的深度图传入到Ray Marching Shader中
                                                  //Graphics.Blit(source, destination, mat);//屏幕特效

            Graphics.Blit(null, volumeTarget, mat);
            compos.SetTexture("_BlendTex", volumeTarget);
            Graphics.Blit(source, destination, compos);


            RenderTexture.ReleaseTemporary(volumeTarget);
            RenderTexture.ReleaseTemporary(frontDepth);
            RenderTexture.ReleaseTemporary(backDepth);
        }
        m_count++;
    }
    public static float zoomNum = 2;
    /// <summary>
    /// 每次更新时运行
    /// </summary>
    void Update()
    {

    }
    /// <summary>
    /// 颜色插值
    /// </summary>
    /// <param name="C1"></param>
    /// <param name="C2"></param>
    /// <returns></returns>
    Color Blend(Color C1, Color C2)
    {
        Color rtn = new Color();
        float cs = C1.a, cd = C2.a;
        rtn.r = (1.0f - cd) * C1.r + cd * C2.r;
        rtn.g = (1.0f - cd) * C1.g + cd * C2.g;
        rtn.b = (1.0f - cd) * C1.b + cd * C2.b;
        rtn.a = System.Math.Max(cs, cd);
        return rtn;
    }
    /// <summary>
    /// 计算高斯函数
    /// </summary>
    /// <param name="miu"></param>
    /// <param name="sigma"></param>
    /// <param name="x"></param>
    /// <returns></returns>
    float Gauss(float miu, float sigma, float x)
    {
        //exp(-pow((x-miu)/sigma, 2.f) /2.f);
        //return (1.0f / (sigma * (float)System.Math.Sqrt(2 * PI))) * (float)System.Math.Exp(-System.Math.Pow((x - miu) / sigma, 2.0f) / 2.0f);
        return (float)System.Math.Exp(-(float)System.Math.Pow((x - miu) / sigma, 2.0f) / 2.0f);
    }
    /// <summary>
    /// 传递函数点结构体
    /// </summary>
    struct CGaussTransferFuncNode
    {
        public float intensity;
        public float variance;
        public float r, g, b, a;
    }
    int[] starts = { 0, 0, 0 };
    /// <summary>
    /// 各个数据的规格
    /// </summary>
    static int[,] sz = new int[3, 3]{
        {244, 124, 257},//HAND
        {256, 256, 256},//HEAD
        {192, 192, 120}, //CHEST
    };
    string[] dataName = new string[3] { "hand", "head", "chest" };
    public static int dataIndex =0;//***
    //head2.bytes
    //static int[] sz = { 256, 256, 225 };
    //hand.bytes
    //static int[] sz = { 244, 124, 257 };
    //seismic2 oil2
    //static int[] sz = { 421, 401, 90 };
    //sample3 chest
    //static int[] sz = { 192, 192, 120 };
    static int m_resolution = 256;
    public static Color[] texTransFunction = new Color[m_resolution];
    float[] intensities;
    /// <summary>
    /// 通过调用TF_Editor类的静态变量points来更新传递函数
    /// </summary>

    void LoadNonlinearTFByTFEditor()
    {
        List<int> indexs = new List<int>();
        List<cPoint> temp = TF_Editor.points;
        for (int i = 0; i < temp.Count; i++)
        {
            //float intensity = (temp[i].m_fx - TF_Editor.f_x) / TF_Editor.f_w;
            float intensity = temp[i].m_fx / TF_Editor.f_w;
            //float alpha = (temp[i].m_fy - TF_Editor.f_y) / TF_Editor.f_h;
            float alpha = temp[i].m_fy;
            texTransFunction[(int)(intensity * 255)] = new Color(
                temp[i].m_color.r,
                temp[i].m_color.g,
                temp[i].m_color.b,
                alpha
                );
            indexs.Add((int)(intensity * 255));
        }
        if (indexs.Count != 0)
        {
            if (indexs[0] != 0)
            {
                indexs.Insert(0, 0);
            }
            if (indexs[indexs.Count - 1] != 255)
            {
                indexs.Add(255);
            }
        }

        for (int i = 0; i < indexs.Count - 1; i++)
        {
            for (int j = indexs[i] + 1; j < indexs[i + 1]; j++)
            {
                texTransFunction[j] = insertValue(texTransFunction[indexs[i]], texTransFunction[indexs[i + 1]], indexs[i] / 255.0f, indexs[i + 1] / 255.0f, j / 255.0f);
            }
        }
        Debug.Log("传递函数插值完成！");
    }
    /// <summary>
    /// 从二进制文件中读取体数据
    /// </summary>
    void binLoadVolumeData()
    {
        intensities = new float[sz[dataIndex, 0] * sz[dataIndex, 1] * sz[dataIndex, 2]];
        TextAsset binAsset = Resources.Load(dataName[dataIndex]) as TextAsset;
        byte[] bs = binAsset.bytes;
        int nRet = bs.Length;
        ushort[] imageData = new ushort[nRet];
        for (int i = 0; i < nRet; i++)
        {
            imageData[i] = bs[i];
        }
        int index = 0;
        Debug.Log("OVER!!!");
        Debug.Log(nRet.ToString());
        for (int i = 0; i < sz[dataIndex, 0] * sz[dataIndex, 1] * sz[dataIndex, 2]; i++)
        {
            intensities[i] = imageData[i];
            //intensities[i] = imageData[i * 2];
            //intensities[i] = imageData[i * 4 + 2];//oil2
        }


    }
    /*void volumeTex()
    {
        _volumeBuffer = new Texture3D(sz[dataIndex, 0], sz[dataIndex, 1], sz[dataIndex, 2], TextureFormat.ARGB32, false);
        var pixels = new Color[sz[dataIndex, 0] * sz[dataIndex, 1] * sz[dataIndex, 2]];
        int index = 0;
        for (int x = 0; x < sz[dataIndex, 0]; x++)
        {
            for (int y = 0; y < sz[dataIndex, 1]; y++)
            {
                for (int z = 0; z < sz[dataIndex, 2]; z++)
                {
                    pixels[x * sz[dataIndex, 1] * sz[dataIndex, 2] + y * sz[dataIndex, 2] + z] = new Color(0,0,0, intensities[index]/255);
                    index++;
                }
            }
        }
        _volumeBuffer.SetPixels(pixels);
        _volumeBuffer.Apply();
        mat.SetTexture("texVolume", _volumeBuffer);
    }*/

    /*void volumeTex()
    {
        _volumeBuffer = new Texture3D(sz[dataIndex, 0], sz[dataIndex, 1], sz[dataIndex, 2], TextureFormat.ARGB32, false);
        var pixels = new Color[sz[dataIndex, 0] * sz[dataIndex, 1] * sz[dataIndex, 2]];
        int index = 0;
        float citg, citr, citb, cita;
        string line;
        StreamReader sr = new StreamReader("Test.txt");
        for (int x = 0; x < sz[dataIndex, 0]; x++)
        {
            for (int y = 0; y < sz[dataIndex, 1]; y++)
            {
                for (int z = 0; z < sz[dataIndex, 2]; z++)
                {
                    line = sr.ReadLine();
                    //int index1=line.IndexOf(' '),index2,index3;
                    if (line != null)
                    {
                        string[] strs;
                        strs = line.Split(' ');
                        citr = float.Parse(strs[0]); citg = float.Parse(strs[1]);
                        citb = float.Parse(strs[2]); cita = float.Parse(strs[3]);

                        // if(line=="")
                         //citg = Convert.ToDouble(line.Substring(3,5));
                         
                    }
                    else
                    {
                        citg = 0; citr = 0; citb = 0; cita = 0;
                    }
                    pixels[x * sz[dataIndex, 1] * sz[dataIndex, 2] + y * sz[dataIndex, 2] + z] = new Color(citr, citg, citb, cita);
                    index++;
                }
            }
        }
        _volumeBuffer.SetPixels(pixels);
        _volumeBuffer.Apply();
        mat.SetTexture("texVolume", _volumeBuffer);
    }*/
    /*void volumeTex()
    {
        _volumeBuffer = new Texture3D(sz[dataIndex, 0], sz[dataIndex, 1], sz[dataIndex, 2], TextureFormat.ARGB32, false);
        var pixels = new Color[sz[dataIndex, 0] * sz[dataIndex, 1] * sz[dataIndex, 2]];

        int index = 0, k1 = 0, k2 = 0;
        float citg, citr, citb, cita;
        //string line;
        //StreamReader sr = new StreamReader("Test.txt");
        TextAsset cit1 = Resources.Load("Test1") as TextAsset;
        TextAsset cit2 = Resources.Load("Test2") as TextAsset;
        TextAsset cit3 = Resources.Load("Test3") as TextAsset;
        TextAsset cit4 = Resources.Load("Test4") as TextAsset;
        string als1 = cit1.text + cit2.text + cit3.text + cit4.text;
        string[] lines1 = als1.Split('\n');




        for (int x = 0; x < sz[dataIndex, 0]; x++)
        {
            for (int y = 0; y < sz[dataIndex, 1]; y++)
            {
                for (int z = 0; z < sz[dataIndex, 2]; z++)
                {
                    //line = sr.ReadLine();
                    //int index1=line.IndexOf(' '),index2,index3;

                    string[] strs1;
                    strs1 = lines1[k1++].Split(' ');
                    citr = float.Parse(strs1[0]); citg = float.Parse(strs1[1]);
                    citb = float.Parse(strs1[2]); cita = float.Parse(strs1[3]);

                    pixels[x * sz[dataIndex, 1] * sz[dataIndex, 2] + y * sz[dataIndex, 2] + z] = new Color(citr, citg, citb, cita);

                    index++;
                }
            }
        }





        tm.text = "读取结束!";
        _volumeBuffer.SetPixels(pixels);
        _volumeBuffer.Apply();
        mat.SetTexture("texVolume", _volumeBuffer);
    }*/

    /*void volumeTex()
    {
        _volumeBuffer = new Texture3D(sz[dataIndex, 0], sz[dataIndex, 1], sz[dataIndex, 2], TextureFormat.ARGB32, false);
        var pixels = new Color[sz[dataIndex, 0] * sz[dataIndex, 1] * sz[dataIndex, 2]];

        int index = 0, k1 = 0,k2=0,k3=0,k4=0;
        float citg, citr, citb, cita;
        //string line;
        //StreamReader sr = new StreamReader("Test.txt");
        TextAsset cit1 = Resources.Load("Test1") as TextAsset;
        string als1 = cit1.text;
        string[] lines1 = als1.Split('\n');

        for (int x = 0; x < sz[dataIndex, 0]/4; x++)
        {
            for (int y = 0; y < sz[dataIndex, 1]; y++)
            {
                for (int z = 0; z < sz[dataIndex, 2]; z++)
                {
                    //line = sr.ReadLine();
                    //int index1=line.IndexOf(' '),index2,index3;

                    string[] strs1;
                    strs1 = lines1[k1++].Split(' ');
                    citr = float.Parse(strs1[0]); citg = float.Parse(strs1[1]);
                    citb = float.Parse(strs1[2]); cita = float.Parse(strs1[3]);

                    pixels[x * sz[dataIndex, 1] * sz[dataIndex, 2] + y * sz[dataIndex, 2] + z] = new Color(citr, citg, citb, cita);

                    index++;
                }
            }
        }

        TextAsset cit2 = Resources.Load("Test2") as TextAsset;
        string als2 = cit2.text;
        string[] lines2 = als2.Split('\n');

        for (int x = sz[dataIndex, 0]/4; x < sz[dataIndex, 0]/2; x++)
        {
            for (int y = 0; y < sz[dataIndex, 1]; y++)
            {
                for (int z = 0; z < sz[dataIndex, 2]; z++)
                {
                    //line = sr.ReadLine();
                    //int index1=line.IndexOf(' '),index2,index3;

                    string[] strs2;
                    strs2 = lines2[k2++].Split(' ');
                    citr = float.Parse(strs2[0]); citg = float.Parse(strs2[1]);
                    citb = float.Parse(strs2[2]); cita = float.Parse(strs2[3]);

                    pixels[x * sz[dataIndex, 1] * sz[dataIndex, 2] + y * sz[dataIndex, 2] + z] = new Color(citr, citg, citb, cita);

                    index++;
                }
            }
        }


        TextAsset cit3 = Resources.Load("Test3") as TextAsset;
        string als3 = cit3.text;
        string[] lines3 = als3.Split('\n');

        for (int x = sz[dataIndex, 0]/2; x < sz[dataIndex, 0]*3 / 4; x++)
        {
            for (int y = 0; y < sz[dataIndex, 1]; y++)
            {
                for (int z = 0; z < sz[dataIndex, 2]; z++)
                {
                    //line = sr.ReadLine();
                    //int index1=line.IndexOf(' '),index2,index3;

                    string[] strs3;
                    strs3 = lines3[k3++].Split(' ');
                    citr = float.Parse(strs3[0]); citg = float.Parse(strs3[1]);
                    citb = float.Parse(strs3[2]); cita = float.Parse(strs3[3]);

                    pixels[x * sz[dataIndex, 1] * sz[dataIndex, 2] + y * sz[dataIndex, 2] + z] = new Color(citr, citg, citb, cita);

                    index++;
                }
            }
        }

        TextAsset cit4 = Resources.Load("Test4") as TextAsset;
        string als4 = cit4.text;
        string[] lines4 = als4.Split('\n');

        for (int x = sz[dataIndex, 0]*3/4; x < sz[dataIndex, 0]; x++)
        {
            for (int y = 0; y < sz[dataIndex, 1]; y++)
            {
                for (int z = 0; z < sz[dataIndex, 2]; z++)
                {
                    //line = sr.ReadLine();
                    //int index1=line.IndexOf(' '),index2,index3;

                    string[] strs4;
                    strs4 = lines4[k4++].Split(' ');
                    citr = float.Parse(strs4[0]); citg = float.Parse(strs4[1]);
                    citb = float.Parse(strs4[2]); cita = float.Parse(strs4[3]);

                    pixels[x * sz[dataIndex, 1] * sz[dataIndex, 2] + y * sz[dataIndex, 2] + z] = new Color(citr, citg, citb, cita);

                    index++;
                }
            }
        }


        tm.text = "读取结束!";
        _volumeBuffer.SetPixels(pixels);
        _volumeBuffer.Apply();
        mat.SetTexture("texVolume", _volumeBuffer);
    }*/

    void volumeTex()
    {
        _volumeBuffer = new Texture3D(sz[dataIndex, 0], sz[dataIndex, 1], sz[dataIndex, 2], TextureFormat.ARGB32, false);
        var pixels = new Color[sz[dataIndex, 0] * sz[dataIndex, 1] * sz[dataIndex, 2]];
        int index = 0, k = 0;
        float citg, citr, citb, cita;
        //string line;
      //  StreamReader sr = new StreamReader("Test.txt");
     TextAsset cit = Resources.Load("HTest") as TextAsset;
      string als = cit.text;
       //TextAsset cit1 = Resources.Load("Test11") as TextAsset;
     //  TextAsset cit2 = Resources.Load("Test12") as TextAsset;
      // TextAsset cit3 = Resources.Load("Test13") as TextAsset;
     //   TextAsset cit4 = Resources.Load("Test4") as TextAsset;

       // string als = cit1.text + cit2.text + cit3.text + cit4.text;
        string[] lines = als.Split(new string[] { "\n" }, StringSplitOptions.None);
        int num = lines.GetLength(0);
        for (int x = 0; x < sz[dataIndex, 0]; x++)
        {
            for (int y = 0; y < sz[dataIndex, 1]; y++)
            {
                for (int z = 0; z < sz[dataIndex, 2]; z++)
                {
                    //line = sr.ReadLine();
                    //int index1=line.IndexOf(' '),index2,index3;
                    if (k < num)
                    {
                        string[] strs;
                        strs = lines[k++].Split(' ');
                        citr = float.Parse(strs[0]); citg = float.Parse(strs[1]);
                        citb = float.Parse(strs[2]); cita = float.Parse(strs[3]);
                    }
                    else
                    {
                        citg = 0; citr = 0; citb = 0; cita = 0;
                    }
                    pixels[x * sz[dataIndex, 1] * sz[dataIndex, 2] + y * sz[dataIndex, 2] + z] = new Color(citr, citg, citb, cita);
                    index++;
                }
            }
        }
        _volumeBuffer.SetPixels(pixels);
        _volumeBuffer.Apply();
        mat.SetTexture("texVolume", _volumeBuffer);
    }




    void transfunctionTex()
    {
        _transfunctionBuffer = new Texture2D(1, 256, TextureFormat.ARGB32, false);
        var pixels = new Color[1 * 256];
        for (int i = 0; i < 256; i++)
        {
            pixels[i] = texTransFunction[i];
        }
        _transfunctionBuffer.SetPixels(pixels);
        _transfunctionBuffer.Apply();
        mat.SetTexture("_texTransfunction", _transfunctionBuffer);
    }
    /// <summary>
    /// 将体数据与传递函数合并
    /// </summary>
    void Read()
    {
        _volumeBuffer = new Texture3D(sz[dataIndex, 0], sz[dataIndex, 1], sz[dataIndex, 2], TextureFormat.ARGB32, false);
        int index = 0;
        //根据intensity找对应点的rgba
        var pixels = new Color[sz[dataIndex, 0] * sz[dataIndex, 1] * sz[dataIndex, 2]];
        index = 0;
        for (int x = 0; x < sz[dataIndex, 0]; x++)
        {
            for (int y = 0; y < sz[dataIndex, 1]; y++)
            {
                for (int z = 0; z < sz[dataIndex, 2]; z++)
                {
                    pixels[index] = texTransFunction[(int)intensities[index]];
                    index++;
                }
            }
        }
        //将每个像素点的颜色放到纹理中去
        _volumeBuffer.SetPixels(pixels);
        _volumeBuffer.Apply();
        //绑定纹理
        //mat.SetTexture("texVolume", _volumeBuffer);
    }


}
public class transFunction
{
    float cerp(float y0, float y1, float x)
    {
        return y0 + (y1 - y0) * (-2.0f * x * x * x + 3 * x * x);
    }
    Color cerp(Color c0, Color c1, float alpha)
    {
        Color c = new Color();
        c.r = cerp(c0.r, c1.r, alpha);
        c.g = cerp(c0.g, c1.g, alpha);
        c.b = cerp(c0.b, c1.b, alpha);
        c.a = cerp(c0.a, c1.a, alpha);
        return c;
    }
    Color cerp(Color c0, Color c1, float x0, float x1, float x)
    {
        float alpha = (x - x0) / (x1 - x0);
        return cerp(c0, c1, alpha);
    }
    public Color insertValue(Color c0, Color c1, float x0, float x1, float x)
    {
        return cerp(c0, c1, x0, x1, x);
    }
}