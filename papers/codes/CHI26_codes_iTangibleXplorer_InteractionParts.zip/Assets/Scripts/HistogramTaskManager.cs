using UnityEngine;
using TMPro; 

public class HistogramTaskManager : MonoBehaviour
{
    [Header("UI References")]
    public TextMeshProUGUI timerText;   
    public TextMeshProUGUI statusText;  

    [Header("Target Objects to Monitor")]
    public GameObject target_Vessel; 
    public GameObject target_Bone;  
    public GameObject target_Skin;  

    private int currentStep = 1;

    private float timer = 0f;
    private bool isCompleted = false;

    void Start()
    {
        UpdateStatusUI();
    }

    void Update()
    {
        if (isCompleted) return;

        timer += Time.deltaTime;
        if (timerText != null) timerText.text = $"Time: {timer:F2}s";

        CheckProgress();
    }

    void CheckProgress()
    {
        switch (currentStep)
        {
            case 1: 
                if (target_Skin.activeSelf)
                {
                    currentStep++;
                    Debug.Log("Step 1 Done: BT21 ON");
                    UpdateStatusUI();
                }
                break;

            case 2: 
                if (!target_Skin.activeSelf)
                {
                    currentStep++;
                    Debug.Log("Step 2 Done: BT21 OFF");
                    UpdateStatusUI();
                }
                break;

            case 3: 
                if (target_Vessel.activeSelf)
                {
                    currentStep++;
                    Debug.Log("Step 3 Done: BT19 ON");
                    UpdateStatusUI();
                }
                break;

            case 4: 
                if (!target_Vessel.activeSelf)
                {
                    currentStep++;
                    Debug.Log("Step 4 Done: BT19 OFF");
                    UpdateStatusUI();
                }
                break;

            case 5: 
                if (target_Bone.activeSelf)
                {
                    currentStep++;
                    Debug.Log("Step 5 Done: BT20 ON");
                    UpdateStatusUI();
                }
                break;

            case 6: 
                if (!target_Bone.activeSelf)
                {
                    CompleteTask();
                }
                break;
        }
    }

    void CompleteTask()
    {
        isCompleted = true;
        currentStep = 7;
        Debug.Log($"All Histogram Tasks Completed in {timer:F2}s");

        if (statusText != null)
        {
            statusText.text = "Success!";
            statusText.color = Color.green;
        }
    }

    void UpdateStatusUI()
    {
        if (statusText == null) return;
        statusText.color = Color.black;

        switch (currentStep)
        {
            case 1:
                statusText.text = "Task 1: Turn ON BT(Skin)";
                break;
            case 2:
                statusText.text = "Task 1: Turn OFF BT(Skin)";
                break;
            case 3:
                statusText.text = "Task 2: Turn ON BT(Vessel)";
                break;
            case 4:
                statusText.text = "Task 2: Turn OFF BT(Vessel)";
                break;
            case 5:
                statusText.text = "Task 3: Turn ON BT(Bone)";
                break;
            case 6:
                statusText.text = "Task 3: Turn OFF BT(Bone)";
                break;
        }
    }
}