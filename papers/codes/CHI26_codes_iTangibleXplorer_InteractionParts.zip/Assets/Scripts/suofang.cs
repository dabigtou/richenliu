﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using UnityEngine;

public class suofang : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }
    
    /*//CHEST-LUNG
    float[] x = new float[4] { -92, -90, -80, 0 };
    float[] y = new float[4] { -33, 0, 33, 0 };
    float[] z = new float[4] { 0, 0, 11, 0 };
    string[] Continent = new string[4] { "Left lung", "Front view", "Right lung", "Bottom view"};
    string[] description = new string[4] {
        "The gray-blue part represents\nlung lesions, which are\ncurrently distributed on \nthe surface of the lung.",
        "From the front view of the \nlung, you can compare the \nlesions on both sides of \nthe lungand observe the \nscattered areas of the lesions.",
        "The gray-blue part indicates \nlung lesions, and the yellow \npart indicates lung structure.",
        "From the bottom perspective, \nthe internal structure of the \nlungs is very clear, and the \ntrachea and other parts \ncan be clearly found."
    };
    
     */
    /*//HAND
    float[] x = new float[5] { -143, -90, -90, -90 ,-40};
    float[] y = new float[5] { 0, 0, -70, 70 ,0};
    float[] z = new float[5] { 0, 0, 0, 0 ,0};
    string[] Continent = new string[5] { "Top view", "Front view", "Left view", "Right view", "Bottom view" };
    string[] description = new string[5] {
        "From the top perspective,\n we can see that \nthe hand bones are surroun-\nded by blood vessels \nand the simple struct-\nures inside the bones.",
        "From the front view, we \ncan see the bone dis-\ntribution and the main \nblood vessels in the palm.",
        "From the left and right \nviews, we can clearly\n see the layering of skin,\n blood vessels, and bones.",
        "From the left and right \nviews, we can clearly\n see the layering of skin,\n blood vessels, and bones.",
        "The hand data is divided\ninto three layers:\nskin layer (light green),\nbone layer (light yellow)\nblood vessel layer (red)."
    };*/
    //HEAD
    float[] x = new float[2] { 90, 90 };
    float[] y = new float[2] { -90, 90 };
    float[] z = new float[2] { 0, 0};
    string[] Continent = new string[2] {"Left view", "Right view" };
    string[] description = new string[2] {
        "From the left and right \nperspectives of the \nhead data, we can clearly\n see the structure of \nthe nasal cavity, \nupper jaw and throat.",
        "From the left and right \nperspectives of the \nhead data, we can clearly\n see the structure of \nthe nasal cavity, \nupper jaw and throat."
    };
    private float delta = 0;
    private int sumTime = 0;
    private bool backFlag = false;
    private int m_count = 1;
    public float sensitive = 0.03f;
    int count = 0;
    List<Vector3> records = new List<Vector3>();
    // Update is called once per frame
    public TextMesh tm;
    public TextMesh tm1;
    private int Count = 0, offset = 0, zoom = 0;
    bool autoFlag = false;
    int len = 200;
    bool test = true;
    int modeFlag = -1;
    int POICount = 2;
    int QQCount = 0;

    public static float f_Fps;
    public float f_UpdateInterval = 0.5f; //每个0.5秒刷新一次
    private float f_LastInterval; //游戏时间
    private int i_Frames = 0;
    void FPS()
    {
        ++i_Frames;

        if (Time.realtimeSinceStartup > f_LastInterval + f_UpdateInterval)
        {
            f_Fps = i_Frames / (Time.realtimeSinceStartup - f_LastInterval);

            i_Frames = 0;

            f_LastInterval = Time.realtimeSinceStartup;
        }
        tm.text = f_Fps.ToString("f2");
    }
    /*void Interactive()
    {
        //tm1.text = "Quadric query\nExploring POI:Left Lung\nWhen the data is rotated,\nwe can clearly see \nthe lung lesions and\n internal structures.";
        if (modeFlag == 0)
        {
            
            if (OVRInput.GetDown(OVRInput.Button.One))
            {
                tm.text = "";
                modeFlag = 1;
                Count = 0;
                Locate(0, 0, 0);
                offset = 0;
                tm.text = "press 'RightHandTrigger' to restart";
            }
            if (OVRInput.GetDown(OVRInput.Button.Two))
            {
                tm.text = "shake 'Thumbstick' to find POI(Point-of-Interest)\npress 'A' to save the POI\npress 'RightIndexTrigger' to explore automatically\npress 'RightHandTrigger' to restart";
                modeFlag = 2;
                offset = 0;
                Count = 0;
                //records.Clear();
                Locate(0, 0, 0);
            }
            return;
            
        }
        if (modeFlag==1)
        {
            if (Count <= len)
            {
                Locate((x[offset] - x[(offset - 1 + POICount) % POICount]) * Count / len + x[(offset - 1 + POICount) % POICount], (y[offset] - y[(offset - 1 + POICount) % POICount]) * Count / len + y[(offset - 1 + POICount) % POICount], (z[offset] - z[(offset - 1 + POICount) % POICount]) * Count / len + z[(offset - 1 + POICount) % POICount]);
            }
            else
            {
                if (zoom < len)
                {
                    gameObject.transform.position = new Vector3(0, 0, -0.2f * zoom / len - 3.0f);
                }
                else if (zoom < 2 * len)
                {
                    tm1.text = "HAND Data \nExploring POI: '" + Continent[offset] + "'\n" + description[offset];
                }
                else if (zoom < 3 * len)
                {
                    gameObject.transform.position = new Vector3(0, 0, -0.2f * (3 * len - zoom) / len - 3.0f);
                }
                else
                {
                    offset++;
                    offset %= POICount;
                    Count = 0;
                    zoom = 0;
                }
                zoom++;
            }
            Count++;
            if (OVRInput.GetDown(OVRInput.RawButton.RHandTrigger))
            {
                modeFlag = 0;
                autoFlag = false;
                tm.text = "press 'A' to exploration automatically\npress 'B' to define the exploration process";
                Locate(0, 0, 0);
            }
        }
        if (modeFlag == 2)
        {
            if (OVRInput.GetDown(OVRInput.Button.One))
            {
                records.Add(transform.localEulerAngles);
            }
            if (OVRInput.Get(OVRInput.RawButton.RThumbstickUp))
            {
                gameObject.transform.Rotate(new Vector3(-1 * sensitive * 3, 0, 0), Space.World);
            }
            if (OVRInput.Get(OVRInput.RawButton.RThumbstickDown))
            {
                gameObject.transform.Rotate(new Vector3(sensitive * 3, 0, 0), Space.World);
            }
            if (OVRInput.Get(OVRInput.RawButton.RThumbstickRight))
            {
                gameObject.transform.Rotate(new Vector3(0, sensitive * 3, 0), Space.World);
            }
            if (OVRInput.Get(OVRInput.RawButton.RThumbstickLeft))
            {
                gameObject.transform.Rotate(new Vector3(0, -1 * sensitive * 3, 0), Space.World);
            }

            if (OVRInput.GetDown(OVRInput.RawButton.RIndexTrigger))
            {
                autoFlag = true;
                tm.text = "press 'RightHandTrigger' to restart";
            }
            if (OVRInput.GetDown(OVRInput.RawButton.RHandTrigger))
            {
                autoFlag = false;
                Count = 0;
                offset = 0;
                zoom = 0;
                records.Clear();
                tm.text = "press 'A' to exploration automatically\npress 'B' to define the exploration process";
                Locate(0, 0, 0);
            }
            if (autoFlag)
            {

                int length = records.Count;
                //tm.text = length.ToString();
                if (Count <= len)
                {
                    Locate((records[offset].x - records[(offset - 1 + length) % length].x) * Count / len + records[(offset - 1 + length) % length].x, (records[offset].y - records[(offset - 1 + length) % length].y) * Count / len + records[(offset - 1 + length) % length].y, (records[offset].z - records[(offset - 1 + length) % length].z) * Count / len + records[(offset - 1 + length) % length].z);
                }
                else
                {
                    if (zoom < len)
                    {
                        gameObject.transform.position = new Vector3(0, 0, -0.4f * zoom / len - 3.0f);
                    }
                    else if (zoom < 2 * len)
                    {

                    }
                    else if (zoom < 3 * len)
                    {
                        gameObject.transform.position = new Vector3(0, 0, -0.4f * (3 * len - zoom) / len - 3.0f);
                    }
                    else
                    {
                        offset++;
                        offset %= length;
                        Count = 0;
                        zoom = 0;
                    }
                    zoom++;
                }
                Count++;
            }

        }
        
    }*/
    private float pValueX = 0f, pValueY = 0f, pValueZ = 0f;
    public void Locate(float valueX, float valueY, float valueZ)
    {
        gameObject.transform.localEulerAngles = new Vector3(0, 0, 0);
        //gameObject.transform.Rotate(new Vector3(-pValueX, -pValueY, -pValueZ));
        gameObject.transform.Rotate(new Vector3(valueX, valueY, valueZ));
        pValueX = valueX;
        pValueY = valueY;
        pValueZ = valueZ;
    }
    
    void LateUpdate()
    {
        
        //gameObject.transform.Rotate(new Vector3(0, 0, sensitive));
        //Interactive();
        
        /*
        if (OVRInput.Get(OVRInput.Button.One))
        {
            gameObject.transform.position = new Vector3(transform.position.x, transform.position.y, transform.position.z-0.01f);
        }
        if (OVRInput.Get(OVRInput.Button.Two))
        {
            gameObject.transform.position = new Vector3(transform.position.x, transform.position.y, transform.position.z + 0.01f);
        }*/
        /*
        if (count % 5 == 0)
        {
            gameObject.transform.Rotate(new Vector3(0, sensitive, 0));
            count = 0;
        }
        count++;*/
    }
    void Update()
    {
        //FPS();
        //FPS();

        /*if (!backFlag)
        {
            if (delta > 2)
                backFlag = true;
            //GetComponent<OVRCameraRig>().GetComponent<Camera>().fieldOfView = 8 + delta;
            transform.position = new Vector3(transform.position.x, transform.position.y, -1 + delta);
            delta += 0.01f;
        }
        else
        {
            if (delta < 0)
                backFlag = false;
            transform.position = new Vector3(transform.position.x, transform.position.y, -1 + delta);
            delta -= 0.01f;
        }
        //
        gameObject.transform.Rotate(new Vector3(0, 0, m_count));*/

        /*if (sumTime % 20 == 0)
        {
            

            //delta %= 8;
            sumTime %= 20;
            
            //m_count++;
            //m_count %= 360;
        }
        sumTime++;*/
    }
}
