using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class testlung : MonoBehaviour
{

    public Camera cam1;
    public Camera cam2;
    public Camera cam3;
    public Camera cam4;
    private float timer = 0f;
    void Start()
    {
        Set(cam1, cam2, cam3, cam4);
    }

    void Update()
    {
        timer += Time.deltaTime;  // ����ʱ��

        if (timer >= 5f)
        {
            Set(cam2, cam1, cam3, cam4);
        }

        if (timer >= 10f)
        {
            Set(cam3, cam2, cam1, cam4);
        }

        if (timer >= 15f)
        {
            Set(cam4, cam2, cam3, cam1);
        }

    }


    private void Set(Camera camera1,Camera camera2,Camera camera3,Camera camera4)
    {
        camera1.gameObject.SetActive(true);
        camera2.gameObject.SetActive(false);
        camera3.gameObject.SetActive(false);
        camera4.gameObject.SetActive(false);
    }
}

