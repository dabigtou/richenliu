using UnityEngine;
using TMPro; 

public class RotationTracker : MonoBehaviour
{
    [Header("Settings")]
    public float targetAngle = 180f;
    public bool startOnPlay = true;

    [Header("UI References")]
    public TextMeshProUGUI timerText;
    public TextMeshProUGUI angleText;
    public TextMeshProUGUI statusText;

    [Header("Debug")]
    public Transform targetToTrack; 

    // �ڲ�����
    private float currentTotalAngle = 0f;
    private float timer = 0f;
    private bool isTracking = false;
    private Quaternion lastRotation;

    void Start()
    {
        if (targetToTrack == null)
        {
            targetToTrack = this.transform;
        }

        lastRotation = targetToTrack.rotation;

        if (startOnPlay)
        {
            StartTracking();
        }
    }

    void Update()
    {
        if (!isTracking || targetToTrack == null) return;

        timer += Time.deltaTime;

        float angleChanged = Quaternion.Angle(targetToTrack.rotation, lastRotation);

        if (angleChanged > 0.05f)
        {
            currentTotalAngle += angleChanged;
        }

        lastRotation = targetToTrack.rotation;

        UpdateUI();

        CheckCompletion();
    }

    public void SetTrackingTarget(Transform newTarget)
    {
        targetToTrack = newTarget;
        lastRotation = newTarget.rotation;
        Debug.Log("RotationTracker: Target set to " + newTarget.name);
    }

    public void StartTracking()
    {
        currentTotalAngle = 0f;
        timer = 0f;
        isTracking = true;
        if (targetToTrack != null) lastRotation = targetToTrack.rotation;

        if (statusText != null) statusText.text = "Task: Rotate " + targetAngle + "��";
    }

    void CheckCompletion()
    {
        if (currentTotalAngle >= targetAngle)
        {
            isTracking = false;
            OnTaskComplete();
        }
    }

    void OnTaskComplete()
    {
        Debug.Log($"Task Completed! Time: {timer:F2}s, Angle: {currentTotalAngle:F2}��");
        if (statusText != null)
        {
            statusText.text = "Success!";
            statusText.color = Color.green;
        }
    }

    void UpdateUI()
    {
        if (timerText != null) timerText.text = $"Time: {timer:F2}s";
        if (angleText != null) angleText.text = $"Angle: {currentTotalAngle:F0}�� / {targetAngle}��";
    }
}