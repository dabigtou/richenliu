using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class intermana : MonoBehaviour
{
    // Start is called before the first frame update
    public bool act = false;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {

    }
    public void click()
    {
        if(act==false)
        {
            gameObject.SetActive(true);
            act = true;

        }
        else
        {
            gameObject.SetActive(false);
            act = false;
        }
    }
    public void nlp()
    {
        Application.LoadLevel(1);
    }
    public void data()
    {
        Application.LoadLevel(2);
    }
    public void ct()
    {
        Application.LoadLevel(3);
    }
    public void focus()
    {
        Application.LoadLevel(4);
    }
    public void exiitt()
    {
        UnityEngine.Application.Quit();
    }

}
