﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cases : MonoBehaviour
{
    public Material mat; 
    public static bool ready = false;
    public static int dataId=1;
    public static int caseId=-1;
    Vector3[,] pos=new Vector3[3,2]{
        {new Vector3(-0.08f,0.22f,0.17f), new Vector3(-0.11f,0.23f,-0.08f)},
        {new Vector3(-0.09f,-0.23f,0.0f), new Vector3(-0.36f,0.05f,0.07f)},
        {new Vector3(-0.23f,0.22f,0.17f), new Vector3(0.0f,0.0f,-0.23f)}
    };
    Vector3[,] scales=new Vector3[3,2]{
        {new Vector3(0.12f,0.12f,0.12f), new Vector3(0.2f,0.2f,0.2f)},
        {new Vector3(0.3f,0.3f,0.3f), new Vector3(0.2f,0.2f,0.2f)},
        {new Vector3(0.15f,0.15f,0.15f), new Vector3(0.18f,0.18f,0.18f)}
    };
    // Start is called before the first frame update
    void Start()
    {
        
    }
    void ClearItems(){
        GameObject go=GameObject.Find("Cube");
        for (int i = 0; i < go.transform.childCount; i++) {
            if(go.transform.GetChild (i).name.StartsWith("target#"))
			    Destroy (go.transform.GetChild (i).gameObject);
		}
    }
    // Update is called once per frame
    void LateUpdate()
    {
        if(ready){
            ready=false;
            if(caseId==0){
                Debug.Log("Start Case1");
                GameObject go = new GameObject();
                go.name="target#0";
                go.transform.position=new Vector3(0,0,0);
                go.transform.localScale=scales[dataId, caseId]*2;
                go.transform.parent=GameObject.Find("Cube").transform;
                go.transform.localPosition = pos[dataId, caseId];
                go.layer=9;
                LineRenderer line=go.AddComponent<LineRenderer>();
                fun(line);
                caseId=-1;
            }else if(caseId==1){
                caseId=-1;
                for(int i=0; i<2; i++){
                    GameObject go = new GameObject();
                    go.name="target#"+i;
                    go.transform.position=new Vector3(0,0,0);
                    go.transform.localScale=scales[dataId, i]*2;
                    go.transform.parent=GameObject.Find("Cube").transform;
                    go.transform.localPosition = pos[dataId, i];
                    go.layer=9;
                    LineRenderer line=go.AddComponent<LineRenderer>();
                    fun(line);
                }
            }
        }
        
    }
    void fun(LineRenderer line){
        Vector3 centerPOs = new Vector3(0,0,0);//中心点
        Vector3 extens = (new Vector3(1,1,1)) / 2;
        Vector3 MaxPos = centerPOs + extens;//最大顶点
        Vector3 MinPos = centerPOs - extens;

        Vector3 A = new Vector3(MinPos.x, MaxPos.y, MinPos.z);
        Vector3 B = new Vector3(MinPos.x, MaxPos.y, MaxPos.z);
        Vector3 C = new Vector3(MaxPos.x, MaxPos.y, MaxPos.z);
        Vector3 D = new Vector3(MaxPos.x, MaxPos.y, MinPos.z);
        Vector3 A1 = new Vector3(MinPos.x, MinPos.y, MinPos.z);
        Vector3 B1 = new Vector3(MinPos.x, MinPos.y, MaxPos.z);
        Vector3 C1 = new Vector3(MaxPos.x, MinPos.y, MaxPos.z);
        Vector3 D1 = new Vector3(MaxPos.x, MinPos.y, MinPos.z);
        line.material = mat;
        line.useWorldSpace=false;
        line.SetVertexCount(16);
        //线的宽度
        line.SetWidth(0.04f, 0.04f);
        //根据8点画的Line；
        line.SetPosition(0, B1);//前左下
        line.SetPosition(1, C1);//前右下
        line.SetPosition(2, D1);//后右下
        line.SetPosition(3, A1);//后左下
        line.SetPosition(4, B1);
        line.SetPosition(5, B);//前左上
        line.SetPosition(6, C);//前右上
        line.SetPosition(7, D);//后右上
        line.SetPosition(8, A);//后左上
        line.SetPosition(9, B);
        line.SetPosition(10, A);
        line.SetPosition(11, A1);
        line.SetPosition(12, D1);
        line.SetPosition(13, D);
        line.SetPosition(14, C);
        line.SetPosition(15, C1);
    }
}
