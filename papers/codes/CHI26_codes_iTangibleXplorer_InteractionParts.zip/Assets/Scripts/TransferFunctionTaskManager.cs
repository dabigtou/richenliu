using UnityEngine;
using UnityEngine.UI; 
using TMPro;          

public class TransferFunctionTaskManager : MonoBehaviour
{
    [Header("UI References")]
    public TextMeshProUGUI timerText;  
    public TextMeshProUGUI statusText;  

    [Header("Observation Targets (Drag from Scene)")]
    public Image img_btP; 
    public Image img_btC; 
    public Image img_btO; 

    public GameObject obj_finger; 

    public GameObject line_C;
    public Transform pos_bt11; 

    public GameObject line_O;
    public Transform pos_bt16; 

    private int currentStep = 1;
    private float timer = 0f;
    private bool isCompleted = false;
    private float posTolerance = 0.01f; 

    void Start()
    {
        UpdateStatusUI();
    }

    void Update()
    {
        if (isCompleted) return;

        timer += Time.deltaTime;
        if (timerText != null) timerText.text = $"Time: {timer:F2}s";

        CheckProgress();
    }

    void CheckProgress()
    {
        switch (currentStep)
        {
            case 1: 
                if (IsColorHighlighted(img_btP))
                {
                    currentStep++;
                    Debug.Log("Step 1a: BT1 Opened");
                    UpdateStatusUI();
                }
                break;

            case 2: 
                if (obj_finger.activeSelf)
                {
                    currentStep++;
                    Debug.Log("Step 1b: BT4 Selected");
                    UpdateStatusUI();
                }
                break;

            case 3: 
                if (!IsColorHighlighted(img_btP))
                {
                    currentStep++;
                    Debug.Log("Step 1c: BT1 Closed");
                    UpdateStatusUI();
                }
                break;

            case 4: 
                if (IsColorHighlighted(img_btC))
                {
                    currentStep++;
                    Debug.Log("Step 2a: BT7 Opened");
                    UpdateStatusUI();
                }
                break;

            case 5: 
                if (IsLineAtPosition(line_C, pos_bt11))
                {
                    currentStep++;
                    Debug.Log("Step 2b: BT11 Selected");
                    UpdateStatusUI();
                }
                break;

            case 6: 
                if (!IsColorHighlighted(img_btC))
                {
                    currentStep++;
                    Debug.Log("Step 2c: BT7 Closed");
                    UpdateStatusUI();
                }
                break;

            case 7: 
                if (IsColorHighlighted(img_btO))
                {
                    currentStep++;
                    Debug.Log("Step 3a: BT13 Opened");
                    UpdateStatusUI();
                }
                break;

            case 8: 
                if (IsLineAtPosition(line_O, pos_bt16))
                {
                    currentStep++;
                    Debug.Log("Step 3b: BT16 Selected");
                    UpdateStatusUI();
                }
                break;

            case 9:
                if (!IsColorHighlighted(img_btO))
                {
                    CompleteTask();
                }
                break;
        }
    }

    bool IsColorHighlighted(Image img)
    {
        return img.color.r < 0.95f;
    }

    bool IsLineAtPosition(GameObject line, Transform targetBtn)
    {
        float lineX = line.transform.localPosition.x;
        float btnX = targetBtn.localPosition.x;

        return Mathf.Abs(lineX - btnX) < posTolerance;
    }

    void CompleteTask()
    {
        isCompleted = true;
        currentStep = 10;
        Debug.Log($"Mission Complete! Time: {timer:F2}s");

        if (statusText != null)
        {
            statusText.text = "Success!";
            statusText.color = Color.green;
        }
    }

    void UpdateStatusUI()
    {
        if (statusText == null) return;
        statusText.color = Color.black;

        switch (currentStep)
        {
            case 1: statusText.text = "Step 1: Open Menu 1"; break;
            case 2: statusText.text = "Step 1: Select Finger"; break;
            case 3: statusText.text = "Step 1: Close Menu 1"; break;

            case 4: statusText.text = "Step 2: Open Color Menu"; break;
            case 5: statusText.text = "Step 2: Select Green"; break;
            case 6: statusText.text = "Step 2: Close Color Menu"; break;

            case 7: statusText.text = "Step 3: Open Opacity Menu"; break;
            case 8: statusText.text = "Step 3: Select Medium Opacity"; break;
            case 9: statusText.text = "Step 3: Close Opacity Menu"; break;
        }
    }
}