﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using System.IO;

public class ReadCmd : MonoBehaviour
{
    // Start is called before the first frame update
    string[] cmds;
    public GameObject prefab;
    public static bool Ready=false;
    int index=0;
    void Start()
    {
        TextAsset Cmd = Resources.Load("Cmd") as TextAsset;
        string allLines = Cmd.text;
        cmds = allLines.Split('\n');
        if(cmds[0].StartsWith("pathline")){
            string[] args=cmds[index].Split(' ');
            Color c=new Color(float.Parse(args[1]), float.Parse(args[2]), float.Parse(args[3]));
            float width=float.Parse(args[4]);
            //MeshTest.width=width;
            //MeshTest.defaultColor=c;
            index=1;
        }
    }
    // Update is called once per frame
    int mode=0;
    int fps=30;
    float Sec=0;
    CmdHelper ch=new CmdHelper();
    void LateUpdate()
    {
        if(Ready==true&&index<cmds.Length){
            string[] args=cmds[index].Split(' ');
            Debug.Log(args[0]);
            switch (args[0]){
                case "pathline":
                Color c=new Color(float.Parse(args[1]), float.Parse(args[2]), float.Parse(args[3]));
                float width=float.Parse(args[4]);
                break;
                case "rotate":
                ch.axis=new Vector3(float.Parse(args[1]), float.Parse(args[2]), float.Parse(args[3]));
                ch.angle=float.Parse(args[4]);
                ch.time_rot=float.Parse(args[5]);
                mode=1;
                Ready=false;
                break;
                case "translate":
                ch.trans=new Vector3(float.Parse(args[1]), float.Parse(args[2]), float.Parse(args[3]));
                ch.time_trans=float.Parse(args[4]);
                mode=2;
                Ready=false;
                break;
                case "scale":
                ch.scale=new Vector3(float.Parse(args[1]), float.Parse(args[2]), float.Parse(args[3]));
                ch.time_scale=float.Parse(args[4]);
                mode=3;
                Ready=false;
                break;
                case "parallelStart":
                int i;
                for(i=index+1; i<cmds.Length; i++){
                    if(cmds[i].StartsWith("parallelEnd")){
                        break;
                    }
                    string[] args1=cmds[i].Split(' ');
                    switch(args1[0]){
                        case "rotate":
                        ch.axis=new Vector3(float.Parse(args1[1]), float.Parse(args1[2]), float.Parse(args1[3]));
                        ch.angle=float.Parse(args1[4]);
                        ch.time_rot=float.Parse(args1[5]);
                        break;
                        case "translate":
                        ch.trans=new Vector3(float.Parse(args1[1]), float.Parse(args1[2]), float.Parse(args1[3]));
                        ch.time_trans=float.Parse(args1[4]);
                        break;
                        case "scale":
                        ch.scale=new Vector3(float.Parse(args1[1]), float.Parse(args1[2]), float.Parse(args1[3]));
                        ch.time_scale=float.Parse(args1[4]);
                        break;
                    }
                }
                index=i;
                Debug.Log("parallel"+index);
                mode=4;
                Ready=false;
                break;
                case "placeANewBox":
                GameObject box=GameObject.CreatePrimitive(PrimitiveType.Cube);
                //GameObject box1=GameObject.Instantiate(prefab);
                Transform tf=box.transform;
                tf.parent=GameObject.Find("Cubes").transform;
                box.name="Cube"+args[1];
                Vector3 pos=new Vector3(float.Parse(args[2]), float.Parse(args[3]), float.Parse(args[4]));
                tf.position=pos;
                Vector3 scale=new Vector3(float.Parse(args[5]), float.Parse(args[6]), float.Parse(args[7]));
                tf.localScale=scale;
                Color color=new Color(float.Parse(args[8])/255.0f, float.Parse(args[9])/255.0f, float.Parse(args[10])/255.0f, float.Parse(args[11]));
                box.GetComponent<Renderer>().material.color=color;
                break;
            }
            index++;
            if(index>=cmds.Length){
                Ready=false;
            }
        }
        if(mode==1){
            float angle=ch.angle/(fps*ch.time_rot);
            Transform tf=GameObject.Find("Cube").transform;
            tf.rotation = Quaternion.AngleAxis(angle, ch.axis) * tf.rotation;
            Sec+=1.0f/fps;
            if(Sec>ch.time_rot){
                mode=0;
                Ready=true;
                Sec=0;
            }
        }else if(mode==2){
            Vector3 trans=ch.trans/(fps*ch.time_trans);
            Transform tf=GameObject.Find("Cube").transform;
            tf.position+=trans;
            Sec+=1.0f/fps;
            if(Sec>ch.time_trans){
                mode=0;
                Ready=true;
                Sec=0;
            }
        }else if(mode==3){
            Vector3 scale=ch.scale/(fps*ch.time_scale);
            Transform tf=GameObject.Find("Cube").transform;
            tf.localScale+=scale;
            Sec+=1.0f/fps;
            if(Sec>ch.time_scale){
                mode=0;
                Ready=true;
                Sec=0;
            }
        }else if(mode==4){
            Transform tf=GameObject.Find("Cube").transform;

            if(Sec<=ch.time_rot){
                float angle=ch.angle/(fps*ch.time_rot);
                tf.rotation = Quaternion.AngleAxis(angle, ch.axis) * tf.rotation;
            }
            if(Sec<=ch.time_trans){
                Vector3 trans=ch.trans/(fps*ch.time_trans);
                tf.position+=trans;
            }
            if(Sec<=ch.time_scale){
                Vector3 scale=ch.scale/(fps*ch.time_scale);
                tf.localScale+=scale;
            }
            Sec+=1.0f/fps;
            if(Sec>ch.time_rot&&Sec>ch.time_trans&&Sec>ch.time_scale){
                mode=0;
                Ready=true;
                Sec=0;
            }
        }
    }
    
}
public class CmdHelper{
    public float angle;
    public Vector3 axis;
    public float time_rot;
    public Vector3 trans;
    public float time_trans;
    public Vector3 scale;
    public float time_scale;
}