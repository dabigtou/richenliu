using UnityEngine;
using TMPro; 

public class SlicingTaskManager : MonoBehaviour
{
    [Header("UI References")]
    public TextMeshProUGUI timerText;   
    public TextMeshProUGUI statusText;  

    [Header("Step 1: Z-Line Settings")]
    public GameObject Zline;           
    public Transform targetBtn_Z;     
    public float tolerance = 0.005f;  

    [Header("Step 2: Y-Line Settings")]
    public GameObject Yline;          
    public Transform targetBtn_Y;     

    [Header("Step 3: X-Line Settings")]
    public GameObject Xline;         
    public Transform targetBtn_X;    

    private int currentStep = 1; 
    private float timer = 0f;
    private bool isCompleted = false;

    void Start()
    {
        UpdateStatusUI();
    }

    void Update()
    {
        if (isCompleted) return;

        timer += Time.deltaTime;
        if (timerText != null) timerText.text = $"Time: {timer:F2}s";

        CheckTaskProgress();
    }

    void CheckTaskProgress()
    {
        switch (currentStep)
        {
            case 1: 
                if (IsClose(Zline.transform.localPosition.z, targetBtn_Z.localPosition.z))
                {
                    currentStep++;
                    UpdateStatusUI();
                    Debug.Log("Step 1 Complete: Z-Line Set");
                }
                break;

            case 2: 
                if (IsClose(Yline.transform.localPosition.z, targetBtn_Y.localPosition.z))
                {
                    currentStep++;
                    UpdateStatusUI();
                    Debug.Log("Step 2 Complete: Y-Line Set");
                }
                break;

            case 3:
                if (IsClose(Xline.transform.localPosition.x, targetBtn_X.localPosition.x))
                {
                    CompleteTask();
                }
                break;
        }
    }

    bool IsClose(float posA, float posB)
    {
        return Mathf.Abs(posA - posB) < tolerance;
    }

    void CompleteTask()
    {
        isCompleted = true;
        currentStep = 4; 
        Debug.Log($"All Tasks Completed in {timer:F2}s");

        if (statusText != null)
        {
            statusText.text = "Success!";
            statusText.color = Color.green;
        }
    }

    void UpdateStatusUI()
    {
        if (statusText == null) return;

        statusText.color = Color.black;

        switch (currentStep)
        {
            case 1:
                statusText.text = "Task 1/3: Move Z-Line";
                break;
            case 2:
                statusText.text = "Task 2/3: Move Y-Line";
                break;
            case 3:
                statusText.text = "Task 3/3: Move X-Line";
                break;
        }
    }
}