using UnityEngine;
using TMPro; // ���� TextMeshPro

public class ScreenSpaceTracker : MonoBehaviour
{
    [Header("Settings")]
    public float rightThreshold = 0.8f;

    public float leftThreshold = 0.2f;

    public bool startOnPlay = true;

    [Header("UI References")]
    public TextMeshProUGUI timerText;   
    public TextMeshProUGUI statusText; 

    [Header("Target")]
    public Transform targetToTrack;   
    public Camera refCamera;          

    private float timer = 0f;
    private bool isRunning = false;
    private bool hasReachedRight = false; 
    private bool isCompleted = false;     

    void Start()
    {
        if (refCamera == null)
        {
            refCamera = Camera.main;
        }

        if (targetToTrack == null)
        {
            targetToTrack = transform;
        }

        if (statusText != null)
        {
            statusText.color = Color.black;
            statusText.text = "Wait for start...";
        }

        if (startOnPlay)
        {
            StartTracking();
        }
    }

    void Update()
    {
        if (!isRunning || targetToTrack == null || refCamera == null) return;

        timer += Time.deltaTime;
        if (timerText != null)
        {
            timerText.text = $"Time: {timer:F2}s";
        }

        Vector3 viewPos = refCamera.WorldToViewportPoint(targetToTrack.position);

        if (viewPos.z < 0) return;

        CheckProgress(viewPos.x);
    }

    void CheckProgress(float screenX)
    {
        if (!hasReachedRight)
        {
            if (screenX >= rightThreshold)
            {
                hasReachedRight = true;
                Debug.Log("Reached Right Side!");

                if (statusText != null)
                {
                    statusText.text = "Go Left <<"; 
                    statusText.color = Color.black; 
                }
            }
        }
        else if (!isCompleted)
        {
            if (screenX <= leftThreshold)
            {
                CompleteTask();
            }
        }
    }

    void CompleteTask()
    {
        isRunning = false;
        isCompleted = true;
        Debug.Log($"Task Finished in {timer:F2}s");

        if (statusText != null)
        {
            statusText.text = "Success!";
            statusText.color = Color.green; 
        }
    }

    public void StartTracking()
    {
        timer = 0f;
        isRunning = true;
        hasReachedRight = false;
        isCompleted = false;

        if (statusText != null)
        {
            statusText.text = "Move Right >>";
            statusText.color = Color.black;
        }
    }

    public void SetTrackingTarget(Transform newTarget)
    {
        targetToTrack = newTarget;
    }
}