﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using Microsoft.Win32.SafeHandles;
using System;

public class TF_Editor : MonoBehaviour
{
    static string[] TFName=new string[3]{
        "hand_tf3",
        "head_tf",
        "chest_tf"
    };
    public static float f_x = 0, f_y = 0.6f, f_w = 0.25f, f_h = 0.3f;
    public float m_r = 0.0025f;
    // Start is called before the first frame update
    void Start()
    {
        TextAsset t = Resources.Load(TFName[readanddraw2.dataIndex]) as TextAsset;
        string allLines = t.text;
        string[] lines = allLines.Split('\n');
        for (int i = 0; i < lines.Length; i++)
        {
            string[] c = lines[i].Split('\t');
            if (c.Length >= 5)
                points.Add(
                    new cPoint(
                        float.Parse(c[0]) * f_w, 
                        float.Parse(c[4]),//原本alpha 
                        m_r, 
                        new Color(float.Parse(c[1]), 
                        float.Parse(c[2]), 
                        float.Parse(c[3]), 
                        float.Parse(c[4])
                        )
                    )
                );
        }
        ReadCmd.Ready=true;
        Debug.Log("传递函数读取完成！");
    }
    public static List<cPoint> points = new List<cPoint>();
    public static bool dataChange=false;
    // Update is called once per frame
    void Update()
    {
        if(dataChange){
            points.Clear();
            TextAsset t = Resources.Load(TFName[readanddraw2.dataIndex]) as TextAsset;
            string allLines = t.text;
            string[] lines = allLines.Split('\n');
            for (int i = 0; i < lines.Length; i++)
            {
                string[] c = lines[i].Split('\t');
                if (c.Length >= 5)
                    points.Add(
                        new cPoint(
                            float.Parse(c[0]) * f_w, 
                            float.Parse(c[4]),//原本alpha 
                            m_r, 
                            new Color(float.Parse(c[1]), 
                            float.Parse(c[2]), 
                            float.Parse(c[3]), 
                            float.Parse(c[4])
                            )
                        )
                    );
            }
            dataChange=false;
        }
    }
    
    
    
}
/// <summary>
/// 传递函数上的控制点类
/// </summary>
public class cPoint
{
    /// <summary>
    /// 控制点坐标及长宽
    /// </summary>
    public float m_fx, m_fy, m_fr;
    /// <summary>
    /// 控制点颜色
    /// </summary>
    public Color m_color;
    /// <summary>
    /// 默认构造函数
    /// </summary>
    public cPoint()
    {
        m_fx = m_fy = m_fr = 0;
        m_color = new Color(0, 0, 0, 0);
    }
    /// <summary>
    /// 带参构造，传入屏幕x,y,控制点宽度，颜色信息。
    /// </summary>
    /// <param name="px"></param>
    /// <param name="py"></param>
    /// <param name="pr"></param>
    /// <param name="pc"></param>
    public cPoint(float px, float py, float pr, Color pc)
    {
        m_fx = px;
        m_fy = py;
        m_fr = pr;
        m_color = pc;
    }
    /// <summary>
    /// 圆内判断
    /// </summary>
    /// <param name="px"></param>
    /// <param name="py"></param>
    /// <returns></returns>
    public bool isInPoint(float px, float py)
    {
        return (float)System.Math.Sqrt(System.Math.Pow(px - m_fx, 2) + System.Math.Pow(py - m_fy, 2)) <= m_fr;
    }
    /// <summary>
    /// 正方形内判断
    /// </summary>
    /// <param name="px"></param>
    /// <param name="py"></param>
    /// <param name="w"></param>
    /// <param name="h"></param>
    /// <returns></returns>
    public bool isInPoint(float px, float py, float w, float h)
    {
        return (px >= m_fx - m_fr / 2) && 
            (px <= m_fx + m_fr / 2) && 
            (py >= m_fy - m_fr * w / h / 2) && 
            (py <= m_fy + m_fr * w / h / 2);
    }
}
