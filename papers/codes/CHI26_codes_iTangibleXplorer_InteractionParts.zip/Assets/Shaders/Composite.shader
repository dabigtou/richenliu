Shader "Custom/Composite" {
	Properties {
		_MainTex ("Base (RGB)", 2D) = "" {}
		_BlendTex ("Blend (RGB)", 2D) = "" {}	
	}
	Subshader {
		Pass {
			ZTest Always Cull Off ZWrite Off
			Fog { Mode off }

			CGPROGRAM
			//ARB_precision_hint_fastest:使用低精度，fp16
			#pragma fragmentoption ARB_precision_hint_fastest
			#pragma vertex vert
			#pragma fragment frag
			#include "UnityCG.cginc"
			//#pragma target 3.0
			
			struct v2f {
				float4 pos : POSITION;
				float2 uv[2] : TEXCOORD0;
			};
			sampler2D _MainTex;
			sampler2D _BlendTex;
			
			float4 _TexSize;
			
			v2f vert( appdata_img v ) {
				v2f o;
				o.pos = UnityObjectToClipPos(v.vertex);
				o.uv[0] = v.texcoord.xy;
				o.uv[1] = v.texcoord.xy;
				return o;
			}
			
			half4 frag(v2f i) : COLOR 
			{		
				half4 src = tex2D(_MainTex, i.uv[1]);
				half4 dst = tex2D(_BlendTex, i.uv[0]);
				return (1.0f - dst.a) * src + dst;
			}
			ENDCG
		}
	}
	Fallback off
}