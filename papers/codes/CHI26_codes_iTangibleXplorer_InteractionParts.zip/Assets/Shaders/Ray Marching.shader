Shader "Custom/RayMarching"
{
	Properties
	{
		_Color("Color", color) = (1,1,1,1)
		_Strength("Strength",range(0,5)) = 1
		texVolume("体数据",3D) = "white"{}
		_FrontTex("前面纹理",2D) = "white"{}
		_BackTex("后面纹理",2D) = "white"{}
		_texTransfunction("传递函数",2D) = "white"{}
		xstart("开始", int) = 0
		xlength("结束", int) = 0
		ystart("开始", int) = 0
		ylength("结束", int) = 0
		section("section", float) = 0
		isBall("isBall", float) = 0
		ball_x("ball_x", float) = 0
		ball_y("ball_y", float) = 0
		ball_z("ball_z", float) = 0
		ball_r("ball_r", float) = 0
		ellipsoid_a("ellipsoid_a", float) = 0
		ellipsoid_b("ellipsoid_b", float) = 0
		ellipsoid_c("ellipsoid_c", float) = 0
		_Width("Width", range(0,0.5)) = 0.1
	}
		SubShader
		{
			ZTest Always
			ZWrite On
			Pass
			{
				CGPROGRAM
				#pragma vertex vert
				#pragma fragment frag
				#include "UnityCG.cginc"
				//#pragma target 3.0
				struct v2f {
					float4 pos : POSITION;
					float2 uv : TEXCOORD0;
				};
				uniform sampler3D texVolume;
				uniform sampler2D _texTransfunction;
				float xstart, xlength;
				float ystart, ylength;
				float isBall, section;
				float ball_x, ball_y, ball_z, ball_r;
				float ellipsoid_a, ellipsoid_b, ellipsoid_c;
				float4 _VolumeTex_TexelSize;
				sampler2D _FrontTex;
				sampler2D _BackTex;
				fixed4 _Color;
				float _Strength;
				fixed _Width;
				v2f vert(appdata_img v)
				{
					v2f o;
					o.pos = UnityObjectToClipPos(v.vertex);
					o.uv = v.texcoord.xy;
					return o;
				}
				half4 raymarch(v2f i)
				{
					float3 frontPos = tex2D(_FrontTex, i.uv).xyz;
					float3 backPos = tex2D(_BackTex, i.uv).xyz;
					float3 dir = backPos - frontPos;
					float3 pos = frontPos;
					float4 dst = 0;

					float3 stepDist = dir / 128;

					for (int k = 0; k < 128; k++)
					{
						pos += stepDist;
						//切片实现
						//if(k>=start&&k<end){
						//	float4 src = tex3D(texVolume, pos);
						//	src.rgb *= src.a;
						//	dst = (1.0f - dst.a) * src + dst;//blend
						//}
						//if((pos.x-ball_x)*(pos.x-ball_x)+(pos.y-ball_y)*(pos.y-ball_y)+(pos.z-ball_z)*(pos.z-ball_z)<ball_r*ball_r){
						//	float4 src = tex3D(texVolume, pos);
						//	src.rgb *= src.a;
						//	dst = (1.0f - dst.a) * src + dst;//blend
						//}
						if (section == -1.0f) {
							if ((pos.x >= xstart && pos.x < xstart + xlength) || (pos.y >= ystart && pos.y < ystart + ylength)) {
								float4 src = tex3D(texVolume, pos);
								float2 temp;
								temp.x = 0;
								temp.y = src.a;
								float4 rgba = tex2D(_texTransfunction, temp);
								rgba.rgb *= rgba.a;
								dst = (1.0f - dst.a) * rgba + dst;//blend
							}

						}
	else {
	   if (section == 1.0f) {
		   if (isBall == 1.0f) {
			   if ((pos.x - ball_x) * (pos.x - ball_x) + (pos.y - ball_y) * (pos.y - ball_y) + (pos.z - ball_z) * (pos.z - ball_z) < ball_r * ball_r) {
				   float4 src = tex3D(texVolume, pos);
				   float2 temp;
				   temp.x = 0;
				   temp.y = src.a;
				   float4 rgba = tex2D(_texTransfunction, temp);
				   rgba.rgb *= rgba.a;
				   dst = (1.0f - dst.a) * rgba + dst;//blend
			   }
		   }
else {
   if ((pos.x - ball_x) * (pos.x - ball_x) / (ellipsoid_a * ellipsoid_a) + (pos.y - ball_y) * (pos.y - ball_y) / (ellipsoid_b * ellipsoid_b) + (pos.z - ball_z) * (pos.z - ball_z) / (ellipsoid_c * ellipsoid_c) <= 1.0f) {
	   float4 src = tex3D(texVolume, pos);
	   float2 temp;
	   temp.x = 0;
	   temp.y = src.a;
	   float4 rgba = tex2D(_texTransfunction, temp);
	   rgba.rgb *= rgba.a;
	   dst = (1.0f - dst.a) * rgba + dst;//blend
   }
   /*else{
	   float4 src = tex3D(texVolume, pos);
	   float2 temp;
	   temp.x = 0;
	   temp.y = src.a;
	   if(abs(src.a-0)>0.00001f){
		   float4 rgba;
		   //rgba.rgb *= rgba.a;
		   rgba.r=0.5f;
		   rgba.g=0;
		   rgba.b=0;
		   rgba.a=0.1f;
		   dst = rgba.a * rgba + dst;
	   }
   }*/
}
}
else {
   float4 src = tex3D(texVolume, pos);
   float2 temp;
   temp.x = 0;
   temp.y = src.a;
   float4 rgba = src;
   rgba.rgb *= rgba.a;
   dst = (1.0f - dst.a) * rgba + dst;//blend
}
}


}

return dst;
}
half4 frag(v2f i) : COLOR
{
	return raymarch(i) * _Color * _Strength;
}
ENDCG
}
		}
			FallBack Off
}
