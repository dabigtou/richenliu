﻿Shader "Custom/volume"
{
    Properties
    {
      
    }
    SubShader
    {
        Tags {"RenderType" = "Volume"}
 
        ZWrite On
 
        Pass
        {
            ColorMask 0
        }

    }
    FallBack "Diffuse"
}
