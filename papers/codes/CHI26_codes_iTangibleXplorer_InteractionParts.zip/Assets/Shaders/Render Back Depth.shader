﻿Shader "Custom/RayBackMarching"
{
	Properties
    {
      
    }
	SubShader
    {
		Tags {"RenderType"="Volume"}
		Fog { Mode Off }
		Pass
		{
			Cull Front
			CGPROGRAM
			#pragma vertex vert
			#pragma fragment frag
			#include "UnityCG.cginc"
			struct v2f {
				float4 pos : POSITION;
				float3 localPos : TEXCOORD0;
			};
			float4 _VolumeScale;
			v2f vert(appdata_base v)
			{
				v2f o;
				o.pos = UnityObjectToClipPos(v.vertex);
				o.localPos = v.vertex.xyz + 0.5;
				return o;
			}
			half4 frag(v2f i) : COLOR
			{
				return float4(i.localPos, 1);
			}
			ENDCG
		}
	}
	FallBack "Diffuse"
}
