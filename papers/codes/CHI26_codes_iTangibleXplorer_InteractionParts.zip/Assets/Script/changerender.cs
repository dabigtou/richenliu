using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class changerender : MonoBehaviour
{
    public readAndDraw scriptB;  
    


}
