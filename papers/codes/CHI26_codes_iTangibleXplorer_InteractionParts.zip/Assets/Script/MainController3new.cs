using Vuforia;
using UnityEngine;
using UnityEngine.UI;
using Image = UnityEngine.UI.Image;

public class MainController3new : MonoBehaviour
{
    public GameObject img1,img2,img3,img4,img5,img6;
    public GameObject p1, p2;
    public GameObject ctimg1, ctimg2, ctimg3;
    public GameObject h1, h2, h3;
    public GameObject line,line2;
    public GameObject MT, H1, H2, H3,C1,C2,C3;
    public GameObject get, ok;
    public Text t;
    RenderTexture renderTexture;
    VirtualButtonBehaviour[] vbs;
    public int flag,f=0,f2=0;
    public int cnt = 0;
    int x=1, y = 1;
    //public Text t;
    private void Start()
    {
        
        vbs = GetComponentsInChildren<VirtualButtonBehaviour>();
        for (int i = 0; i < vbs.Length; i++)
        {
            vbs[i].RegisterOnButtonPressed(OnButtonPressed);
            vbs[i].RegisterOnButtonReleased(OnButtonReleased);
        }
        Debug.Log(vbs.Length);
    }
//�ô������ڽ���CT��Ƭ��ѡ��
    private void Update()
    {
        flag =GetComponent<MainController1>().flag;
       if(flag==7)
        {
            if (x == 1)//ѡ��ͼƬ����
            {
                h1.SetActive(true);
                h2.SetActive(false);
                h3.SetActive(false);
                renderTexture = ctimg1.GetComponent<RenderTexture>();
            }else if(x==2){
                h1.SetActive(false);
                h2.SetActive(true);
                h3.SetActive(false);
                renderTexture = ctimg2.GetComponent<RenderTexture>();
            }
            else
            {
                h1.SetActive(false);
                h2.SetActive(false);
                h3.SetActive(true);
                renderTexture = ctimg2.GetComponent<RenderTexture>();
            }
            ctimg1.GetComponent<RawImage>().texture = Resources.Load<Texture>("ct/"+(3 * y- 2).ToString());
            ctimg2.GetComponent<RawImage>().texture = Resources.Load<Texture>("ct/" + (3 * y - 1).ToString());
            ctimg3.GetComponent<RawImage>().texture = Resources.Load<Texture>("ct/" + (3 * y - 1).ToString());
            t.text = "Page " + y.ToString();
            
        }
    
     
    }
    //��ť������ʱ
    private void OnButtonPressed(VirtualButtonBehaviour vb)
    {

        if (flag == 6)
        {

            if (vb.VirtualButtonName == "skin")
            {
                if(H1.activeInHierarchy&& H2.activeInHierarchy)
                {
                    if(!H3.activeInHierarchy)
                    {
                        H3.SetActive(true);
                        C3.SetActive(true);
                    }
                   else
                    {
                        H3.SetActive(false);
                        C3.SetActive(false);
                    }
                }
            }


            if (vb.VirtualButtonName == "vess")
            {
                if (!H1.activeInHierarchy)
                {
                    H1.SetActive(true);
                    C1.SetActive(true);
                }
                else
                {
                    H1.SetActive(false);
                    C1.SetActive(false);
                }
            }

            if (vb.VirtualButtonName == "bone")
            {
                if (!H2.activeInHierarchy)
                {
                    H2.SetActive(true);
                    C2.SetActive(true);
                }
                else
                {
                    H2.SetActive(false);
                    C2.SetActive(false);
                }
            }

        }
        if (flag == 7)
        {
            Debug.Log(vb.VirtualButtonName);
            MT.GetComponent<GestureControl1>().flag = 0;
            if (vb.VirtualButtonName == "s1")
            {
                line.transform.localPosition=new Vector3(vb.transform.localPosition.x, line.transform.localPosition.y, line.transform.localPosition.z);
                x = 1;
            }

                
            if (vb.VirtualButtonName == "s2")
            {
                line.transform.localPosition = new Vector3(vb.transform.localPosition.x, line.transform.localPosition.y, line.transform.localPosition.z);
                x = 1;
            }

            if (vb.VirtualButtonName == "s3")
            {
                line.transform.localPosition = new Vector3(vb.transform.localPosition.x, line.transform.localPosition.y, line.transform.localPosition.z);
                x = 2;
            }

            if (vb.VirtualButtonName == "s4")
            {
                line.transform.localPosition = new Vector3(vb.transform.localPosition.x, line.transform.localPosition.y, line.transform.localPosition.z);
                x = 2;
            }

            if (vb.VirtualButtonName == "s5")
            {
                line.transform.localPosition = new Vector3(vb.transform.localPosition.x, line.transform.localPosition.y, line.transform.localPosition.z);
                x = 3;
            }

            if (vb.VirtualButtonName == "s6")
            {
                line.transform.localPosition = new Vector3(vb.transform.localPosition.x, line.transform.localPosition.y, line.transform.localPosition.z);
                x = 3;
            }
            if (vb.VirtualButtonName == "ss1")
            {
                y = 1;
                line2.transform.localPosition = new Vector3(line2.transform.localPosition.x, line2.transform.localPosition.y, vb.transform.localPosition.z);
            }
            if (vb.VirtualButtonName == "ss2")
            {
                y = 2;
                line2.transform.localPosition = new Vector3(line2.transform.localPosition.x, line2.transform.localPosition.y, vb.transform.localPosition.z);
            }
            if (vb.VirtualButtonName == "ss3")
            {
                y = 3;
                line2.transform.localPosition = new Vector3(line2.transform.localPosition.x, line2.transform.localPosition.y, vb.transform.localPosition.z);
            }
            if (vb.VirtualButtonName == "ss4")
            {
                y = 4;
                line2.transform.localPosition = new Vector3(line2.transform.localPosition.x, line2.transform.localPosition.y, vb.transform.localPosition.z);
            }
            if (vb.VirtualButtonName == "ss5")
            {
                y = 5;
                line2.transform.localPosition = new Vector3(line2.transform.localPosition.x, line2.transform.localPosition.y, vb.transform.localPosition.z);
            }
            if (vb.VirtualButtonName == "ss6")
            {
                y = 6;
                line2.transform.localPosition = new Vector3(line2.transform.localPosition.x, line2.transform.localPosition.y, vb.transform.localPosition.z);
            }
            MT.GetComponent<GestureControl1>().flag = 0;
            //p1.transform.localPosition = new Vector3(-30, 0, 48);
            if (vb.VirtualButtonName == "get")
            {
                cnt++;
                get.GetComponent<Image>().color = new Color(72 / 255f, 121 / 255f, 195 / 255f, 195 / 255f);
                switch (cnt)
                {
                    case 1:
                        img1.GetComponent<RawImage>().texture = Resources.Load<Texture>("ct/" + (3 * y +x-3).ToString());
                        img1.SetActive(true);
                        break;
                    case 2:
                        img2.GetComponent<RawImage>().texture = Resources.Load<Texture>("ct/" + (3 * y + x - 3).ToString());
                        img2.SetActive(true);
                        break;
                    case 3:
                        img3.GetComponent<RawImage>().texture = Resources.Load<Texture>("ct/" + (3 * y + x - 3).ToString());
                        img3.SetActive(true);
                        break;
                    case 4:
                        img4.GetComponent<RawImage>().texture = Resources.Load<Texture>("ct/" + (3 * y - x).ToString());
                        img4.SetActive(true);
                        break;
                    case 5:
                        img5.GetComponent<RawImage>().texture = Resources.Load<Texture>("ct/" + (3 * y - x).ToString());
                        img5.SetActive(true);
                        break;
                    case 6:
                        img6.GetComponent<RawImage>().texture = Resources.Load<Texture>("ct/" + (3 * y - x).ToString());
                        img6.SetActive(true);
                        break;
                }
            }
            if (vb.VirtualButtonName == "ok")
            {
                ok.GetComponent<Image>().color = new Color(72 / 255f, 121 / 255f, 195 / 255f, 195 / 255f);
                p1.SetActive(false);
                p2.SetActive(true);
            }

        }
        else
        {
            if (flag != 8 && flag != 7)
            {
                img1.SetActive(false);
                img2.SetActive(false);
                img3.SetActive(false);
                img4.SetActive(false);
                img5.SetActive(false);
                img6.SetActive(false);
            }
               // p1.SetActive(false);

        }
       

       
    }
    //��ť�ͷ�ʱ
    private void OnButtonReleased(VirtualButtonBehaviour vb)
    {
        if (vb.VirtualButtonName == "get")
        {
            get.GetComponent<Image>().color = new Color(72/255f, 169/255f, 195/255f, 195/255f);

        }
        if (vb.VirtualButtonName == "ok")
        {

            ok.GetComponent<Image>().color = new Color(72 / 255f, 169 / 255f, 195 / 255f, 195 / 255f);
        }

    }
}
    
    


