using UnityEngine.UI;
using UnityEngine;

public class Changecolor : MonoBehaviour
{
    // Start is called before the first frame update
    public RawImage paint;
    public Image m_img;
    // Update is called once per frame
    void Update()
    {
        m_img.color= paint.color;
    }
}
