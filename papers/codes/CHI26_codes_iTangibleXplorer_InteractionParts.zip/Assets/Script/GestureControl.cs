using UnityEngine.UI;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GestureControl : MonoBehaviour
{
    
    public GameObject mControObj;
    public GameObject mControObj1;
    public GameObject b1,b21,b22,b31,b32,b33,b41,b42,b43,b44,b51,b52,b53,b54,b55,b61,b62,b63,b64,b65,b66;




    private void Update()
    {
    
        mControObj1.transform.localRotation = transform.rotation;
        b1.transform.localRotation = transform.rotation;
        b21.transform.localRotation = transform.rotation;
        b22.transform.localRotation = transform.rotation;
        b31.transform.localRotation = transform.rotation;
        b32.transform.localRotation = transform.rotation;
        b33.transform.localRotation = transform.rotation;
        b41.transform.localRotation = transform.rotation;
        b42.transform.localRotation = transform.rotation;
        b43.transform.localRotation = transform.rotation;
        b44.transform.localRotation = transform.rotation;
        b51.transform.localRotation = transform.rotation;
        b52.transform.localRotation = transform.rotation;
        b53.transform.localRotation = transform.rotation;
        b54.transform.localRotation = transform.rotation;
        b55.transform.localRotation = transform.rotation;
        b61.transform.localRotation = transform.rotation;
        b62.transform.localRotation = transform.rotation;
        b63.transform.localRotation = transform.rotation;
        b64.transform.localRotation = transform.rotation;
        b65.transform.localRotation = transform.rotation;
        b66.transform.localRotation = transform.rotation;


    }
    
   

    
   
    
 

}