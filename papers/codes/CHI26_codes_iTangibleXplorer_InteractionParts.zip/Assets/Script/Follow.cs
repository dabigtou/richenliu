using System.Collections;
using UnityEngine;
using System.Collections.Generic;
public class Follow : MonoBehaviour
{

    Vector3 lastPos = Vector3.zero;
    public GameObject target;
    public Vector3 v;
    public float time;

    void Start()
    {
    }
    private void Update()
    {
        OnMoving();
        v=transform.position;
    }

    public void OnMoving()
    {

        Vector3 sPos = transform.position;

        if (lastPos == Vector3.zero)
        {
            lastPos = sPos;
            return;
        }


        float offsetX = sPos.x - lastPos.x;
        float offsetY = sPos.y - lastPos.y;
        target.transform.localPosition += new Vector3(offsetX*time, offsetY*time, 0);
        lastPos = sPos;
    }
}
