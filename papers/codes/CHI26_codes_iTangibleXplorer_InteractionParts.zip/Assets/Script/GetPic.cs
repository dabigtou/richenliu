using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;

public class GetPic : MonoBehaviour
{
    // Start is called before the first frame update
    public RenderTexture renderTexture;
    void Update()
    {
        int width = renderTexture.width;
        int height = renderTexture.height;
        Texture2D texture2D = new Texture2D(width, height, TextureFormat.ARGB32, false);
        RenderTexture.active = renderTexture;
        texture2D.ReadPixels(new Rect(0, 0, width, height), 0, 0);
        texture2D.Apply();
        byte[] vs = texture2D.EncodeToPNG();


        string path = @"E:\pic\" + name + ".png";
        FileStream fileStream = new FileStream(path, FileMode.Create, FileAccess.Write);
        fileStream.Write(vs, 0, vs.Length);
        fileStream.Dispose();
        fileStream.Close();

    }

}
