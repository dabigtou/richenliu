using Vuforia;
using UnityEngine;
using UnityEngine.UI;
using Image = UnityEngine.UI.Image;

public class MainController2 : MonoBehaviour
{
    public GameObject p1, p2, p3, p4, p5, p6;
    public GameObject b1, b21, b22, b31, b32, b33, b41, b42, b43, b44, b51, b52, b53, b54, b55, b61, b62, b63, b64, b65, b66;
    public RenderTexture renderTexture;
    public GameObject img1,img2,img3,img4,img5,img6;
    public GameObject zoommer,line,line2;
    VirtualButtonBehaviour[] vbs;
    int flag,f=0,f2=0;
    int cnt = 0;
    //public Text t;
    private void Start()
    {
        
        vbs = GetComponentsInChildren<VirtualButtonBehaviour>();
        for (int i = 0; i < vbs.Length; i++)
        {
            vbs[i].RegisterOnButtonPressed(OnButtonPressed);
            vbs[i].RegisterOnButtonReleased(OnButtonReleased);
        }
        Debug.Log(vbs.Length);
    }
    void ChangePosition1(float tmp)
    {
        float step = 0.1f;
       

        b1.transform.localPosition = Vector3.MoveTowards(b1.transform.localPosition, new Vector3(0, tmp, 0), step);
        b21.transform.localPosition = Vector3.MoveTowards(b1.transform.localPosition, new Vector3(0, tmp, 0), step);
        b22.transform.localPosition = Vector3.MoveTowards(b1.transform.localPosition, new Vector3(0, tmp, 0), step);
        b31.transform.localPosition = Vector3.MoveTowards(b1.transform.localPosition, new Vector3(0, tmp, 0), step);
        b32.transform.localPosition = Vector3.MoveTowards(b1.transform.localPosition, new Vector3(0, tmp, 0), step);
        b33.transform.localPosition = Vector3.MoveTowards(b1.transform.localPosition, new Vector3(0, tmp, 0), step);
        b41.transform.localPosition = Vector3.MoveTowards(b1.transform.localPosition, new Vector3(0, tmp, 0), step);
        b42.transform.localPosition = Vector3.MoveTowards(b1.transform.localPosition, new Vector3(0, tmp, 0), step);
        b43.transform.localPosition = Vector3.MoveTowards(b1.transform.localPosition, new Vector3(0, tmp, 0), step);
        b44.transform.localPosition = Vector3.MoveTowards(b1.transform.localPosition, new Vector3(0, tmp, 0), step);
        b51.transform.localPosition = Vector3.MoveTowards(b1.transform.localPosition, new Vector3(0, tmp, 0), step);
        b52.transform.localPosition = Vector3.MoveTowards(b1.transform.localPosition, new Vector3(0, tmp, 0), step);
        b53.transform.localPosition = Vector3.MoveTowards(b1.transform.localPosition, new Vector3(0, tmp, 0), step);
        b54.transform.localPosition = Vector3.MoveTowards(b1.transform.localPosition, new Vector3(0, tmp, 0), step);
        b55.transform.localPosition = Vector3.MoveTowards(b1.transform.localPosition, new Vector3(0, tmp, 0), step);
        b61.transform.localPosition = Vector3.MoveTowards(b1.transform.localPosition, new Vector3(0, tmp, 0), step);
        b62.transform.localPosition = Vector3.MoveTowards(b1.transform.localPosition, new Vector3(0, tmp, 0), step);
        b63.transform.localPosition = Vector3.MoveTowards(b1.transform.localPosition, new Vector3(0, tmp, 0), step);
        b64.transform.localPosition = Vector3.MoveTowards(b1.transform.localPosition, new Vector3(0, tmp, 0), step);
        b65.transform.localPosition = Vector3.MoveTowards(b1.transform.localPosition, new Vector3(0, tmp, 0), step);
        b66.transform.localPosition = Vector3.MoveTowards(b1.transform.localPosition, new Vector3(0, tmp, 0), step);
    }
    void ChangePosition2(Vector3 k)
    {
        float step = 0.08f;
        zoommer.transform.localPosition = Vector3.MoveTowards(zoommer.transform.localPosition, k, step);

    }
    private void Update()
    {
        flag =GetComponent<MainController>().flag;
        if(f==1)
        {
            ChangePosition1(-4);
        }
        if (f ==2)
        {
            ChangePosition1(-2.4f);
        }
        if (f == 3)
        {
            ChangePosition1(-0.8f);
        }
        if (f == 4)
        {
            ChangePosition1(0.8f);
        }
        if (f ==5)
        {
            ChangePosition1(2.4f);
        }
        if (f == 6)
        {
            ChangePosition1(4f);
        }
        if (flag != 8)
        {
            cnt = 0;

            p1.transform.localPosition = new Vector3(0, 4.30000019f, 8.03999996f);
            img1.SetActive(false);
            img2.SetActive(false);
            img3.SetActive(false);
            img4.SetActive(false);
            img5.SetActive(false);
            img6.SetActive(false);
        }
        if (f2 == 1)
        {
            ChangePosition2(new Vector3(-0.540000021f, 0.620000005f, 4.15339756f));
        }
        if (f2 == 2)
        {
            ChangePosition2(new Vector3(0.720000029f, 0.620000005f, 4.15339756f));
        }
        if (f2 == 3)
        {
            ChangePosition2(new Vector3(0.0592296124f, 0.139324665f, 4.15339756f));
        }
        if (f2 == 4)
        {
            ChangePosition2(new Vector3(-0.400000006f, -0.479999989f, 4.15339756f));
        }
        if (f2==5)
        {
            ChangePosition2(new Vector3(0.709999979f, -0.569999993f, 4.15339756f));
        }
        if (f2 == 6)
        {
            ChangePosition2(new Vector3(-0.300000012f, 0.360000014f, 4.15339756f));
        }
        if (f2 == 7)
        {
            ChangePosition2(new Vector3(0.270000011f, 0.330000013f, 4.15339756f));
        }
        if (f2 == 8)
        {
            ChangePosition2(new Vector3(-0.540000021f, 0.139324665f, 4.15339756f));
        }
        if (f2 == 9)
        {
            ChangePosition2(new Vector3(0.449999988f, 0.139324665f, 4.15339756f));
        }
        if (f2 == 10)
        {
            ChangePosition2(new Vector3(-0.419999987f, -0.400000006f, 4.15339756f));
        }
        if (f2 == 11)
        {
            ChangePosition2(new Vector3(0.270000011f, -0.400000006f, 4.15339756f));
        }
    }
    //��ť������ʱ
    private void OnButtonPressed(VirtualButtonBehaviour vb)
    {
        //ͨ��VirtualButtonBehaviour�µ�VirtualButtonName���Լ������ᵽ��Name���Ի�ȡ��Ӧ�����ⰴť
        if (flag == 3)
        {
            if (vb.VirtualButtonName == "a1")
            {
                
                f2 = 1;
            }
            if (vb.VirtualButtonName == "a2")
            {
                f2 = 2;
             
            }
            if (vb.VirtualButtonName == "a3")
            {
                f2 = 3;
            
            }
            if (vb.VirtualButtonName == "a4")
            {
                f2 = 4;
               
            }
            if (vb.VirtualButtonName == "a5")
            {
                f2 = 5;
               
            }
            if (vb.VirtualButtonName == "a6")
            {
                f2 = 6;

            }
            if (vb.VirtualButtonName == "a7")
            {
                f2 = 7;

            }
            if (vb.VirtualButtonName == "a8")
            {
                f2 = 8;

            }
            if (vb.VirtualButtonName == "a9")
            {
                f2 = 9;

            }
            if (vb.VirtualButtonName == "a10")
            {
                f2 = 10;

            }
            if (vb.VirtualButtonName == "a11")
            {
                f2 =11;

            }

        }
        if (flag == 7)
        {
        
            if (vb.VirtualButtonName == "s1")
            {
                line.transform.localPosition=new Vector3(vb.transform.localPosition.x, line.transform.localPosition.y, line.transform.localPosition.z);
                p1.SetActive(true);
                p2.SetActive(false);
                p3.SetActive(false);
                p4.SetActive(false);
                p5.SetActive(false);
                p6.SetActive(false);
            }

                
            if (vb.VirtualButtonName == "s2")
            {
                line.transform.localPosition = new Vector3(vb.transform.localPosition.x, line.transform.localPosition.y, line.transform.localPosition.z);
                p1.SetActive(false);
                p2.SetActive(true);
                p3.SetActive(false);
                p4.SetActive(false);
                p5.SetActive(false);
                p6.SetActive(false);
            }

            if (vb.VirtualButtonName == "s3")
            {
                line.transform.localPosition = new Vector3(vb.transform.localPosition.x, line.transform.localPosition.y, line.transform.localPosition.z);
                p1.SetActive(false);
                p2.SetActive(false);
                p3.SetActive(true);
                p4.SetActive(false);
                p5.SetActive(false);
                p6.SetActive(false);
            }

            if (vb.VirtualButtonName == "s4")
            {
                line.transform.localPosition = new Vector3(vb.transform.localPosition.x, line.transform.localPosition.y, line.transform.localPosition.z);
                p1.SetActive(false);
                p2.SetActive(false);
                p3.SetActive(false);
                p4.SetActive(true);
                p5.SetActive(false);
                p6.SetActive(false);
            }

            if (vb.VirtualButtonName == "s5")
            {
                line.transform.localPosition = new Vector3(vb.transform.localPosition.x, line.transform.localPosition.y, line.transform.localPosition.z);
                p1.SetActive(false);
                p2.SetActive(false);
                p3.SetActive(false);
                p4.SetActive(false);
                p5.SetActive(true);
                p6.SetActive(false);
            }

            if (vb.VirtualButtonName == "s6")
            {
                line.transform.localPosition = new Vector3(vb.transform.localPosition.x, line.transform.localPosition.y, line.transform.localPosition.z);
                p1.SetActive(false);
                p2.SetActive(false);
                p3.SetActive(false);
                p4.SetActive(false);
                p5.SetActive(false);
                p6.SetActive(true);
            }
            if (vb.VirtualButtonName == "ss1")
            {
                f = 1;
                line2.transform.localPosition = new Vector3(line2.transform.localPosition.x, line2.transform.localPosition.y, vb.transform.localPosition.z);
            }
            if (vb.VirtualButtonName == "ss2")
            {
                f = 2;
                line2.transform.localPosition = new Vector3(line2.transform.localPosition.x, line2.transform.localPosition.y, vb.transform.localPosition.z);
            }
            if (vb.VirtualButtonName == "ss3")
            {
                f = 3;
                line2.transform.localPosition = new Vector3(line2.transform.localPosition.x, line2.transform.localPosition.y, vb.transform.localPosition.z);
            }
            if (vb.VirtualButtonName == "ss4")
            {
                f = 4;
                line2.transform.localPosition = new Vector3(line2.transform.localPosition.x, line2.transform.localPosition.y, vb.transform.localPosition.z);
            }
            if (vb.VirtualButtonName == "ss5")
            {
                f = 5;
                line2.transform.localPosition = new Vector3(line2.transform.localPosition.x, line2.transform.localPosition.y, vb.transform.localPosition.z);
            }
            if (vb.VirtualButtonName == "ss6")
            {
                f =6;
                line2.transform.localPosition = new Vector3(line2.transform.localPosition.x, line2.transform.localPosition.y, vb.transform.localPosition.z);
            }
            if (vb.VirtualButtonName == "a1")
            {
                f2 = 1;
                line2.transform.localPosition = new Vector3(line2.transform.localPosition.x, line2.transform.localPosition.y, vb.transform.localPosition.z);
            }
            
        }
        else
        {
            if(flag!=8&&flag!=7)
               // p1.SetActive(false);
            p2.SetActive(false);
            p3.SetActive(false);
            p4.SetActive(false);
            p5.SetActive(false);
            p6.SetActive(false);
        }
        if(flag==8)
        {
            //p1.transform.localPosition = new Vector3(-30, 0, 48);
            if (vb.VirtualButtonName == "get")
            {
                cnt++;
                int width = renderTexture.width;
                int height = renderTexture.height;
                Texture2D texture2D = new Texture2D(width, height, TextureFormat.ARGB32, false);
                RenderTexture.active = renderTexture;
                texture2D.ReadPixels(new Rect(0, 0, width, height), 0, 0);
                texture2D.Apply();
                switch(cnt)
                {
                    case 1:
                        img1.GetComponent<RawImage>().texture = texture2D;
                        img1.SetActive(true);
                        break;
                    case 2:
                        img2.GetComponent<RawImage>().texture = texture2D;
                        img2.SetActive(true);
                        break;
                    case 3:
                        img3.GetComponent<RawImage>().texture = texture2D;
                        img3.SetActive(true);
                        break;
                    case 4:
                        img4.GetComponent<RawImage>().texture = texture2D;
                        img4.SetActive(true);
                        break;
                    case 5:
                        img5.GetComponent<RawImage>().texture = texture2D;
                        img5.SetActive(true);
                        break;
                    case 6:
                        img6.GetComponent<RawImage>().texture = texture2D;
                        img6.SetActive(true);
                        break;
                }
            }

        }
        else
        {
           
            if(flag!=8)
            {
                cnt = 0;
               
                //p1.transform.localPosition=new Vector3(0, 4.30000019f, 8.03999996f);
                img1.SetActive(false);
                img2.SetActive(false);
                img3.SetActive(false);
                img4.SetActive(false);
                img5.SetActive(false);
                img6.SetActive(false);
            }
        }
       
    }
    //��ť�ͷ�ʱ
    private void OnButtonReleased(VirtualButtonBehaviour vb)
    {


    }
}
    
    


