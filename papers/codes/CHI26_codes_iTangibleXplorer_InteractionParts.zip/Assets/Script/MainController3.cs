using Vuforia;
using UnityEngine;
using UnityEngine.UI;
using Image = UnityEngine.UI.Image;

public class MainController3 : MonoBehaviour
{
    public GameObject p1, p2, p3, p4, p5, p6;
    public GameObject cut;
    public RenderTexture renderTexture;
    public GameObject img1,img2,img3,img4,img5,img6;
    public GameObject line,line2;
    public GameObject MT, H1, H2, H3,C1,C2,C3;
    VirtualButtonBehaviour[] vbs;
    public int flag,f=0,f2=0;
    int cnt = 0;
    //public Text t;
    private void Start()
    {
        
        vbs = GetComponentsInChildren<VirtualButtonBehaviour>();
        for (int i = 0; i < vbs.Length; i++)
        {
            vbs[i].RegisterOnButtonPressed(OnButtonPressed);
            vbs[i].RegisterOnButtonReleased(OnButtonReleased);
        }
        Debug.Log(vbs.Length);
    }
    void ChangePosition1(float tmp)
    {
        float step = 0.01f;
       

        cut.transform.localPosition = Vector3.MoveTowards(cut.transform.localPosition, new Vector3(0, 0, tmp), step);
      
    }

    private void Update()
    {
        flag =GetComponent<MainController1>().flag;
       if(flag==7)
        {
            if (f == 1)
            {
                ChangePosition1(0.75f);
            }
            if (f == 2)
            {
                ChangePosition1(0.9f);
            }
            if (f == 3)
            {
                ChangePosition1(1.05f);
            }
            if (f == 4)
            {
                ChangePosition1(1.20f);
            }
            if (f == 5)
            {
                ChangePosition1(1.35f);
            }
            if (f == 6)
            {
                ChangePosition1(1.5f);
            }
        }
        if (flag != 8)
        {
            cnt = 0;

            p1.transform.localPosition = new Vector3(0, 4.30000019f, 8.03999996f);
            img1.SetActive(false);
            img2.SetActive(false);
            img3.SetActive(false);
            img4.SetActive(false);
            img5.SetActive(false);
            img6.SetActive(false);
        }
     
    }
    //��ť������ʱ
    private void OnButtonPressed(VirtualButtonBehaviour vb)
    {

        if (flag == 6)
        {

            if (vb.VirtualButtonName == "skin")
            {
                if(H1.activeInHierarchy&& H2.activeInHierarchy)
                {
                    if(!H3.activeInHierarchy)
                    {
                        H3.SetActive(true);
                        C3.SetActive(true);
                    }
                   else
                    {
                        H3.SetActive(false);
                        C3.SetActive(false);
                    }
                }
            }


            if (vb.VirtualButtonName == "vess")
            {
                if (!H1.activeInHierarchy)
                {
                    H1.SetActive(true);
                    C1.SetActive(true);
                }
                else
                {
                    H1.SetActive(false);
                    C1.SetActive(false);
                }
            }

            if (vb.VirtualButtonName == "bone")
            {
                if (!H2.activeInHierarchy)
                {
                    H2.SetActive(true);
                    C2.SetActive(true);
                }
                else
                {
                    H2.SetActive(false);
                    C2.SetActive(false);
                }
            }

        }
        if (flag == 7)
        {
            Debug.Log(vb.VirtualButtonName);
            MT.GetComponent<GestureControl1>().flag = 0;
            if (vb.VirtualButtonName == "s1")
            {
                line.transform.localPosition=new Vector3(vb.transform.localPosition.x, line.transform.localPosition.y, line.transform.localPosition.z);
                p1.SetActive(true);
                p2.SetActive(false);
                p3.SetActive(false);
                p4.SetActive(false);
                p5.SetActive(false);
                p6.SetActive(false);
            }

                
            if (vb.VirtualButtonName == "s2")
            {
                line.transform.localPosition = new Vector3(vb.transform.localPosition.x, line.transform.localPosition.y, line.transform.localPosition.z);
                p1.SetActive(false);
                p2.SetActive(true);
                p3.SetActive(false);
                p4.SetActive(false);
                p5.SetActive(false);
                p6.SetActive(false);
            }

            if (vb.VirtualButtonName == "s3")
            {
                line.transform.localPosition = new Vector3(vb.transform.localPosition.x, line.transform.localPosition.y, line.transform.localPosition.z);
                p1.SetActive(false);
                p2.SetActive(false);
                p3.SetActive(true);
                p4.SetActive(false);
                p5.SetActive(false);
                p6.SetActive(false);
            }

            if (vb.VirtualButtonName == "s4")
            {
                line.transform.localPosition = new Vector3(vb.transform.localPosition.x, line.transform.localPosition.y, line.transform.localPosition.z);
                p1.SetActive(false);
                p2.SetActive(false);
                p3.SetActive(false);
                p4.SetActive(true);
                p5.SetActive(false);
                p6.SetActive(false);
            }

            if (vb.VirtualButtonName == "s5")
            {
                line.transform.localPosition = new Vector3(vb.transform.localPosition.x, line.transform.localPosition.y, line.transform.localPosition.z);
                p1.SetActive(false);
                p2.SetActive(false);
                p3.SetActive(false);
                p4.SetActive(false);
                p5.SetActive(true);
                p6.SetActive(false);
            }

            if (vb.VirtualButtonName == "s6")
            {
                line.transform.localPosition = new Vector3(vb.transform.localPosition.x, line.transform.localPosition.y, line.transform.localPosition.z);
                p1.SetActive(false);
                p2.SetActive(false);
                p3.SetActive(false);
                p4.SetActive(false);
                p5.SetActive(false);
                p6.SetActive(true);
            }
            if (vb.VirtualButtonName == "ss1")
            {
                f = 1;
                line2.transform.localPosition = new Vector3(line2.transform.localPosition.x, line2.transform.localPosition.y, vb.transform.localPosition.z);
            }
            if (vb.VirtualButtonName == "ss2")
            {
                f = 2;
                line2.transform.localPosition = new Vector3(line2.transform.localPosition.x, line2.transform.localPosition.y, vb.transform.localPosition.z);
            }
            if (vb.VirtualButtonName == "ss3")
            {
                f = 3;
                line2.transform.localPosition = new Vector3(line2.transform.localPosition.x, line2.transform.localPosition.y, vb.transform.localPosition.z);
            }
            if (vb.VirtualButtonName == "ss4")
            {
                f = 4;
                line2.transform.localPosition = new Vector3(line2.transform.localPosition.x, line2.transform.localPosition.y, vb.transform.localPosition.z);
            }
            if (vb.VirtualButtonName == "ss5")
            {
                f = 5;
                line2.transform.localPosition = new Vector3(line2.transform.localPosition.x, line2.transform.localPosition.y, vb.transform.localPosition.z);
            }
            if (vb.VirtualButtonName == "ss6")
            {
                f =6;
                line2.transform.localPosition = new Vector3(line2.transform.localPosition.x, line2.transform.localPosition.y, vb.transform.localPosition.z);
            }


        }
        else
        {
            if(flag!=8&&flag!=7)
               // p1.SetActive(false);
            p2.SetActive(false);
            p3.SetActive(false);
            p4.SetActive(false);
            p5.SetActive(false);
            p6.SetActive(false);
        }
        if(flag==8)
        {
            MT.GetComponent<GestureControl1>().flag =0;
            //p1.transform.localPosition = new Vector3(-30, 0, 48);
            if (vb.VirtualButtonName == "get")
            {
                cnt++;
                int width = renderTexture.width;
                int height = renderTexture.height;
                Texture2D texture2D = new Texture2D(width, height, TextureFormat.ARGB32, false);
                RenderTexture.active = renderTexture;
                texture2D.ReadPixels(new Rect(0, 0, width, height), 0, 0);
                texture2D.Apply();
                switch(cnt)
                {
                    case 1:
                        img1.GetComponent<RawImage>().texture = texture2D;
                        img1.SetActive(true);
                        break;
                    case 2:
                        img2.GetComponent<RawImage>().texture = texture2D;
                        img2.SetActive(true);
                        break;
                    case 3:
                        img3.GetComponent<RawImage>().texture = texture2D;
                        img3.SetActive(true);
                        break;
                    case 4:
                        img4.GetComponent<RawImage>().texture = texture2D;
                        img4.SetActive(true);
                        break;
                    case 5:
                        img5.GetComponent<RawImage>().texture = texture2D;
                        img5.SetActive(true);
                        break;
                    case 6:
                        img6.GetComponent<RawImage>().texture = texture2D;
                        img6.SetActive(true);
                        break;
                }
            }

        }
        else
        {
           
            if(flag!=8)
            {
                cnt = 0;
               
                //p1.transform.localPosition=new Vector3(0, 4.30000019f, 8.03999996f);
                img1.SetActive(false);
                img2.SetActive(false);
                img3.SetActive(false);
                img4.SetActive(false);
                img5.SetActive(false);
                img6.SetActive(false);
            }
        }
       
    }
    //��ť�ͷ�ʱ
    private void OnButtonReleased(VirtualButtonBehaviour vb)
    {


    }
}
    
    


