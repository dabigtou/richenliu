using UnityEngine;
using UnityEngine.UI; // ����UI�����ռ�����Slider
using Vuforia;

public class SlicingSider : MonoBehaviour
{
    [Header("=== ������� ===")]
    public GameObject excluder;
    public Camera ARcamera;
    public GameObject Xline, Yline, Zline;

    [Header("=== Inspector�ֶ����ڻ��� ===")]
    [Tooltip("����excluder��X��λ��")]
    public Slider xPositionSlider;
    [Tooltip("����excluder��Y��λ��")]
    public Slider yPositionSlider;
    [Tooltip("����excluder��Z��λ��")]
    public Slider zPositionSlider;

    [Header("=== ���ⰴť ===")]
    public VirtualButtonBehaviour btx2;
    public VirtualButtonBehaviour btx3;
    public VirtualButtonBehaviour btx4;
    public VirtualButtonBehaviour btx5;
    public VirtualButtonBehaviour btx6;
    public VirtualButtonBehaviour btx7;
    public VirtualButtonBehaviour btx8;
    public VirtualButtonBehaviour bty1;
    public VirtualButtonBehaviour bty2;
    public VirtualButtonBehaviour bty3;
    public VirtualButtonBehaviour bty4;
    public VirtualButtonBehaviour bty5;

    [Header("=== λ�õ��ڷ�Χ ===")]
    public float minX = -1f;
    public float maxX = 1f;
    public float minY = -1f;
    public float maxY = 1f;
    public float minZ = -1f;
    public float maxZ = 1f;

    private Vector3 initiallocalPosition;
    private Vector3 initiallocalX;
    public float distanceThreshold = 5f;

    // ���ڸ��ٵ�ǰ�Ƿ�����ͨ����ť����λ��
    private bool isButtonControlling = false;

    float time = 0;
    int cnt = 0;
    float ans = 100f;
    public TMPro.TextMeshProUGUI text;

    public void press_btn()
    {
        time = 0;
    }

    void Start()
    {
        RegisterButtonEvents();

        // ��ʼ��λ��
        initiallocalPosition = excluder.transform.localPosition;
        initiallocalX = Yline.transform.localPosition;

        // ��ʼ������
        InitializeSliders();

        // ��ʼ״̬
        Xline.SetActive(true);
        Yline.SetActive(true);
        Zline.SetActive(false);
    }

    private void Update()
    {
        CheckDistance();

        // ������ǰ�ť����״̬����Ӧ�û����ֵ
        if (!isButtonControlling)
        {
            ApplySliderValues();
        }
    }

    /// <summary>
    /// ��ʼ���������
    /// </summary>
    private void InitializeSliders()
    {
        if (xPositionSlider != null)
        {
            xPositionSlider.minValue = minX;
            xPositionSlider.maxValue = maxX;
            xPositionSlider.value = excluder.transform.localPosition.x;
            xPositionSlider.onValueChanged.AddListener(OnXSliderChanged);
        }

        if (yPositionSlider != null)
        {
            yPositionSlider.minValue = minY;
            yPositionSlider.maxValue = maxY;
            yPositionSlider.value = excluder.transform.localPosition.y;
            yPositionSlider.onValueChanged.AddListener(OnYSliderChanged);
        }

        if (zPositionSlider != null)
        {
            zPositionSlider.minValue = minZ;
            zPositionSlider.maxValue = maxZ;
            zPositionSlider.value = excluder.transform.localPosition.z;
            zPositionSlider.onValueChanged.AddListener(OnZSliderChanged);
        }
    }

    /// <summary>
    /// X�Ử��ֵ�ı��¼�
    /// </summary>
    private void OnXSliderChanged(float value)
    {
        if (!isButtonControlling)
        {
            Vector3 newPosition = excluder.transform.localPosition;
            newPosition.x = value;
            excluder.transform.localPosition = newPosition;

            // ͬʱ����Xline��λ��
            Vector3 linePos = Xline.transform.localPosition;
            linePos.x = value;
            Xline.transform.localPosition = linePos;
        }
    }

    /// <summary>
    /// Y�Ử��ֵ�ı��¼�
    /// </summary>
    private void OnYSliderChanged(float value)
    {
        if (!isButtonControlling)
        {
            Vector3 newPosition = excluder.transform.localPosition;
            newPosition.y = value;
            excluder.transform.localPosition = newPosition;
        }
    }

    /// <summary>
    /// Z�Ử��ֵ�ı��¼�
    /// </summary>
    private void OnZSliderChanged(float value)
    {
        if (!isButtonControlling)
        {
            Vector3 newPosition = excluder.transform.localPosition;
            newPosition.z = value;
            excluder.transform.localPosition = newPosition;

            // ͬʱ����Yline��λ��
            Vector3 linePos = Yline.transform.localPosition;
            linePos.z = value;
            Yline.transform.localPosition = linePos;
        }
    }

    /// <summary>
    /// Ӧ�û���ֵ��excluder
    /// </summary>
    private void ApplySliderValues()
    {
        if (xPositionSlider != null)
        {
            Vector3 newPosition = excluder.transform.localPosition;
            newPosition.x = xPositionSlider.value;
            excluder.transform.localPosition = newPosition;
        }
    }

    /// <summary>
    /// ���»�����ʾֵ���������¼���
    /// </summary>
    private void UpdateSlidersWithoutNotify()
    {
        if (xPositionSlider != null)
            xPositionSlider.SetValueWithoutNotify(excluder.transform.localPosition.x);
        if (yPositionSlider != null)
            yPositionSlider.SetValueWithoutNotify(excluder.transform.localPosition.y);
        if (zPositionSlider != null)
            zPositionSlider.SetValueWithoutNotify(excluder.transform.localPosition.z);
    }

    private void RegisterButtonEvents()
    {
        VirtualButtonBehaviour[] buttons = {
            btx2, btx3, btx4, btx5, btx6, btx7, btx8, bty1, bty2,
            bty3, bty4, bty5
        };

        foreach (var button in buttons)
        {
            button.RegisterOnButtonPressed(OnButtonPressed);
            button.RegisterOnButtonReleased(OnButtonReleased);
        }
    }

    private void CheckDistance()
    {
        float distance = Vector3.Distance(transform.position, ARcamera.transform.position);

        if (distance >= 2.7f && distance <= 4.2f)
        {
            double realtime_y = initiallocalPosition.y - (distance - 2.7) / 1.5 * 0.9;

            Vector3 presentPositionY = new Vector3(excluder.transform.localPosition.x, (float)realtime_y, excluder.transform.localPosition.z);
            excluder.transform.localPosition = presentPositionY;

            // ���»�����ʾ
            UpdateSlidersWithoutNotify();
        }
        Debug.Log(distance);
    }

    // ԭ�еİ�ť�����߼����ֲ��䣬ֻ���ӱ�ǿ���
    public void OnButtonPressed(VirtualButtonBehaviour vb)
    {
        // ����Ϊ��ť����ģʽ
        isButtonControlling = true;

        Vector3 presentPositionX = new Vector3(initiallocalPosition.x, excluder.transform.localPosition.y, excluder.transform.localPosition.z);
        Vector3 presentPositionY = new Vector3(excluder.transform.localPosition.x, initiallocalPosition.y, excluder.transform.localPosition.z);
        Vector3 presentPositionZ = new Vector3(excluder.transform.localPosition.x, excluder.transform.localPosition.y, initiallocalPosition.z);
        Vector3 currentPositionX = Xline.transform.localPosition;
        Vector3 currentPositionY = Yline.transform.localPosition;
        currentPositionY.x = initiallocalX.x;

        switch (vb.VirtualButtonName)
        {
            case "btx2":
                excluder.transform.localPosition = presentPositionX + new Vector3(0f, 0.0f, 0.0f);
                currentPositionX.x = btx2.transform.localPosition.x;
                Xline.transform.localPosition = currentPositionX;
                Debug.Log("btx2");
                break;
            case "btx3":
                excluder.transform.localPosition = presentPositionX + new Vector3(0.15f, 0.0f, 0.0f);
                currentPositionX.x = btx3.transform.localPosition.x;
                Xline.transform.localPosition = currentPositionX;
                Debug.Log("btx3");
                break;
            case "btx4":
                excluder.transform.localPosition = presentPositionX + new Vector3(0.3f, 0.0f, 0.0f);
                currentPositionX.x = btx4.transform.localPosition.x;
                Xline.transform.localPosition = currentPositionX;
                Debug.Log("btx4");
                break;
            case "btx5":
                excluder.transform.localPosition = presentPositionX + new Vector3(0.45f, 0.0f, 0.0f);
                currentPositionX.x = btx5.transform.localPosition.x;
                Xline.transform.localPosition = currentPositionX;
                Debug.Log("btx5");
                cnt++;
                break;
            case "btx6":
                excluder.transform.localPosition = presentPositionX + new Vector3(0.6f, 0.0f, 0.0f);
                currentPositionX.x = btx6.transform.localPosition.x;
                Xline.transform.localPosition = currentPositionX;
                Debug.Log("btx6");
                break;
            case "btx7":
                excluder.transform.localPosition = presentPositionX + new Vector3(0.75f, 0.0f, 0.0f);
                currentPositionX.x = btx7.transform.localPosition.x;
                Xline.transform.localPosition = currentPositionX;
                Debug.Log("btx7");
                break;
            case "btx8":
                excluder.transform.localPosition = presentPositionX + new Vector3(0.9f, 0.0f, 0.0f);
                currentPositionX.x = btx8.transform.localPosition.x;
                Xline.transform.localPosition = currentPositionX;
                Debug.Log("btx8");
                break;
            case "bty1":
                excluder.transform.localPosition = presentPositionZ + new Vector3(0.0f, 0.0f, 0.0f);
                currentPositionY.z = bty1.transform.localPosition.z;
                Yline.transform.localPosition = currentPositionY;
                Debug.Log("bty1");
                break;
            case "bty2":
                excluder.transform.localPosition = presentPositionZ + new Vector3(0.0f, 0.0f, 0.225f);
                currentPositionY.z = bty2.transform.localPosition.z;
                Yline.transform.localPosition = currentPositionY;
                Debug.Log("bty2");
                break;
            case "bty3":
                excluder.transform.localPosition = presentPositionZ + new Vector3(0.0f, 0.0f, 0.45f);
                currentPositionY.z = bty3.transform.localPosition.z;
                Yline.transform.localPosition = currentPositionY;
                Debug.Log("bty3");
                break;
            case "bty4":
                excluder.transform.localPosition = presentPositionZ + new Vector3(0.0f, 0.0f, 0.675f);
                currentPositionY.z = bty4.transform.localPosition.z;
                Yline.transform.localPosition = currentPositionY;
                Debug.Log("bty4");
                break;
            case "bty5":
                excluder.transform.localPosition = presentPositionZ + new Vector3(0.0f, 0.0f, 0.9f);
                currentPositionY.z = bty5.transform.localPosition.z;
                Yline.transform.localPosition = currentPositionY;
                Debug.Log("bty5");
                break;
        }

        // ���»�����ʾ
        UpdateSlidersWithoutNotify();
    }

    public void OnButtonReleased(VirtualButtonBehaviour vb)
    {
        // ��ť�ͷź󣬻ָ��������
        isButtonControlling = false;
    }

    // ����ԭ�з������ֲ���...
    private void DisableAllButtons()
    {
        VirtualButtonBehaviour[] buttons = {
            btx2, btx3, btx4, btx5, btx6, btx7, btx8, bty1, bty2,
            bty3, bty4, bty5
        };

        foreach (var button in buttons)
        {
            button.enabled = false;
            button.gameObject.SetActive(false);
        }
    }

    private void SetButtonState(VirtualButtonBehaviour[] buttons, bool state)
    {
        foreach (var button in buttons)
        {
            button.enabled = state;
            button.gameObject.SetActive(state);
        }
    }

    private void EnableHorizontalButtons()
    {
        SetButtonState(new[] { btx2, btx3, btx4, btx5, btx6, btx7 }, true);
        SetButtonState(new[] { btx8, bty1, bty2, bty3, bty4, bty5 }, false);
        Zline.SetActive(false);
        Xline.SetActive(true);
        Yline.SetActive(false);
    }

    private void EnableVerticalButtons()
    {
        SetButtonState(new[] { btx8, bty1, bty2, bty3, bty4, bty5 }, true);
        SetButtonState(new[] { btx2, btx3, btx4, btx5, btx6, btx7 }, false);
        Zline.SetActive(false);
        Xline.SetActive(false);
        Yline.SetActive(true);
    }
}