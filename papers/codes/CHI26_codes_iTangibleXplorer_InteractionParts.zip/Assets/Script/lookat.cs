using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class lookat : MonoBehaviour
{
    public GameObject lookatPrefab;
    public GameObject Target;
    public int f=0;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {/*
        Quaternion q = Quaternion.identity;
        q.SetLookRotation(Camera.main.transform.forward, Camera.main.transform.up);
        lookatPrefab.transform.rotation = q;
        */
    }
    public void F()
    {
        lookatPrefab.transform.position = Target.transform.position;
    }
}
