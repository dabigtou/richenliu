using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.UIElements;
using Vuforia;

public class RegistrationSimulator : MonoBehaviour
{
   private TrackableBehaviour mTrackableBehaviour;
    public GameObject targetObject,canvas_loading,canvas_primary; // ��Ҫ�ӳټ���� GameObject
    public UnityEngine.UI.Slider slider;
    public VirtualButtonBehaviour yes,no;
    public GameObject main_controller;
    private bool isTracking = false;
    private bool hasActivated = false; // ��ֹ�ظ�����
    private Dictionary<string, MonoBehaviour> scriptsDict = new Dictionary<string, MonoBehaviour>();

  /*  public VirtualButtonBehaviour nav, sli, fc, his, tf_func, exp, menu, btx2, btx3, btx4,
       btx5, btx6, btx7, btx8, bty1, bty2, bty3, bty4, bty5, btz2, btz3, btz4,
       btz5, btz6, btz7, btz8, bt_rotate, bt_pan, bt_lung, bt_brain, bth_1, bth_2, bth_3, color, pre, alpha, c1, c2, c3, c4, c5, p1, p2
       , p3, p4, p5, a1, a2, a3, a4, a5;*/

    void Start()
    {

   /*     VirtualButtonBehaviour[] vbs ={
           nav, sli, fc, his, tf_func, exp,menu, btx2, btx3, btx4,
        btx5, btx6, btx7, btx8, bty1, bty2, bty3, bty4, bty5, btz2, btz3, btz4,
        btz5, btz6, btz7, btz8,bt_rotate,bt_pan,bt_lung,bt_brain,bth_1,bth_2,bth_3,color,pre,alpha,c1,c2,c3,c4,c5,p1,p2
        ,p3,p4,p5,a1,a2,a3,a4,a5
        };

        foreach (var vb in vbs)
        {
            vb.enabled = false;
            vb.gameObject.SetActive(false);
        }
   */
        // ��ʼ�� TrackableBehaviour ��ע���¼�����
        mTrackableBehaviour =GetComponent<TrackableBehaviour>();
        if (mTrackableBehaviour)
        {
            mTrackableBehaviour.RegisterOnTrackableStatusChanged(OnTrackableStatusChanged);
        }

            targetObject.SetActive(false);
            yes.gameObject.SetActive(true);
            no.gameObject.SetActive(true);
            canvas_loading.gameObject.SetActive(false);
            canvas_primary.gameObject.SetActive(true);
            slider.gameObject.SetActive(false);
            yes.enabled= true;
            no.enabled= true;

        yes.RegisterOnButtonPressed(OnButtonPressed);
        no.RegisterOnButtonPressed(OnButtonPressed);

        MonoBehaviour[] scripts = main_controller.GetComponents<MonoBehaviour>();
        foreach (MonoBehaviour script in scripts)
        {
            if (script != this)
                scriptsDict[script.GetType().Name] = script;
        }

    }

    // �¼������ص����������� Image Target ״̬�仯
    public void OnTrackableStatusChanged(TrackableBehaviour.StatusChangeResult statusChangeResult)
    {
        TrackableBehaviour.Status newStatus = statusChangeResult.NewStatus;
        if (newStatus == TrackableBehaviour.Status.DETECTED || newStatus == TrackableBehaviour.Status.TRACKED)
        {
            if (!isTracking && !hasActivated)
            {
                isTracking = true;
                StartCoroutine(ActivateAfterDelay(5f));
            }
        }
        else
        {
            isTracking = false;
        }
    }

    // Э�̣��ӳټ��� GameObject
    private IEnumerator ActivateAfterDelay(float delay)
    {
        yield return new WaitForSeconds(delay);
        if (isTracking && targetObject != null)
        {
            targetObject.SetActive(true);
            yes.gameObject.SetActive(true);
            no.gameObject.SetActive(true);
            yes.enabled = true;
            no.enabled = true;
            hasActivated = true; // ���Ϊ�Ѽ���
        }
    }

    public void OnButtonPressed(VirtualButtonBehaviour vb)
    {
        switch(vb.VirtualButtonName)
        {
            case "Yes":
                Debug.Log("yes");
                targetObject.SetActive(false);
                yes.gameObject.SetActive(false);
                no.gameObject.SetActive(false);
                canvas_primary.SetActive(false);
                canvas_loading.SetActive(true);
                slider.gameObject.SetActive(true);
                yes.enabled = false;
                no.enabled = false;
                StartSliderTransition();
                break;
        }
    }

    public void OnButtonReleased(VirtualButtonBehaviour vb)
    {

    }

    private void SetallActive(bool state)
    {
        VirtualButtonBehaviour[] buttons = {
   yes,no
        };

        foreach (var button in buttons)
        {
            button.enabled = state;
            button.gameObject.SetActive(state);
        }

        GameObject[] gameObjects = {  targetObject,canvas_loading,canvas_primary
        };
        foreach (var gameObject in gameObjects)
        {
            gameObject.SetActive(state);
        }

        slider.gameObject.SetActive(state);

    }

    private void SetButtonState(VirtualButtonBehaviour[] buttons, bool state)
    {
        foreach (var button in buttons)
        {
            button.enabled = state;
            button.gameObject.SetActive(state);
        }
    }

    public void StartSliderTransition()
    {
        // �������ʱ�䣬��Χ�� 5 �� 10 ��
        float randomTime = Random.Range(5f, 10f);
        StartCoroutine(TransitionSlider(randomTime));
    }

    // Э�̣����� Slider ��ֵ��ʱ��ƽ���仯
    private IEnumerator TransitionSlider(float duration)
    {
        float elapsedTime = 0f;
        float startValue = slider.minValue;
        float maxValue = slider.maxValue;
        float subMaxValue = maxValue * 0.9f; // �δ�ֵ��Ϊ���ֵ�� 90%���ɵ���

        // ��һ�׶Σ�10-15����ƽ�����ɵ��δ�ֵ
        while (elapsedTime < duration)
        {
            elapsedTime += Time.deltaTime;
            slider.value = Mathf.Lerp(startValue, subMaxValue, elapsedTime / duration);
            yield return null;
        }
        slider.value = subMaxValue; // ȷ����ȷ�ﵽ�δ�ֵ

        // �ڶ��׶Σ�����ȴ� 3-7 ��
        float waitTime = Random.Range(3f, 7f);
        yield return new WaitForSeconds(waitTime);

        // �����׶Σ�ֱ������Ϊ���ֵ
        slider.value = maxValue;

        float thenTime = 2f;
        yield return new WaitForSeconds(thenTime);
        slider.gameObject.SetActive(false);
        canvas_loading.SetActive(false);
        yes.gameObject.SetActive(false);
        yes.enabled = false;

        no.gameObject.SetActive(false);
        no.enabled = false;

        /*     VirtualButtonBehaviour[] vbs ={
                nav, sli, fc, his, tf_func, exp,menu, btx2, btx3, btx4,
             btx5, btx6, btx7, btx8, bty1, bty2, bty3, bty4, bty5, btz2, btz3, btz4,
             btz5, btz6, btz7, btz8,bt_rotate,bt_pan,bt_lung,bt_brain,bth_1,bth_2,bth_3,color,pre,alpha,c1,c2,c3,c4,c5,p1,p2
             ,p3,p4,p5,a1,a2,a3,a4,a5
             };*/

        /*   foreach (var vb in vbs)
           {
               vb.enabled = true;
               vb.gameObject.SetActive(true);
           }*/
        EnableOnlyScript("Main_controller");
    }

    public void EnableScript(string scriptName)
    {
        if (scriptsDict.ContainsKey(scriptName))
            scriptsDict[scriptName].enabled = true;
        else
            Debug.LogWarning($"δ�ҵ��ű�: {scriptName}");
    }

    // ����ָ���ű�
    public void DisableScript(string scriptName)
    {
        if (scriptsDict.ContainsKey(scriptName))
            scriptsDict[scriptName].enabled = false;
        else
            Debug.LogWarning($"δ�ҵ��ű�: {scriptName}");
    }

    // �л�ָ���ű���״̬
    public void ToggleScript(string scriptName)
    {
        if (scriptsDict.ContainsKey(scriptName))
            scriptsDict[scriptName].enabled = !scriptsDict[scriptName].enabled;
        else
            Debug.LogWarning($"δ�ҵ��ű�: {scriptName}");
    }

    public void EnableOnlyScript(string scriptName)
    {
        DisableScript("Test");
        DisableScript("Main_controller");
        EnableScript(scriptName);
    }


}