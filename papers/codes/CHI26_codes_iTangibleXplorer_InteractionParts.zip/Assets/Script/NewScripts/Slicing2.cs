using UnityEngine;
using Vuforia;
public class Slicing2 : MonoBehaviour
{
    public GameObject excluder;
    public Camera ARcamera;
    public GameObject Xline, Yline, Zline; // ���� Xline, Yline, Zline
    public VirtualButtonBehaviour btx2;
    public VirtualButtonBehaviour btx3;
    public VirtualButtonBehaviour btx4;
    public VirtualButtonBehaviour btx5;
    public VirtualButtonBehaviour btx6;
    public VirtualButtonBehaviour btx7;
    public VirtualButtonBehaviour btx8;
    public VirtualButtonBehaviour bty1;
    public VirtualButtonBehaviour bty2;
    public VirtualButtonBehaviour bty3;
    public VirtualButtonBehaviour bty4;
    public VirtualButtonBehaviour bty5;
    private Vector3 initiallocalPosition;
    private Vector3 initiallocalX;
    // private Vector3 initialXlinePos, initialYlinePos, initialZlinePos; // �洢�����ĳ�ʼ localPosition
    private TrackableBehaviour mTrackableBehaviour;
    public float distanceThreshold = 5f;

    float time = 0;
    int cnt = 0;
    float ans = 100f;
    public TMPro.TextMeshProUGUI text;

    public void press_btn()
    {
        time = 0;
    }

    void Start()
    {
        // mTrackableBehaviour = GetComponent<TrackableBehaviour>();
        // if (mTrackableBehaviour)
        // {
        //    mTrackableBehaviour.RegisterOnTrackableStatusChanged(OnTrackableStatusChanged);
        // }

        RegisterButtonEvents();

        // �洢��ʼ��ת�������� localPosition
        initiallocalPosition = excluder.transform.localPosition;
        initiallocalX=Yline.transform.localPosition;
        //  initialXlinePos = Xline.transform.localPosition;
        //  initialYlinePos = Yline.transform.localPosition;
        //  initialZlinePos = Zline.transform.localPosition;

        // ��ʼ�������ͽ��ð�ť
        Xline.SetActive(true);
        Yline.SetActive(true);
        Zline.SetActive(false);
       // DisableAllButtons();
        //InvokeRepeating("LogEulerAngles", 0f, 5f);
    }

    private void Update()
    {
        if (cnt > 0)
        {
            ans = Mathf.Min(ans, time);
            //Debug.Log("Time = " + time);
            text.text = "Time = " + ans;

        }
        //Debug.Log(excluder_z.transform.localPosition.z);
        time += Time.deltaTime;
        CheckDistance();

    }

    //  void LogEulerAngles()
    //{
    // ��ȡ�����ŷ����
    //  Vector3 eulerAngles = transform.eulerAngles;

    // ���ŷ���ǵ�����̨
    //Debug.Log("Euler Angles: " + eulerAngles);
    // }

    public void OnTrackableStatusChanged(TrackableBehaviour.StatusChangeResult statusChangeResult)
    {
        TrackableBehaviour.Status newStatus = statusChangeResult.NewStatus;
        if (newStatus == TrackableBehaviour.Status.DETECTED || newStatus == TrackableBehaviour.Status.TRACKED)
        {
            CheckDistance();
        }
    }

    private void RegisterButtonEvents()
    {
        VirtualButtonBehaviour[] buttons = {
            btx2, btx3, btx4, btx5, btx6, btx7, btx8, bty1, bty2,
            bty3, bty4, bty5
        };

        foreach (var button in buttons)
        {
            button.RegisterOnButtonPressed(OnButtonPressed);
            button.RegisterOnButtonReleased(OnButtonReleased);
        }
    }

    private void CheckDistance()
    {
        float distance = Vector3.Distance(transform.position, ARcamera.transform.position);

        if (distance >= 2.7f && distance <= 4.2f)
        {
            double realtime_y =  initiallocalPosition.y- (distance - 2.7) / 1.5 * 0.9 ;
          
            Vector3 presentPositionY = new Vector3(excluder.transform.localPosition.x, (float)realtime_y, excluder.transform.localPosition.z);
            excluder.transform.localPosition = presentPositionY;
           
        }

       

      
        //  if (distance > distanceThreshold)
        // {
        //      EnableButtonsForFarDistance();
        // Debug.Log("far");
        //  }
        //  else
        //  {
        //      EnableButtonsForCloseDistance();
        //  Debug.Log("close");
        //  }
        //Debug.Log(distance);
    }

    private void DisableAllButtons()
    {
        VirtualButtonBehaviour[] buttons = {
            btx2, btx3, btx4, btx5, btx6, btx7, btx8, bty1, bty2,
            bty3, bty4, bty5
        };

        foreach (var button in buttons)
        {
            button.enabled = false;
            button.gameObject.SetActive(false);
        }
    }
    //X����z����y��С
    public void OnButtonPressed(VirtualButtonBehaviour vb)
    {
        Vector3 presentPositionX = new Vector3(initiallocalPosition.x, excluder.transform.localPosition.y, excluder.transform.localPosition.z);
        Vector3 presentPositionY = new Vector3(excluder.transform.localPosition.x, initiallocalPosition.y, excluder.transform.localPosition.z);
        Vector3 presentPositionZ = new Vector3(excluder.transform.localPosition.x, excluder.transform.localPosition.y, initiallocalPosition.z);
        Vector3 currentPositionX = Xline.transform.localPosition;
        Vector3 currentPositionY = Yline.transform.localPosition;
        currentPositionY.x = initiallocalX.x;

        switch (vb.VirtualButtonName)
        {
            case "btx2":
                excluder.transform.localPosition = presentPositionX + new Vector3(0f, 0.0f, 0.0f);
                currentPositionX.x = btx2.transform.localPosition.x;
                Xline.transform.localPosition = currentPositionX;
                Debug.Log("btx2");
                break;
            case "btx3":
                excluder.transform.localPosition = presentPositionX + new Vector3(0.15f, 0.0f, 0.0f);
                currentPositionX.x = btx3.transform.localPosition.x;
                Xline.transform.localPosition = currentPositionX;
                Debug.Log("btx3");
                break;
            case "btx4":
                excluder.transform.localPosition = presentPositionX + new Vector3(0.3f, 0.0f, 0.0f);
                currentPositionX.x = btx4.transform.localPosition.x;
                Xline.transform.localPosition = currentPositionX;
                Debug.Log("btx4");
                break;
            case "btx5":
                excluder.transform.localPosition = presentPositionX + new Vector3(0.45f, 0.0f, 0.0f);
                currentPositionX.x = btx5.transform.localPosition.x;
                Xline.transform.localPosition = currentPositionX;
                Debug.Log("btx5");
                cnt++;
                break;
            case "btx6":
                excluder.transform.localPosition = presentPositionX + new Vector3(0.6f, 0.0f, 0.0f);
                currentPositionX.x = btx6.transform.localPosition.x;
                Xline.transform.localPosition = currentPositionX;
                Debug.Log("btx6");
                break;
            case "btx7":
                excluder.transform.localPosition = presentPositionX + new Vector3(0.75f, 0.0f, 0.0f);
                currentPositionX.x = btx7.transform.localPosition.x;
                Xline.transform.localPosition = currentPositionX;
                Debug.Log("btx7");
                break;
            case "btx8":
                excluder.transform.localPosition = presentPositionX + new Vector3(0.9f, 0.0f, 0.0f);
                currentPositionX.x = btx8.transform.localPosition.x;
                Xline.transform.localPosition = currentPositionX;
                Debug.Log("btx8");
                break;
            case "bty1":
                excluder.transform.localPosition = presentPositionZ + new Vector3(0.0f, 0.0f, 0.0f);
                currentPositionY.z = bty1.transform.localPosition.z;
                Yline.transform.localPosition = currentPositionY;
                Debug.Log("bty1");
                break;
            case "bty2":
                excluder.transform.localPosition = presentPositionZ + new Vector3(0.0f, 0.0f, 0.225f);
                currentPositionY.z = bty2.transform.localPosition.z;
                Yline.transform.localPosition = currentPositionY;
                Debug.Log("bty2");
                break;
            case "bty3":
                excluder.transform.localPosition = presentPositionZ + new Vector3(0.0f, 0.0f, 0.45f);
                currentPositionY.z = bty3.transform.localPosition.z;
                Yline.transform.localPosition = currentPositionY;
                Debug.Log("bty3");
                break;
            case "bty4":
                excluder.transform.localPosition = presentPositionZ + new Vector3(0.0f, 0.0f, 0.675f);
                currentPositionY.z = bty4.transform.localPosition.z;
                Yline.transform.localPosition = currentPositionY;
                Debug.Log("bty4");
                break;
            case "bty5":
                excluder.transform.localPosition = presentPositionZ + new Vector3(0.0f, 0.0f, 0.9f);
                currentPositionY.z = bty5.transform.localPosition.z;
                Yline.transform.localPosition = currentPositionY;
                Debug.Log("bty5");
                break;

        }
    }

    public void OnButtonReleased(VirtualButtonBehaviour vb)
    {
        // �ɸ�����Ҫ�����߼�
    }
    private void SetButtonState(VirtualButtonBehaviour[] buttons, bool state)
    {
        foreach (var button in buttons)
        {
            button.enabled = state;
            button.gameObject.SetActive(state);
        }
    }

    private void EnableHorizontalButtons()
    {
        SetButtonState(new[] { btx2, btx3, btx4, btx5, btx6, btx7 }, true);
        SetButtonState(new[] { btx8, bty1, bty2, bty3, bty4, bty5 }, false);
        Zline.SetActive(false);
        Xline.SetActive(true);
        Yline.SetActive(false);
    }

    private void EnableVerticalButtons()
    {
        SetButtonState(new[] { btx8, bty1, bty2, bty3, bty4, bty5 }, true);
        SetButtonState(new[] { btx2, btx3, btx4, btx5, btx6, btx7 }, false);
        Zline.SetActive(false);
        Xline.SetActive(false);
        Yline.SetActive(true);
    }

    /*  private void EnableButtonsForCloseDistance()
      {
          Quaternion currentRotation = transform.rotation;

          float yRotation = currentRotation.eulerAngles.y;

          SetButtonState(new[] { bt13, bt14, bt15, bt16, bt17, bt18 }, false);

          if (yRotation > 180f)
          {
              yRotation -= 360f;
          }

          if (Mathf.Abs(yRotation) <= 45f || Mathf.Abs(yRotation) >= 135f)
          {
              EnableHorizontalButtons();
              // Debug.Log("horizontal");
          }
          else
          {
              EnableVerticalButtons();
              //  Debug.Log("vertical");
          }
      }


  */

}
