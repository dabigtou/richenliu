using UnityEngine;
using Vuforia;
public class NewBehaviourScript : MonoBehaviour
{
    public GameObject excluder;
    public Camera ARcamera;
    public GameObject Xline, Yline, Zline; // ���� Xline, Yline, Zline
    public VirtualButtonBehaviour btx2;
    public VirtualButtonBehaviour btx3;
    public VirtualButtonBehaviour btx4;
    public VirtualButtonBehaviour btx5;
    public VirtualButtonBehaviour btx6;
    public VirtualButtonBehaviour btx7;
    public VirtualButtonBehaviour btx8;
    public VirtualButtonBehaviour bty1;
    public VirtualButtonBehaviour bty2;
    public VirtualButtonBehaviour bty3;
    public VirtualButtonBehaviour bty4;
    public VirtualButtonBehaviour bty5;
    public VirtualButtonBehaviour btz2;
    public VirtualButtonBehaviour btz3;
    public VirtualButtonBehaviour btz4;
    public VirtualButtonBehaviour btz5;
    public VirtualButtonBehaviour btz6;
    public VirtualButtonBehaviour btz7;
    public VirtualButtonBehaviour btz8;

    private Vector3 initialRotation;
    // private Vector3 initialXlinePos, initialYlinePos, initialZlinePos; // �洢�����ĳ�ʼ localPosition
    private TrackableBehaviour mTrackableBehaviour;
    public float distanceThreshold = 5f;

    void Start()
    {
        // mTrackableBehaviour = GetComponent<TrackableBehaviour>();
        // if (mTrackableBehaviour)
        // {
        //    mTrackableBehaviour.RegisterOnTrackableStatusChanged(OnTrackableStatusChanged);
        // }

        RegisterButtonEvents();

        // �洢��ʼ��ת�������� localPosition
        initialRotation = excluder.transform.localEulerAngles;
        //  initialXlinePos = Xline.transform.localPosition;
        //  initialYlinePos = Yline.transform.localPosition;
        //  initialZlinePos = Zline.transform.localPosition;

        // ��ʼ�������ͽ��ð�ť
        Xline.SetActive(false);
        Yline.SetActive(false);
        Zline.SetActive(false);
        DisableAllButtons();
        //InvokeRepeating("LogEulerAngles", 0f, 5f);
    }

    private void Update()
    {
        CheckDistance();

    }

    //  void LogEulerAngles()
    //{
    // ��ȡ�����ŷ����
    //  Vector3 eulerAngles = transform.eulerAngles;

    // ���ŷ���ǵ�����̨
    //Debug.Log("Euler Angles: " + eulerAngles);
    // }

    public void OnTrackableStatusChanged(TrackableBehaviour.StatusChangeResult statusChangeResult)
    {
        TrackableBehaviour.Status newStatus = statusChangeResult.NewStatus;
        if (newStatus == TrackableBehaviour.Status.DETECTED || newStatus == TrackableBehaviour.Status.TRACKED)
        {
            CheckDistance();
        }
    }

    private void RegisterButtonEvents()
    {
        VirtualButtonBehaviour[] buttons = {
            btx2, btx3, btx4, btx5, btx6, btx7, btx8, bty1, bty2,
            bty3, bty4, bty5, btz2, btz3, btz4, btz5, btz6, btz7,btz8
        };

        foreach (var button in buttons)
        {
            button.RegisterOnButtonPressed(OnButtonPressed);
            button.RegisterOnButtonReleased(OnButtonReleased);
        }
    }

    private void CheckDistance()
    {
        float distance = Vector3.Distance(transform.position, ARcamera.transform.position);

        if (distance > distanceThreshold)
        {
            EnableButtonsForFarDistance();
            Debug.Log("far");
        }
        else
        {
            EnableButtonsForCloseDistance();
            Debug.Log("close");
        }
    }

    private void DisableAllButtons()
    {
        VirtualButtonBehaviour[] buttons = {
            btx2, btx3, btx4, btx5, btx6, btx7, btx8, bty1, bty2,
            bty3, bty4, bty5, btz2, btz3, btz4, btz5, btz6, btz7,btz8
        };

        foreach (var button in buttons)
        {
            button.enabled = false;
            button.gameObject.SetActive(false);
        }
    }

    public void OnButtonPressed(VirtualButtonBehaviour vb)
    {
        Vector3 presentPositionX = new Vector3(initialRotation.x, excluder.transform.localPosition.y, excluder.transform.localPosition.z);
        Vector3 presentPositionY = new Vector3(excluder.transform.localPosition.x, initialRotation.y, excluder.transform.localPosition.z);
        Vector3 presentPositionZ = new Vector3(excluder.transform.localPosition.x, excluder.transform.localPosition.y, initialRotation.z);
        Vector3 currentPositionX = Xline.transform.localPosition;
        Vector3 currentPositionY = Yline.transform.localPosition;
        Vector3 currentPositionZ = Zline.transform.localPosition;

        switch (vb.VirtualButtonName)
        {
            case "btx2":
                excluder.transform.localEulerAngles = presentPositionX + new Vector3(0f, 0.0f, 0.0f);
                currentPositionX.x = btx2.transform.localPosition.x;
                Xline.transform.localPosition = currentPositionX;
                Debug.Log("btx2");
                break;
            case "btx3":
                excluder.transform.localEulerAngles = presentPositionX + new Vector3(60f, 0.0f, 0.0f);
                currentPositionX.x = btx3.transform.localPosition.x;
                Xline.transform.localPosition = currentPositionX;
                Debug.Log("btx3");
                break;
            case "btx4":
                excluder.transform.localEulerAngles = presentPositionX + new Vector3(120f, 0.0f, 0.0f);
                currentPositionX.x = btx4.transform.localPosition.x;
                Xline.transform.localPosition = currentPositionX;
                Debug.Log("btx4");
                break;
            case "btx5":
                excluder.transform.localEulerAngles = presentPositionX + new Vector3(180f, 0.0f, 0.0f);
                currentPositionX.x = btx5.transform.localPosition.x;
                Xline.transform.localPosition = currentPositionX;
                Debug.Log("btx5");
                break;
            case "btx6":
                excluder.transform.localEulerAngles = presentPositionX + new Vector3(240f, 0.0f, 0.0f);
                currentPositionX.x = btx6.transform.localPosition.x;
                Xline.transform.localPosition = currentPositionX;
                Debug.Log("btx6");
                break;
            case "btx7":
                excluder.transform.localEulerAngles = presentPositionX + new Vector3(300f, 0.0f, 0.0f);
                currentPositionX.x = btx7.transform.localPosition.x;
                Xline.transform.localPosition = currentPositionX;
                Debug.Log("btx7");
                break;
            case "btx8":
                excluder.transform.localEulerAngles = presentPositionY + new Vector3(360f, 0.0f, 0.0f);
                currentPositionX.x = btx8.transform.localPosition.x;
                Xline.transform.localPosition = currentPositionX;
                Debug.Log("btx8");
                break;
            case "bty1":
                excluder.transform.localEulerAngles = presentPositionY + new Vector3(0.0f, 0.0f, 0.0f);
                currentPositionY.z = bty1.transform.localPosition.z;
                Yline.transform.localPosition = currentPositionY;
                Debug.Log("bty1");
                break;
            case "bty2":
                excluder.transform.localEulerAngles = presentPositionY + new Vector3(0.0f, 72f, 0.0f);
                currentPositionY.z = bty2.transform.localPosition.z;
                Yline.transform.localPosition = currentPositionY;
                Debug.Log("bty2");
                break;
            case "bty3":
                excluder.transform.localEulerAngles = presentPositionY + new Vector3(0.0f, 144f, 0.0f);
                currentPositionY.z = bty3.transform.localPosition.z;
                Yline.transform.localPosition = currentPositionY;
                Debug.Log("bty3");
                break;
            case "bty4":
                excluder.transform.localEulerAngles = presentPositionY + new Vector3(0.0f, 216f, 0.0f);
                currentPositionY.z = bty4.transform.localPosition.z;
                Yline.transform.localPosition = currentPositionY;
                Debug.Log("bty4");
                break;
            case "bty5":
                excluder.transform.localEulerAngles = presentPositionY + new Vector3(0.0f, 288f, 0.0f);
                currentPositionY.z = bty5.transform.localPosition.z;
                Yline.transform.localPosition = currentPositionY;
                Debug.Log("bty5");
                break;
            case "btz2":
                excluder.transform.localEulerAngles = presentPositionZ + new Vector3(0.0f, 0.0f, 0f);
                currentPositionZ.x = btz2.transform.localPosition.x;
                Zline.transform.localPosition = currentPositionZ;
                Debug.Log("btz2");
                break;
            case "btz3":
                excluder.transform.localEulerAngles = presentPositionZ + new Vector3(0.0f, 0.0f, 60f);
                currentPositionZ.x = btz3.transform.localPosition.x;
                Zline.transform.localPosition = currentPositionZ;
                Debug.Log("btz3");
                break;
            case "btz4":
                excluder.transform.localEulerAngles = presentPositionZ + new Vector3(0.0f, 0.0f, 120f);
                currentPositionZ.x = btz4.transform.localPosition.x;
                Zline.transform.localPosition = currentPositionZ;
                Debug.Log("btz4");
                break;
            case "btz5":
                excluder.transform.localEulerAngles = presentPositionZ + new Vector3(0.0f, 0.0f, 180f);
                currentPositionZ.x = btz5.transform.localPosition.x;
                Zline.transform.localPosition = currentPositionZ;
                Debug.Log("btz5");
                break;
            case "btz6":
                excluder.transform.localEulerAngles = presentPositionZ + new Vector3(0.0f, 0.0f, 240f);
                currentPositionZ.x = btz6.transform.localPosition.x;
                Zline.transform.localPosition = currentPositionZ;
                Debug.Log("btz6");
                break;
            case "btz7":
                excluder.transform.localEulerAngles = presentPositionZ + new Vector3(0.0f, 0.0f, 300f);
                currentPositionZ.x = btz7.transform.localPosition.x;
                Zline.transform.localPosition = currentPositionZ;
                Debug.Log("btz7");
                break;
            case "btz8":
                excluder.transform.localEulerAngles = presentPositionZ + new Vector3(0.0f, 0.0f, 360f);
                currentPositionZ.x = btz8.transform.localPosition.x;
                Zline.transform.localPosition = currentPositionZ;
                Debug.Log("btz8");
                break;
        }
    }

    public void OnButtonReleased(VirtualButtonBehaviour vb)
    {
        // �ɸ�����Ҫ�����߼�
    }
    private void SetButtonState(VirtualButtonBehaviour[] buttons, bool state)
    {
        foreach (var button in buttons)
        {
            button.enabled = state;
            button.gameObject.SetActive(state);
        }
    }

    private void EnableHorizontalButtons()
    {
        SetButtonState(new[] { btx2, btx3, btx4, btx5, btx6, btx7 }, true);
        SetButtonState(new[] { btx8, bty1, bty2, bty3, bty4, bty5 }, false);
        Zline.SetActive(false);
        Xline.SetActive(true);
        Yline.SetActive(false);
    }

    private void EnableVerticalButtons()
    {
        SetButtonState(new[] { btx8, bty1, bty2, bty3, bty4, bty5 }, true);
        SetButtonState(new[] { btx2, btx3, btx4, btx5, btx6, btx7 }, false);
        Zline.SetActive(false);
        Xline.SetActive(false);
        Yline.SetActive(true);
    }

    private void EnableButtonsForFarDistance()
    {
        SetButtonState(new[] { btx2, btx3, btx4, btx5, btx6, btx7, btx8, bty1, bty2, bty3, bty4, bty5 }, false);
        SetButtonState(new[] { btz2, btz3, btz4, btz5, btz6, btz7, btz8 }, true);
        Zline.SetActive(true);
        Xline.SetActive(false);
        Yline.SetActive(false);
    }

    private void EnableButtonsForCloseDistance()
    {
        SetButtonState(new[] { btx2, btx3, btx4, btx5, btx6, btx7, btx8, bty1, bty2, bty3, bty4, bty5 }, true);
        SetButtonState(new[] { btz2, btz3, btz4, btz5, btz6, btz7, btz8 }, false);
        Zline.SetActive(false);
        Xline.SetActive(true);
        Yline.SetActive(true);
    }
    /*  private void EnableButtonsForCloseDistance()
      {
          Quaternion currentRotation = transform.rotation;

          float yRotation = currentRotation.eulerAngles.y;

          SetButtonState(new[] { bt13, bt14, bt15, bt16, bt17, bt18 }, false);

          if (yRotation > 180f)
          {
              yRotation -= 360f;
          }

          if (Mathf.Abs(yRotation) <= 45f || Mathf.Abs(yRotation) >= 135f)
          {
              EnableHorizontalButtons();
              // Debug.Log("horizontal");
          }
          else
          {
              EnableVerticalButtons();
              //  Debug.Log("vertical");
          }
      }


  */

}
