using UnityEngine;
using Vuforia;

public class fc_1d : MonoBehaviour
{
    public GameObject magnifier;
    public GameObject Xline, Yline,Zline;
    public GameObject excluder;
    public Camera ARcamera;
    public VirtualButtonBehaviour btx2;
    public VirtualButtonBehaviour btx3;
    public VirtualButtonBehaviour btx4;
    public VirtualButtonBehaviour btx5;
    public VirtualButtonBehaviour btx6;
    public VirtualButtonBehaviour btx7;
    public VirtualButtonBehaviour btx8;
    public VirtualButtonBehaviour bty2;
    public VirtualButtonBehaviour bty3;
    public VirtualButtonBehaviour bty4;
    public VirtualButtonBehaviour bty5,bty6,bty7,bty8,btz2,btz3,btz4,btz5,btz6,btz7,btz8;
    private TrackableBehaviour mTrackableBehaviour;
    private Vector3 initialLocalPosition;
    private Vector3 initialLocalPositionE;
    public float distanceThreshold = 5f;


    public float position_far = 3.5f;
    public float position_near = 2.0f;
    private float fixed_z;
    void Start()
    {
        //  mTrackableBehaviour = GetComponent<TrackableBehaviour>();
        //  if (mTrackableBehaviour)
        //  {
        //      mTrackableBehaviour.RegisterOnTrackableStatusChanged(OnTrackableStatusChanged);
        //  }                //Tracklble �ӿڵ���


        btx2.RegisterOnButtonPressed(OnButtonPressed);
        btx2.RegisterOnButtonReleased(OnButtonReleased);
        btx3.RegisterOnButtonPressed(OnButtonPressed);
        btx3.RegisterOnButtonReleased(OnButtonReleased);
        btx4.RegisterOnButtonPressed(OnButtonPressed);
        btx4.RegisterOnButtonReleased(OnButtonReleased);
        btx5.RegisterOnButtonPressed(OnButtonPressed);
        btx5.RegisterOnButtonReleased(OnButtonReleased);
        btx6.RegisterOnButtonPressed(OnButtonPressed);
        btx6.RegisterOnButtonReleased(OnButtonReleased);
        btx7.RegisterOnButtonPressed(OnButtonPressed);
        btx7.RegisterOnButtonReleased(OnButtonReleased);
        btx8.RegisterOnButtonPressed(OnButtonPressed);
        btx8.RegisterOnButtonReleased(OnButtonReleased);
        bty2.RegisterOnButtonPressed(OnButtonPressed);
        bty2.RegisterOnButtonReleased(OnButtonReleased);
        bty3.RegisterOnButtonPressed(OnButtonPressed);
        bty3.RegisterOnButtonReleased(OnButtonReleased);
        bty4.RegisterOnButtonPressed(OnButtonPressed);
        bty4.RegisterOnButtonReleased(OnButtonReleased);
        bty5.RegisterOnButtonPressed(OnButtonPressed);
        bty5.RegisterOnButtonReleased(OnButtonReleased);
        bty6.RegisterOnButtonPressed(OnButtonPressed);
        bty6.RegisterOnButtonReleased(OnButtonReleased);
        bty7.RegisterOnButtonPressed(OnButtonPressed);
        bty7.RegisterOnButtonReleased(OnButtonReleased);
        bty8.RegisterOnButtonPressed(OnButtonPressed);
        bty8.RegisterOnButtonReleased(OnButtonReleased);
        btz2.RegisterOnButtonPressed(OnButtonPressed);
        btz2.RegisterOnButtonReleased(OnButtonReleased);
        btz3.RegisterOnButtonPressed(OnButtonPressed);
        btz3.RegisterOnButtonReleased(OnButtonReleased);
        btz4.RegisterOnButtonPressed(OnButtonPressed);
        btz4.RegisterOnButtonReleased(OnButtonReleased);
        btz5.RegisterOnButtonPressed(OnButtonPressed);
        btz5.RegisterOnButtonReleased(OnButtonReleased);
        btz6.RegisterOnButtonPressed(OnButtonPressed);
        btz6.RegisterOnButtonReleased(OnButtonReleased);
        btz7.RegisterOnButtonPressed(OnButtonPressed);
        btz7.RegisterOnButtonReleased(OnButtonReleased);
        btz8.RegisterOnButtonPressed(OnButtonPressed);
        btz8.RegisterOnButtonReleased(OnButtonReleased);
        initialLocalPosition = magnifier.transform.localPosition;
        initialLocalPositionE = excluder.transform.localPosition;
        Xline.SetActive(true);
        Yline.SetActive(true);

        fixed_z = excluder.transform.position.z;
    }

    private void Update()
    {
          CheckDistance();
    }
    // x,y������
    /*  private void Update()
      {
          EnableButtonsForCloseDistance();
      }
      public void OnTrackableStatusChanged(TrackableBehaviour.StatusChangeResult statusChangeResult)
      {
          TrackableBehaviour.Status newStatus = statusChangeResult.NewStatus;
          if (newStatus == TrackableBehaviour.Status.DETECTED || newStatus == TrackableBehaviour.Status.TRACKED)
          {
              EnableButtonsForCloseDistance();
          }
      }
    */
    public void OnButtonPressed(VirtualButtonBehaviour vb)
    {
        Vector3 presentLocalPositionX = new Vector3(initialLocalPosition.x, magnifier.transform.localPosition.y, magnifier.transform.localPosition.z);
        Vector3 presentLocalPositionY = new Vector3(magnifier.transform.localPosition.x, initialLocalPosition.y, magnifier.transform.localPosition.z);
        Vector3 presentPositionZ = new Vector3(excluder.transform.localPosition.x, excluder.transform.localPosition.y, initialLocalPositionE.z);
        Vector3 currentPositionX = Xline.transform.localPosition;
        Vector3 currentPositionY = Yline.transform.localPosition;
        Vector3 currentPositionZ = Yline.transform.localPosition;

        switch (vb.VirtualButtonName)
        {

            case "btx2":
                currentPositionX.x = btx2.transform.localPosition.x;
                Xline.transform.localPosition = currentPositionX;
                magnifier.transform.localPosition = presentLocalPositionX + new Vector3(0f, 0.0f, 0.0f);
                Debug.Log("btx2");
                break;
            case "btx3":
                currentPositionX.x = btx3.transform.localPosition.x;
                Xline.transform.localPosition = currentPositionX;
                magnifier.transform.localPosition = presentLocalPositionX + new Vector3(8f, 0.0f, 0.0f);
                Debug.Log("btx3");
                break;
            case "btx4":
                currentPositionX.x = btx4.transform.localPosition.x;
                Xline.transform.localPosition = currentPositionX;
                magnifier.transform.localPosition = presentLocalPositionX + new Vector3(16f, 0.0f, 0.0f);
                Debug.Log("btx4");
                break;
            case "btx5":
                currentPositionX.x = btx5.transform.localPosition.x;
                Xline.transform.localPosition = currentPositionX;
                magnifier.transform.localPosition = presentLocalPositionX + new Vector3(24f, 0.0f, 0.0f);
                Debug.Log("btx5");
                break;
            case "btx6":
                currentPositionX.x = btx6.transform.localPosition.x;
                Xline.transform.localPosition = currentPositionX;
                magnifier.transform.localPosition = presentLocalPositionX + new Vector3(32f, 0.0f, 0.0f);
                Debug.Log("btx6");
                break;
            case "btx7":
                currentPositionX.x = btx7.transform.localPosition.x;
                Xline.transform.localPosition = currentPositionX;
                magnifier.transform.localPosition = presentLocalPositionX + new Vector3(40f, 0.0f, 0.0f);
                Debug.Log("btx7");
                break;
            case "btx8":
                currentPositionX.x = btx8.transform.localPosition.x;
                Xline.transform.localPosition = currentPositionX;
                magnifier.transform.localPosition = presentLocalPositionX + new Vector3(48f, 0.0f, 0.0f);
                Debug.Log("btx8");
                break;

            case "bty2":
                currentPositionY.x = bty2.transform.localPosition.x;
                Yline.transform.localPosition = currentPositionY;
                magnifier.transform.localPosition = presentLocalPositionY + new Vector3(0.0f, 0f, 0.0f);
                Debug.Log("bty2");
                break;

            case "bty3":
                currentPositionY.x = bty3.transform.localPosition.x;
                Yline.transform.localPosition = currentPositionY;
                magnifier.transform.localPosition = presentLocalPositionY + new Vector3(0.0f, 8.6f, 0.0f);
                Debug.Log("bty3");
                break;
            case "bty4":
                currentPositionY.x = bty4.transform.localPosition.x;
                Yline.transform.localPosition = currentPositionY;
                magnifier.transform.localPosition = presentLocalPositionY + new Vector3(0.0f, 17.2f, 0.0f);
                Debug.Log("bty4");
                break;
            case "bty5":
                currentPositionY.x = bty5.transform.localPosition.x;
                Yline.transform.localPosition = currentPositionY;
                magnifier.transform.localPosition = presentLocalPositionY + new Vector3(0.0f,25.8f, 0.0f);
                Debug.Log("bty5");
                break;
            case "bty6":
                currentPositionY.x = bty6.transform.localPosition.x;
                Yline.transform.localPosition = currentPositionY;
                magnifier.transform.localPosition = presentLocalPositionY + new Vector3(0.0f, 34.4f, 0.0f);
                Debug.Log("bty1");
                break;
            case "bty7":
                currentPositionY.x = bty7.transform.localPosition.x;
                Yline.transform.localPosition = currentPositionY;
                magnifier.transform.localPosition = presentLocalPositionY + new Vector3(0.0f, 43f, 0.0f);
                Debug.Log("bty1");
                break;
            case "bty8":
                currentPositionY.x = bty8.transform.localPosition.x;
                Yline.transform.localPosition = currentPositionY;
                magnifier.transform.localPosition = presentLocalPositionY + new Vector3(0.0f, 51.6f, 0.0f);
                Debug.Log("bty1");
                break;
            case "btz2":
                excluder.transform.localPosition = presentPositionZ + new Vector3(0f, 0.0f, 0.0f);
                currentPositionZ.x = btz2.transform.localPosition.x;
                Zline.transform.localPosition = currentPositionZ;
                Debug.Log("btx2");
                break;
            case "btz3":
                excluder.transform.localPosition = presentPositionZ + new Vector3(0f, 0f, 0.1f);
                currentPositionZ.x = btx3.transform.localPosition.x;
                Zline.transform.localPosition = currentPositionZ;
                Debug.Log("btx3");
                break;
            case "btz4":
                excluder.transform.localPosition = presentPositionZ + new Vector3(0f, 0f, 0.2f);
                currentPositionZ.x = btx4.transform.localPosition.x;
                Zline.transform.localPosition = currentPositionZ;
                Debug.Log("btx4");
                break;
            case "btz5":
                excluder.transform.localPosition = presentPositionZ + new Vector3(0f, 0f, 0.3f);
                currentPositionZ.x = btx5.transform.localPosition.x;
                Zline.transform.localPosition = currentPositionZ;
                Debug.Log("btx5");
                break;
            case "btz6":
                excluder.transform.localPosition = presentPositionZ + new Vector3(0f, 0f, 0.4f);
                currentPositionZ.x = btx6.transform.localPosition.x;
                Zline.transform.localPosition = currentPositionZ;
                Debug.Log("btx6");
                break;
            case "btz7":
                excluder.transform.localPosition = presentPositionZ + new Vector3(0f, 0f, 0.5f);
                currentPositionZ.x = btx7.transform.localPosition.x;
                Zline.transform.localPosition = currentPositionZ;
                Debug.Log("btx7");
                break;
            case "btz8":
                excluder.transform.localPosition = presentPositionZ + new Vector3(0f, 0f, 0.6f);
                currentPositionZ.x = btx8.transform.localPosition.x;
                Zline.transform.localPosition = currentPositionZ;
                Debug.Log("btx8");
                break;

        }
    }

    private void CheckDistance()
    {
        float distance = Vector3.Distance(transform.position, ARcamera.transform.position);

        if (distance <= distanceThreshold)
        {
            EnableButtonsForCloseDistance();
            Debug.Log("far");
        }

        else
        {
            EnableButtonsForFarDistance();
            Debug.Log("close");
        }

        //  if (distance > distanceThreshold)
        // {
        //      EnableButtonsForFarDistance();
        // Debug.Log("far");
        //  }
        //  else
        //  {
        //      EnableButtonsForCloseDistance();
        //  Debug.Log("close");
        //  }
        Debug.Log(distance);
    }

    public void OnButtonReleased(VirtualButtonBehaviour vb)
    {
        // Add any functionality needed when a button is released.
    }

    private void SetButtonState(VirtualButtonBehaviour[] buttons, bool state)
    {
        foreach (var button in buttons)
        {
            button.enabled = state;
            button.gameObject.SetActive(state);
        }
    }

    private void EnableHorizontalButtons()
    {
        SetButtonState(new[] { btx2, btx3, btx4, btx5, btx6, btx7, btx8 }, true);
        SetButtonState(new[] {  bty2, bty3, bty4, bty5, bty6, bty7, bty8 }, false);
        Zline.SetActive(false);
        Xline.SetActive(true);
        Yline.SetActive(false);
    }

    private void EnableVerticalButtons()
    {
        SetButtonState(new[] {  bty2, bty3, bty4, bty5, bty6, bty7, bty8 }, true);
        SetButtonState(new[] { btx2, btx3, btx4, btx5, btx6, btx7, btx8  }, false);
        Zline.SetActive(false);
        Xline.SetActive(false);
        Yline.SetActive(true);
    }


    private void EnableButtonsForFarDistance()
    {
        SetButtonState(new[] { btx2, btx3, btx4, btx5, btx6, btx7, btx8,bty2, bty3, bty4, bty5 }, false);
        SetButtonState(new[] { btz2, btz3, btz4, btz5, btz6, btz7, btz8 , bty6, bty7, bty8 }, true);
        Zline.SetActive(true);
        Xline.SetActive(false);
        Yline.SetActive(false);
        Debug.Log("far");
    }

    private void EnableButtonsForCloseDistance()
    {
        Quaternion currentRotation = transform.rotation;

        float yRotation = currentRotation.eulerAngles.y;

        SetButtonState(new[] { btz2, btz3, btz4, btz5, btz6, btz7, btz8 }, false);

        if (yRotation > 180f)
        {
            yRotation -= 360f;
        }

        if (Mathf.Abs(yRotation) <= 45f || Mathf.Abs(yRotation) >= 135f)
        {
            EnableHorizontalButtons();
            Debug.Log("horizontal");
        }
        else
        {
            EnableVerticalButtons();
             Debug.Log("vertical");
        }
    }
}

