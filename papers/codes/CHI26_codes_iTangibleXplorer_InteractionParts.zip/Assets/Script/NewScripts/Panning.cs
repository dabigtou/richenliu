using UnityEngine;
using UnityEngine.UI;
using Vuforia;

public class Panning : MonoBehaviour
{
    
    public GameObject canvas;
  //  private TrackableBehaviour trackableBehaviour;

   void Update()
    {
        canvas.transform.position = transform.position;
    }

    
}
