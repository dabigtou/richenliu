using UnityEngine;
using Vuforia;
public class slicing_3d_top : MonoBehaviour
{
    public GameObject excluder;
    public Camera ARcamera;
    public GameObject Zline; // ���� Xline, Yline, Zline
    public VirtualButtonBehaviour btx2;
    public VirtualButtonBehaviour btx3;
    public VirtualButtonBehaviour btx4;
    public VirtualButtonBehaviour btx5;
    public VirtualButtonBehaviour btx6;
    public VirtualButtonBehaviour btx7;
    public VirtualButtonBehaviour btx8;
    public VirtualButtonBehaviour bty1;
    public VirtualButtonBehaviour bty2;
    public VirtualButtonBehaviour bty3;
    public VirtualButtonBehaviour bty4;
    public VirtualButtonBehaviour bty5;
    private Vector3 initiallocalPosition;
    private Vector3 initiallocalX;
    // private Vector3 initialXlinePos, initialYlinePos, initialZlinePos; // �洢�����ĳ�ʼ localPosition
    private TrackableBehaviour mTrackableBehaviour;
    public float distanceThreshold = 5f;

    void Start()
    {
        // mTrackableBehaviour = GetComponent<TrackableBehaviour>();
        // if (mTrackableBehaviour)
        // {
        //    mTrackableBehaviour.RegisterOnTrackableStatusChanged(OnTrackableStatusChanged);
        // }

        RegisterButtonEvents();

        // �洢��ʼ��ת�������� localPosition
        initiallocalPosition = excluder.transform.localPosition;
        //  initialXlinePos = Xline.transform.localPosition;
        //  initialYlinePos = Yline.transform.localPosition;
        //  initialZlinePos = Zline.transform.localPosition;

        // ��ʼ�������ͽ��ð�ť
        Zline.SetActive(true);
        // DisableAllButtons();
        //InvokeRepeating("LogEulerAngles", 0f, 5f);
    }


    //  void LogEulerAngles()
    //{
    // ��ȡ�����ŷ����
    //  Vector3 eulerAngles = transform.eulerAngles;

    // ���ŷ���ǵ�����̨
    //Debug.Log("Euler Angles: " + eulerAngles);
    // }


    private void RegisterButtonEvents()
    {
        VirtualButtonBehaviour[] buttons = {
            btx2, btx3, btx4, btx5, btx6, btx7, btx8, bty1, bty2,
            bty3, bty4, bty5
        };

        foreach (var button in buttons)
        {
            button.RegisterOnButtonPressed(OnButtonPressed);
            button.RegisterOnButtonReleased(OnButtonReleased);
        }
    }

    private void CheckDistance()
    {
        float distance = Vector3.Distance(transform.position, ARcamera.transform.position);

        if (distance >= 2.7f && distance <= 4.2f)
        {
            double realtime_y = initiallocalPosition.y - (distance - 2.7) / 1.5 * 0.9;

            Vector3 presentPositionY = new Vector3(excluder.transform.localPosition.x, (float)realtime_y, excluder.transform.localPosition.z);
            excluder.transform.localPosition = presentPositionY;

        }


        //  if (distance > distanceThreshold)
        // {
        //      EnableButtonsForFarDistance();
        // Debug.Log("far");
        //  }
        //  else
        //  {
        //      EnableButtonsForCloseDistance();
        //  Debug.Log("close");
        //  }
        Debug.Log(distance);
    }

    private void DisableAllButtons()
    {
        VirtualButtonBehaviour[] buttons = {
            btx2, btx3, btx4, btx5, btx6, btx7, btx8, bty1, bty2,
            bty3, bty4, bty5
        };

        foreach (var button in buttons)
        {
            button.enabled = false;
            button.gameObject.SetActive(false);
        }
    }
    //X����z����y��С
    public void OnButtonPressed(VirtualButtonBehaviour vb)
    {
        Vector3 presentPositionXE = new Vector3(initiallocalPosition.x, excluder.transform.localPosition.y, excluder.transform.localPosition.z);
        Vector3 presentPositionYE = new Vector3(excluder.transform.localPosition.x, initiallocalPosition.y, excluder.transform.localPosition.z);
        Vector3 presentPositionZ = new Vector3(excluder.transform.localPosition.x, excluder.transform.localPosition.y, initiallocalPosition.z);
        Vector3 currentPositionZ = Zline.transform.localPosition;

        switch (vb.VirtualButtonName)
        {
            case "btx2":
                excluder.transform.localPosition = presentPositionYE + new Vector3(0f, 0.0f, 0.0f);
                currentPositionZ.z = btx2.transform.localPosition.z;
                Zline.transform.localPosition = currentPositionZ;
                Debug.Log("btx2");
                break;
            case "btx3":
                excluder.transform.localPosition = presentPositionYE + new Vector3(0f, -0.15f, 0f);
                currentPositionZ.z = btx3.transform.localPosition.z;
                Zline.transform.localPosition = currentPositionZ;
                Debug.Log("btx3");
                break;
            case "btx4":
                excluder.transform.localPosition = presentPositionYE + new Vector3(0f, -0.3f, 0f);
                currentPositionZ.z = btx4.transform.localPosition.z;
                Zline.transform.localPosition = currentPositionZ;
                Debug.Log("btx4");
                break;
            case "btx5":
                excluder.transform.localPosition = presentPositionYE + new Vector3(0f, -0.45f, 0f);
                currentPositionZ.z = btx5.transform.localPosition.z;
                Zline.transform.localPosition = currentPositionZ;
                Debug.Log("btx5");
                break;
            case "btx6":
                excluder.transform.localPosition = presentPositionYE + new Vector3(0f, -0.6f, 0f);
                currentPositionZ.z = btx6.transform.localPosition.z;
                Zline.transform.localPosition = currentPositionZ;
                Debug.Log("btx6");
                break;
            case "btx7":
                excluder.transform.localPosition = presentPositionYE + new Vector3(0f, -0.75f, 0f);
                currentPositionZ.z = btx7.transform.localPosition.z;
                Zline.transform.localPosition = currentPositionZ;
                Debug.Log("btx7");
                break;
            case "btx8":
                excluder.transform.localPosition = presentPositionYE + new Vector3(0f, -0.9f, 0f);
                currentPositionZ.z = btx8.transform.localPosition.z;
                Zline.transform.localPosition = currentPositionZ;
                Debug.Log("btx8");
                break;
          

        }
    }

    public void OnButtonReleased(VirtualButtonBehaviour vb)
    {
        // �ɸ�����Ҫ�����߼�
    }
    private void SetButtonState(VirtualButtonBehaviour[] buttons, bool state)
    {
        foreach (var button in buttons)
        {
            button.enabled = state;
            button.gameObject.SetActive(state);
        }
    }

    private void EnableHorizontalButtons()
    {
        SetButtonState(new[] { btx2, btx3, btx4, btx5, btx6, btx7 }, true);
        SetButtonState(new[] { btx8, bty1, bty2, bty3, bty4, bty5 }, false);
        Zline.SetActive(true);
    }

    private void EnableVerticalButtons()
    {
        SetButtonState(new[] { btx8, bty1, bty2, bty3, bty4, bty5 }, true);
        SetButtonState(new[] { btx2, btx3, btx4, btx5, btx6, btx7 }, false);
        Zline.SetActive(false);
    }

    /*  private void EnableButtonsForCloseDistance()
      {
          Quaternion currentRotation = transform.rotation;

          float yRotation = currentRotation.eulerAngles.y;

          SetButtonState(new[] { bt13, bt14, bt15, bt16, bt17, bt18 }, false);

          if (yRotation > 180f)
          {
              yRotation -= 360f;
          }

          if (Mathf.Abs(yRotation) <= 45f || Mathf.Abs(yRotation) >= 135f)
          {
              EnableHorizontalButtons();
              // Debug.Log("horizontal");
          }
          else
          {
              EnableVerticalButtons();
              //  Debug.Log("vertical");
          }
      }


  */

}
