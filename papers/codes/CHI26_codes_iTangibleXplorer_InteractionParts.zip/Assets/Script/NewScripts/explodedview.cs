using UnityEngine;
using Vuforia;

public class explodedview : MonoBehaviour
{
    private TrackableBehaviour mTrackableBehaviour;
    public Camera ARcamera;
    public GameObject imagetarget;
    public GameObject imagetarget2;
    public GameObject group1, group2, vessel1, vessel2;
    public float distanceThreshold = 5f;
    private Vector3 group1_IniPos;
    private Vector3 group2_IniPos;
    private Vector3 vessel1_IniPos;
    private Vector3 vessel2_IniPos;
    public TMPro.TextMeshProUGUI text;
    float time = 0;
    bool btn = false;
    bool is_open = false;

    void Start()
    {
        mTrackableBehaviour = GetComponent<TrackableBehaviour>();
        if (mTrackableBehaviour)
        {
            mTrackableBehaviour.RegisterOnTrackableStatusChanged(OnTrackableStatusChanged);
        }

        // �����ʼλ��Ϊ�ֲ�����
        group1_IniPos = group1.transform.localPosition;
        group2_IniPos = group2.transform.localPosition;
        vessel1_IniPos = vessel1.transform.localPosition;
        vessel2_IniPos = vessel2.transform.localPosition;
    }

    private void Update()
    {
        time += Time.deltaTime;
        Explode();
    }
    public void OnTrackableStatusChanged(TrackableBehaviour.StatusChangeResult statusChangeResult)
    {
        TrackableBehaviour.Status newStatus = statusChangeResult.NewStatus;
        if (newStatus == TrackableBehaviour.Status.DETECTED || newStatus == TrackableBehaviour.Status.TRACKED)
        {
            Explode();
        }
    }

    public void press_btn()
    {
        btn = true;
        time = 0;
    }

    private void Explode()
    {
        // ���� AR Camera �� Image Target �ľ���
        float distance = Vector3.Distance(imagetarget2.transform.position, ARcamera.transform.position);
        //Debug.Log(distance);
        if (distance > distanceThreshold)
        {
            // ����Զ��ʱ������ָ��λ�Ƹ��¾ֲ�����
            group1.transform.localPosition = group1_IniPos + new Vector3(-2.0f, 0.0f, 0.0f);
            group2.transform.localPosition = group2_IniPos + new Vector3(-1.0f, 0.0f, 0.0f);
            vessel1.transform.localPosition = vessel1_IniPos + new Vector3(2.0f, 0.0f, 0.0f);
            vessel2.transform.localPosition = vessel2_IniPos + new Vector3(1.0f, 0.0f, 0.0f);

        //   Debug.Log("far");
           if(btn)is_open = true;
        }
        else
        {
            // ����ӽ�ʱ���ص�ԭʼ�ֲ�λ��
            group1.transform.localPosition = group1_IniPos;
            group2.transform.localPosition = group2_IniPos;
            vessel1.transform.localPosition = vessel1_IniPos;
            vessel2.transform.localPosition = vessel2_IniPos;

        //    Debug.Log("close");
            if (is_open)
            {
                text.text = "Time = " + time;
                is_open = false;
            }
        }
    }
}
