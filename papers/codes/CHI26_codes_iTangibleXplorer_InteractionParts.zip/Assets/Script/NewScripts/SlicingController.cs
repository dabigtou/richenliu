﻿using UnityEngine;
using Vuforia;

public class SlicingController : MonoBehaviour
{
    private float timer = 0f; // 用于计时的变量
    public GameObject excluder;
    public GameObject Xline, Yline, Zline,guideline;
    public Camera ARcamera;
    public VirtualButtonBehaviour bt1;
    public VirtualButtonBehaviour bt2;
    public VirtualButtonBehaviour bt3;
    public VirtualButtonBehaviour bt4;
    public VirtualButtonBehaviour bt5;
    public VirtualButtonBehaviour bt6;
    public VirtualButtonBehaviour bt7;
    public VirtualButtonBehaviour bt8;
    public VirtualButtonBehaviour bt9;
    public VirtualButtonBehaviour bt10;
    public VirtualButtonBehaviour bt11;
    public VirtualButtonBehaviour bt12;
    public VirtualButtonBehaviour bt13;
    public VirtualButtonBehaviour bt14;
    public VirtualButtonBehaviour bt15;
    public VirtualButtonBehaviour bt16;
    public VirtualButtonBehaviour bt17;
    public VirtualButtonBehaviour bt18;
    private Vector3 initialLocalPosition;
    private TrackableBehaviour mTrackableBehaviour;
    public float distanceThreshold = 5f;
    void Start()
    {
      //  mTrackableBehaviour = GetComponent<TrackableBehaviour>();
     //   if (mTrackableBehaviour)
       // {
       //     mTrackableBehaviour.RegisterOnTrackableStatusChanged(OnTrackableStatusChanged);
       // }

        RegisterButtonEvents();

        initialLocalPosition = excluder.transform.localPosition;
    }

  /*  public void OnTrackableStatusChanged(TrackableBehaviour.StatusChangeResult statusChangeResult)
    {
        TrackableBehaviour.Status newStatus = statusChangeResult.NewStatus;

        if (newStatus == TrackableBehaviour.Status.DETECTED ||
            newStatus == TrackableBehaviour.Status.TRACKED ||
            newStatus == TrackableBehaviour.Status.EXTENDED_TRACKED)
        {
            Debug.Log($"Trackable found: {newStatus}");
            CheckDistance();
        }
        else
        {
            Debug.Log($"Trackable lost: {newStatus}");
        }
    } */

    private void Update()
    {
        CheckDistance();
        timer += Time.deltaTime; // 累加时间

        if (timer >= 5f) // 每10秒
        {
            Debug.Log($"Local Rotation: {transform.rotation.eulerAngles}");
            timer = 0f; // 重置计时器
        }
    }

    private void CheckDistance()
    {
        float distance = Vector3.Distance(transform.position, ARcamera.transform.position);

        if (distance > distanceThreshold)
        {
            EnableButtonsForFarDistance();
        //    Debug.Log("far");
        }
        else
        {
            EnableButtonsForCloseDistance();
        //    Debug.Log("close");
        }
    }

    private void RegisterButtonEvents()
    {
        var buttons = new[]
        {
            bt1, bt2, bt3, bt4, bt5, bt6, bt7, bt8, bt9, bt10,
            bt11, bt12, bt13, bt14, bt15, bt16, bt17, bt18
        };

        foreach (var button in buttons)
        {
            if (button != null)
            {
                button.RegisterOnButtonPressed(OnButtonPressed);
                button.RegisterOnButtonReleased(OnButtonReleased);
            }
        }
    }

    public void OnButtonPressed(VirtualButtonBehaviour vb)
    {
        
        Vector3 presentLocalPositionX = new Vector3(excluder.transform.localPosition.x, excluder.transform.localPosition.y, initialLocalPosition.z);
        Vector3 presentLocalPositionY = new Vector3(excluder.transform.localPosition.x, initialLocalPosition.y, excluder.transform.localPosition.z);
        Vector3 presentLocalPositionZ = new Vector3(initialLocalPosition.x, excluder.transform.localPosition.y, excluder.transform.localPosition.z);
        Vector3 currentPosition = Xline.transform.localPosition;

        switch (vb.VirtualButtonName)
        {
            case "bt1":
                excluder.transform.localPosition = presentLocalPositionX + new Vector3(0.0f, 0.0f, 0.05f);
                currentPosition.x = bt1.transform.localPosition.x;
                Xline.transform.localPosition = currentPosition;
                Debug.Log("bt1");
                break;
            case "bt2":
                excluder.transform.localPosition = presentLocalPositionX + new Vector3(0.0f, 0.0f, 0.1f);
                currentPosition.x = bt2.transform.localPosition.x;
                Xline.transform.localPosition = currentPosition;
                Debug.Log("bt2");
                break;
            case "bt3":
                excluder.transform.localPosition = presentLocalPositionX + new Vector3(0.0f, 0.0f, 0.15f);
                currentPosition.x = bt3.transform.localPosition.x;
                Xline.transform.localPosition = currentPosition;
                Debug.Log("bt3");
                break;
            case "bt4":
                excluder.transform.localPosition = presentLocalPositionX + new Vector3(0.0f, 0.0f, 0.2f);
                currentPosition.x = bt4.transform.localPosition.x;
                Xline.transform.localPosition = currentPosition;
                Debug.Log("bt4");
                break;
            case "bt5":
                excluder.transform.localPosition = presentLocalPositionX + new Vector3(0.0f, 0.0f, 0.25f);
                currentPosition.x = bt5.transform.localPosition.x;
                Xline.transform.localPosition = currentPosition;
                Debug.Log("bt5");
                break;
            case "bt6":
                excluder.transform.localPosition = presentLocalPositionX + new Vector3(0.0f, 0.0f, 0.3f);
                currentPosition.x = bt6.transform.localPosition.x;
                Xline.transform.localPosition = currentPosition;
                Debug.Log("bt6");
                break;
            case "bt7":
                excluder.transform.localPosition = presentLocalPositionY + new Vector3(0.0f, -0.05f, 0.0f);
                currentPosition.x = bt7.transform.localPosition.x;
                Yline.transform.localPosition = currentPosition;
                Debug.Log("bt7");
                break;
            case "bt8":
                excluder.transform.localPosition = presentLocalPositionY + new Vector3(0.0f, -0.1f, 0.0f);
                currentPosition.x = bt8.transform.localPosition.x;
                Yline.transform.localPosition = currentPosition;
                Debug.Log("bt8");
                break;
            case "bt9":
                excluder.transform.localPosition = presentLocalPositionY + new Vector3(0.0f, -0.15f, 0.0f);
                currentPosition.x = bt9.transform.localPosition.x;
                Yline.transform.localPosition = currentPosition;
                Debug.Log("bt9");
                break;
            case "bt10":
                excluder.transform.localPosition = presentLocalPositionY + new Vector3(0.0f, -0.2f, 0.0f);
                currentPosition.x = bt10.transform.localPosition.x;
                Yline.transform.localPosition = currentPosition;
                Debug.Log("bt10");
                break;
            case "bt11":
                excluder.transform.localPosition = presentLocalPositionY + new Vector3(0.0f, -0.25f, 0.0f);
                currentPosition.x = bt11.transform.localPosition.x;
                Yline.transform.localPosition = currentPosition;
                Debug.Log("bt11");
                break;
            case "bt12":
                excluder.transform.localPosition = presentLocalPositionY + new Vector3(0.0f, -0.3f, 0.0f);
                currentPosition.x = bt12.transform.localPosition.x;
                Yline.transform.localPosition = currentPosition;
                Debug.Log("bt12");
                break;
            case "bt13":
                excluder.transform.localPosition = presentLocalPositionZ + new Vector3(0.05f, 0.0f, 0.00f);
                currentPosition.x = bt13.transform.localPosition.x;
                Zline.transform.localPosition= currentPosition;
                Debug.Log("bt13");
                break;
            case "bt14":
                excluder.transform.localPosition = presentLocalPositionZ + new Vector3(0.1f, 0.0f, 0.0f);
                currentPosition.x = bt14.transform.localPosition.x;
                Zline.transform.localPosition = currentPosition;
                Debug.Log("bt14");
                break;
            case "bt15":
                excluder.transform.localPosition = presentLocalPositionZ + new Vector3(0.15f, 0.0f, 0.0f);
                currentPosition.x = bt15.transform.localPosition.x;
                Zline.transform.localPosition = currentPosition;
                Debug.Log("bt15");
                break;
            case "bt16":
                excluder.transform.localPosition = presentLocalPositionZ + new Vector3(0.2f, 0.0f, 0.0f);
                currentPosition.x = bt16.transform.localPosition.x;
                Zline.transform.localPosition = currentPosition;
                Debug.Log("bt16");
                break;
            case "bt17":
                excluder.transform.localPosition = presentLocalPositionZ + new Vector3(0.25f, 0.0f, 0.0f);
                currentPosition.x = bt17.transform.localPosition.x;
                Zline.transform.localPosition = currentPosition;
                Debug.Log("bt17");
                break;
            case "bt18":
                excluder.transform.localPosition = presentLocalPositionZ + new Vector3(0.3f, 0.0f, 0.0f);
                currentPosition.x = bt18.transform.localPosition.x;
                Zline.transform.localPosition = currentPosition;
                Debug.Log("bt18");
                break;
        }
    }

    public void OnButtonReleased(VirtualButtonBehaviour vb)
    {
    }

    private void SetButtonState(VirtualButtonBehaviour[] buttons, bool state)
    {
        foreach (var button in buttons)
        {
            if (button != null)
            {
                button.enabled = state;
                button.gameObject.SetActive(state);
            }
        }
    }

    private void EnableHorizontalButtons()
    {
        SetButtonState(new[] { bt1, bt2, bt3, bt4, bt5, bt6 }, true);
        SetButtonState(new[] { bt7, bt8, bt9, bt10, bt11, bt12 }, false);
        Xline.SetActive(true);
        Yline.SetActive(false);
        Zline.SetActive(false);
    }

    private void EnableVerticalButtons()
    {
        SetButtonState(new[] { bt7, bt8, bt9, bt10, bt11, bt12 }, true);
        SetButtonState(new[] { bt1, bt2, bt3, bt4, bt5, bt6 }, false);
        Xline.SetActive(false);
        Yline.SetActive(true);
        Zline.SetActive(false);
    }

    private void EnableButtonsForFarDistance()
    {
        SetButtonState(new[] { bt1, bt2, bt3, bt4, bt5, bt6, bt7, bt8, bt9, bt10, bt11, bt12 }, false);
        SetButtonState(new[] { bt13, bt14, bt15, bt16, bt17, bt18 }, true);
        Xline.SetActive(false);
        Yline.SetActive(false);
        Zline.SetActive(true);
    }

  /*  private void EnableButtonsForCloseDistance()
    {
        SetButtonState(new[] { bt13, bt14, bt15, bt16, bt17, bt18 }, false);

        Quaternion currentRotation = transform.localRotation;

        float zAngle = Quaternion.Angle(Quaternion.Euler(0, 0, 0), currentRotation); // 计算当前旋转与初始（0度）之间的角度差

        // 这里你可以根据 zAngle 来判断目标是否接近水平或垂直
        if (zAngle < 60 || zAngle > 300)
        {
            EnableHorizontalButtons();
        //    Debug.Log("horizontal");
        }
        else
        {
            EnableVerticalButtons();
        //    Debug.Log("vertical");
        }
    }
  */
    private void EnableButtonsForCloseDistance()
{
    float yRotation = transform.rotation.eulerAngles.y; 

       SetButtonState(new[] { bt13, bt14, bt15, bt16, bt17, bt18 }, false);

        if (yRotation > 180f)
    {
        yRotation -= 360f;
    }

    if (Mathf.Abs(yRotation) <= 45f || Mathf.Abs(yRotation) >= 135f)
    {
        EnableHorizontalButtons(); 
       // Debug.Log("horizontal");
    }
    else
    {
        EnableVerticalButtons(); 
      //  Debug.Log("vertical");
    }
}




}
