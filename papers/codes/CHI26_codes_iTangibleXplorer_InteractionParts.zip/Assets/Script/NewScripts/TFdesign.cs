using UnityEngine;
using Vuforia;
using UnityEngine.UI;
using VolumeViewer;
using System;
public class TFdesign : MonoBehaviour
{
    public GameObject MRI;
    public Canvas canvas;
    //��һ�׶�
    public VirtualButtonBehaviour c1, c2, c3, c4, c5, c6, c7, a1, a2, a3, a4, a5, a6, a7, bt_back,
    bt_menu,bt_pre,bt_basic,bt_custom,bt_c,bt_a;
    public GameObject colorclick,alphaclick,line_O, line_C,menu,back,pre,basic,custom,b_color,b_alpha,pre_image;
    public UnityEngine.UI.Image bt_color_UI,bt_alpha_UI,
        advised1_UI,design1_UI, advised2_UI, design2_UI, subtile_rg, subtile_go, subtile_yp, subtile_bo;
    public RawImage painting,pre_color;
    bool isActive = false;
   private Vector3 initialPosition_O;
   private Vector3 initialPosition_C;
    //�ڶ��׶�
    public VirtualButtonBehaviour t1, t2, t3, t4, t5, t6, t7, t8, t9, t10, t11,
    bt_advised1,bt_design1,red_green,yello_purple,green_orange,bone;
    public GameObject advised_canvas1, design_canvas1, red_green_canvas, 
        green_orange_canvas, yello_purple_canvas, bone_canvas,border_design;
    public Texture2D paintTexture,GreenOrange,RedGreen,YellowPurple,BoneOnly,Mode1_tf,Mode2_tf,Mode3_tf;
    private Color[] segmentColors;
    private Color selectedcolor = Color.white;
    private int numSegments=11, width, height;
    public float transitionRatio = 0.1f;
    bool isActive2 = false;
    private VolumeComponent volumeComponent;
    private Texture2D textureRef;
    //�����׶�
    public VirtualButtonBehaviour bt_advised2, bt_design2, bt_mode1, bt_mode2, bt_mode3,btx2,btx3,btx4,
       btx5,btx6,btx7,btx8
       ,bty1,bty2,bty3,bty4,bty5
        ,bt_add,bt_revert,bt_back2;
    public GameObject advised_canvas2, design_canvas2,mode1,mode2,mode3,border1,border2,border3,add,revert,Slider_x,Slider_y,
        back2;
    public RawImage control_point;
    bool isActive3 = false;
    int num_points=0;
    public GameObject dot;
    private Slider Xline, Yline;
    private GameObject now_dot;
    public GameObject dotx2,dotx3,dotx4,dotx5,dotx6,dotx7,doty2,doty3,doty4,doty5;
    Vector2 dot_pos;
    private Vector3 initialLocalPosition;
    Vector2[] dot_array = new Vector2[7];
    public GameObject[] dots;
    void Start()
    {
        now_dot = dot;
        RegisterButtonEvents();
        SetallActive(false);
        bt_basic.gameObject.SetActive(true);
        bt_custom.gameObject.SetActive(true);
        bt_pre.gameObject.SetActive(true);
        bt_basic.enabled = true;
        bt_custom.enabled = true;
        bt_pre.enabled = true;
        bt_menu.enabled = true;
        basic.SetActive(true);
        pre.SetActive(true);
        menu.SetActive(true);
        custom.SetActive(true);
        width = paintTexture.width;
        height = paintTexture.height;
        segmentColors = new Color[numSegments];
        for (int i = 0; i < numSegments; i++)
        {
            segmentColors[i] = new Color(0,0,0,0); 
        }
        initialLocalPosition = dot.transform.localPosition;
        // initialPosition_C = line_C.transform.position;
        // initialPosition_O= line_O.transform.position;
        volumeComponent = MRI.GetComponent<VolumeComponent>();
        dots=new GameObject[7];
        initialPosition_O = line_O.transform.localPosition;
        initialPosition_C=line_C.transform.localPosition;
        Xline= Slider_x.GetComponent<Slider>();
        Xline.value = -4;
        Yline=Slider_y.GetComponent<Slider>();
        Yline.value = -4;

    }

    void Update()
    {
        
    }

    private void OnApplicationQuit()
    {
        Revert(GreenOrange);
        Revert(paintTexture);
        Revert(RedGreen);
        Revert(BoneOnly);
        Revert(YellowPurple);
    }
    public void OnButtonPressed(VirtualButtonBehaviour vb)
    {
        Vector3 currentPosition_O =line_O.transform.localPosition;
        Vector3 currentPosition_C =line_C.transform.localPosition;
  
        Vector3 presentLocalPositionX = new Vector3(initialLocalPosition.x, now_dot.transform.localPosition.y, now_dot.transform.localPosition.z);
        Vector3 presentLocalPositionY = new Vector3(now_dot.transform.localPosition.x, initialLocalPosition.y, now_dot.transform.localPosition.z);
        Vector3 currentPositionX = Xline.transform.localPosition;
        Vector3 currentPositionY = Yline.transform.localPosition;


        switch (vb.VirtualButtonName)
        {
            case "bt_menu":
                SetallActive(false);
                bt_basic.gameObject.SetActive(true);
                bt_custom.gameObject.SetActive(true);
                bt_pre.gameObject.SetActive(true);
                bt_basic.enabled = true;
                bt_custom.enabled = true;
                bt_pre.enabled = true;
                bt_menu.enabled = true;
                menu.SetActive(true);
                pre.SetActive(true);
                basic.SetActive(true);
                custom.SetActive(true);
                isActive=false;
                isActive2= false;
                isActive3 = false;
                line_C.SetActive(false);
                line_O.SetActive(false);
                ChangeColor(advised1_UI, 255, 255, 255);
                ChangeColor(advised2_UI, 255, 255, 255);
                ChangeColor(design1_UI, 255, 255, 255);
                ChangeColor(design2_UI, 255, 255, 255);

                ChangeColor(bt_color_UI, 255, 255, 255);
                ChangeColor(bt_alpha_UI, 255, 255, 255);
                ChangeColor(design2_UI, 255, 255, 255);
                ChangeColor(design2_UI, 255, 255, 255);

                ChangeColor(subtile_rg, 255, 255, 255);
                ChangeColor(subtile_yp, 255, 255, 255);
                ChangeColor(subtile_go, 255, 255, 255);
                ChangeColor(subtile_bo, 255, 255, 255);
                Debug.Log("success_bt_menu");
            break;
            case "pre":
                SetallActive(false);
                pre_image.SetActive(true);
                SetButtonState(new[]{bt_a,bt_c,bt_menu},true);
                //pre_color.gameObject.SetActive(true);
                colorclick.SetActive(true);
                b_alpha.gameObject.SetActive(true);
                b_color.gameObject.SetActive(true);
                alphaclick.SetActive(true);
                menu.SetActive(true);
                Debug.Log("pre");
                break;
            case "bt_basic":
                SetallActive(false);
                SetButtonState(new[] { bt_menu,bt_advised1,bt_design1}, true);
                menu.SetActive(true);
                MRI.SetActive(true);
                advised_canvas1.SetActive(true);
                design_canvas1.SetActive(true);
                Debug.Log(basic);
                break;
            case "bt_custom":
                control_point.texture = textureRef;
                SetallActive(false);
                MRI.SetActive(true);
                control_point.gameObject.SetActive(true);
                SetButtonState(new[] { bt_menu, bt_advised2, bt_design2 }, true);
                advised_canvas2.SetActive(true);
                design_canvas2.SetActive(true);
                menu.SetActive(true);
                Debug.Log(basic);
                break;
            case "bt_back":
                SetallActive(false);
                if (isActive2==true)
                {
                    ChangeColor(subtile_rg, 255, 255, 255);
                    ChangeColor(subtile_yp, 255, 255, 255);
                    ChangeColor(subtile_go, 255, 255, 255);
                    ChangeColor(subtile_bo, 255, 255, 255);

                    SetButtonState(new[] { bt_menu, bt_advised1, bt_design1 }, true);
                    menu.SetActive(true);
                    advised_canvas1.SetActive(true);
                    design_canvas1.SetActive(true);
                    isActive2 = !isActive2;
                }
                if(isActive3==true)
                {
                    dot.SetActive(false);
                    SetButtonState(new[] { bt_menu, bt_advised2, bt_design2 }, true);
                    menu.SetActive(true);
                    advised_canvas2.SetActive(true);
                    design_canvas2.SetActive(true);
                    back.transform.position=menu.transform.position;
                    bt_back.transform.position=bt_menu.transform.position;
                    isActive3 = !isActive3;
                }
                break;
            case "bt_back2":
                SetallActive(false);
                if (isActive3 == true)
                {
                    dot.SetActive(false);
                    SetButtonState(new[] { bt_menu, bt_advised2, bt_design2 }, true);
                    menu.SetActive(true);
                    advised_canvas2.SetActive(true);
                    design_canvas2.SetActive(true);
                    back.transform.position = menu.transform.position;
                    bt_back.transform.position = bt_menu.transform.position;
                    isActive3 = !isActive3;
                }
                break;
            case "advised1":
                SetallActive(false);
                if(isActive2==false)
                {
                   // ChangeColor(advised1_UI, 150, 205, 255);
                    SetButtonState(new[] { bt_back, red_green, yello_purple, green_orange, bone }, true);
                   // menu.SetActive(true);
                    GameObject[] gameObjects = { 
                        back, red_green_canvas,
                 green_orange_canvas, yello_purple_canvas, bone_canvas
                };
                    foreach (var gameObject in gameObjects)
                    {
                        gameObject.SetActive(true);
                    }
                    isActive2 = !isActive2;
                }
                else
                {
                  //  ChangeColor(advised1_UI, 255, 255, 255);
                    ChangeColor(subtile_rg, 255, 255, 255);
                    ChangeColor(subtile_yp, 255, 255, 255);
                    ChangeColor(subtile_go, 255, 255, 255);
                    ChangeColor(subtile_bo, 255, 255, 255);

                    SetButtonState(new[] { bt_menu, bt_advised1, bt_design1 }, true);
                    menu.SetActive(true);
                    advised_canvas1.SetActive(true);
                    design_canvas1.SetActive(true);
                    isActive2 = !isActive2;
                }
                Debug.Log("bt_advised1");
                break;

            case "design1":
                textureRef = paintTexture;
                volumeComponent.tfData = textureRef;
                SetallActive(false);
                if (isActive2 == false)
                {   
                   // ChangeColor(design1_UI, 150, 205, 255);
                    SetButtonState(new[] { t1, t2, t3, t4, t5, t6, t7, t8, t9, t10, t11,
                    bt_back }, true);
                    //menu.SetActive(true);
                    back.SetActive(true);
                   border_design.SetActive(true);
                 //   advised_canvas1.SetActive(true);
                 //   design_canvas1.SetActive(true);
                    painting.gameObject.SetActive(true);
                    isActive2 = !isActive2;
                }
                else
                {
                    //ChangeColor(design1_UI, 255, 255, 255);
                    SetButtonState(new[] { bt_menu,bt_advised1,bt_design1 }, true);
                    menu.SetActive(true);
                    advised_canvas1.SetActive(true);
                    design_canvas1.SetActive (true);
                    isActive2 = !isActive2;
                }
                Debug.Log("bt_design1");
                break;

            case "advised2":
            SetallActive(false);
                if (isActive3 == false)
                {
                    //ChangeColor(advised2_UI, 150, 205, 255);
                    SetButtonState(new[] { bt_back, bt_mode1, bt_mode2, bt_mode3 }, true);
                   // menu.SetActive(true);
                    GameObject[] gameObjects = {
                        back, mode1,mode2, mode3
                };
                    foreach (var gameObject in gameObjects)
                    {
                        gameObject.SetActive(true);
                    }
                    control_point.gameObject.SetActive(true);
                    isActive3 = !isActive3;
                }
                else
                {
                   // ChangeColor(advised1_UI, 255, 255, 255);
                    SetButtonState(new[] { bt_menu, bt_advised2, bt_design2 }, true);
                    menu.SetActive(true);
                    advised_canvas2.SetActive(true);
                    design_canvas2.SetActive(true);
                    isActive3 = !isActive3;
                }
                Debug.Log("bt_advised2");
                break;
            case "design2":
                SetallActive(false);
                if (isActive3 == false)
                {
                 //   ChangeColor(design2_UI, 150, 205, 255);
                    SetButtonState(new[] { btx2,btx3,btx4,btx5,btx6,btx7,btx8,bty1,bty2,bty3,bty4,bty5
                    ,bt_add,bt_revert,bt_back2 }, true);
                    //menu.SetActive(true);
                    dot.SetActive(true);
                    add.SetActive(true);
                    revert.SetActive(true);
                    //design_canvas2.SetActive(true);
                    back2.SetActive(true);
                    control_point.gameObject.SetActive(true);
                    Slider_x.SetActive(true);
                    Slider_y.SetActive(true);
                    isActive3 = !isActive3;
                    
                }
                else
                {
                  //  ChangeColor(design2_UI, 255, 255, 255);
                    dot.SetActive(false);
                    SetButtonState(new[] { bt_menu, bt_advised2, bt_design2 }, true);
                    menu.SetActive(true);
                    advised_canvas2.SetActive(true);
                    design_canvas2.SetActive(true);
                    isActive3 = !isActive3;
                }
                Debug.Log("bt_design2");
                break;
            
            case "mode2":
                textureRef = Mode2_tf;
                volumeComponent.tfData= textureRef;
                control_point.texture = textureRef;
                border1.SetActive(false);
                border2.SetActive(true);
                border3.SetActive(false);
                // Revert(textureRef);
                //     ModifyTextureByBezier(textureRef, 0, 0, textureRef.width*0.16,
                //textureRef.height * 7/ 8, textureRef.width*0.32, textureRef.height * 7 / 8, 0.484*textureRef.width, 0);
                ModifyTextureByBezier(textureRef, 0, textureRef.height / 10, textureRef.width / 6, textureRef.height,
                textureRef.width / 2, textureRef.height * 1 / 20, textureRef.width, textureRef.height / 9);
                break;
            case "mode1":
                textureRef = Mode1_tf;
                volumeComponent.tfData = textureRef;
                control_point.texture = textureRef;
                border1.SetActive(true);
                border2.SetActive(false);
                border3.SetActive(false);
              //  Revert(textureRef);
                ModifyTextureByBezier(textureRef, 0, textureRef.height/10, textureRef.width / 6, textureRef.height,
            textureRef.width / 2, textureRef.height * 1 / 20, textureRef.width, textureRef.height / 9);
                Debug.Log(mode1);
                break;
            case "mode3":
                textureRef = Mode3_tf;
                volumeComponent.tfData = textureRef;
                control_point.texture = textureRef;
                border1.SetActive(false);
                border2.SetActive(false);
                border3.SetActive(true);
                // Revert(textureRef);
                //  ModifyTextureByBezier(textureRef, 0, textureRef.height/9,textureRef.width / 2, textureRef.height/20,
                //textureRef.width *5/ 6, textureRef.height, textureRef.width, 0);
                ModifyTextureByBezier(textureRef, 0, textureRef.height / 10, textureRef.width / 6, textureRef.height,
                textureRef.width / 2, textureRef.height * 1 / 20, textureRef.width, textureRef.height / 9);
                break;
            case"add":
                if (num_points < 7)
                {
                    if(num_points>=1) dot_array[num_points - 1] = dot_pos;
                    num_points++;
                    now_dot = Instantiate(dot);
                    now_dot.transform.SetParent(canvas.transform, false);
                    dots[num_points - 1] = now_dot;
                    now_dot.transform.localPosition = initialLocalPosition;
                }
                Debug.Log("add:sum=" + num_points);
                break;      
            case "revert":
                Revert(textureRef);
                foreach (GameObject obj in dots)
                {
                    Destroy(obj);
                }
                Array.Clear(dots, 0, dots.Length);  // �����������
                num_points = 0;
                Debug.Log("revert");
                break;
            case "bt_c": 
                pre_image.SetActive(true);
                if (isActive==false)
                {
                    SetallActive(false);
                    pre_image.SetActive(true);
                    SetColor();
                    ChangeColor(bt_color_UI, 150, 205, 255);
                    isActive = true;
                }
                else
                {
                    SetallActive(false);
                    pre_image.SetActive(true);
                    menu.SetActive(true);
                    b_alpha.SetActive(true);
                    b_color.SetActive(true);
                    colorclick.SetActive(true);
                    alphaclick.SetActive(true);
                    bt_menu.gameObject.SetActive(true);
                    bt_menu.enabled=true;
                    bt_a.gameObject.SetActive(true);
                    bt_a.enabled = true;
                    bt_c.gameObject.SetActive(true);
                    bt_c.enabled = true;
                    ChangeColor(bt_color_UI, 255, 255, 255);
                    isActive = false;
                }
                Debug.Log(bt_c);
                break;

            case "bt_a":
                if (isActive == false)
                {
                    SetallActive(false);
                    pre_image.SetActive(true);
                    SetAlpha();
                    ChangeColor(bt_alpha_UI, 150, 205, 255);
                    isActive = !isActive;
                }
                else
                {
                    SetallActive(false);
                    pre_image.SetActive(true);
                    menu.SetActive(true);
                    b_alpha.SetActive(true);
                    b_color.SetActive(true);
                    colorclick.SetActive(true);
                    alphaclick.SetActive(true);
                    bt_menu.gameObject.SetActive(true);
                    bt_menu.enabled = true;
                    bt_a.gameObject.SetActive(true);
                    bt_a.enabled = true;
                    bt_c.gameObject.SetActive(true);
                    bt_c.enabled = true;
                    ChangeColor(bt_alpha_UI, 255, 255, 255);
                    isActive = !isActive;
                }
                Debug.Log(bt_a);
                break;
            case "red_green":
                textureRef = RedGreen;
                volumeComponent.tfData = textureRef;
                ChangeColor(subtile_rg, 150, 205, 255);
                ChangeColor(subtile_yp, 255, 255, 255);
                ChangeColor(subtile_go, 255, 255, 255);
                ChangeColor(subtile_bo, 255, 255, 255);
                break;
            case "yellow_purple":
                textureRef = YellowPurple;
                volumeComponent.tfData = textureRef;
                ChangeColor(subtile_rg, 255, 255, 255);
                ChangeColor(subtile_yp, 150, 205, 255);
                ChangeColor(subtile_go, 255, 255, 255);
                ChangeColor(subtile_bo, 255, 255, 255);
                break;
            case "green_orange":
                textureRef = GreenOrange;
                volumeComponent.tfData = textureRef; 
                ChangeColor(subtile_rg, 255, 255, 255);
                ChangeColor(subtile_yp, 255, 255, 255);
                ChangeColor(subtile_go, 150, 205, 255);
                ChangeColor(subtile_bo, 255, 255, 255);
                Debug.Log("green_orange");
                break;
            case "bone":
                textureRef = BoneOnly;
                volumeComponent.tfData = textureRef; 
                ChangeColor(subtile_rg, 255, 255, 255);
                ChangeColor(subtile_yp, 255, 255, 255);
                ChangeColor(subtile_go, 255, 255, 255);
                ChangeColor(subtile_bo, 150, 205, 255);
                Debug.Log("bone");
                break;
            case "btc1":
                ChangeColor(pre_color, 255, 0, 0);
                selectedcolor=pre_color.color;
                currentPosition_C.x = c1.transform.localPosition.x;
                line_C.transform.localPosition = currentPosition_C;
                Debug.Log("btc1");
                break;
            case "btc2":

                ChangeColor(pre_color, 255, 136, 0);
                selectedcolor = pre_color.color;
                currentPosition_C.x = c2.transform.localPosition.x;
                line_C.transform.localPosition = currentPosition_C;
                Debug.Log("btc2");
                break;
            case "btc3":

                ChangeColor(pre_color, 255, 252, 0);
                selectedcolor = pre_color.color;
                currentPosition_C.x = c3.transform.localPosition.x;
                line_C.transform.localPosition = currentPosition_C;
                Debug.Log("btc1");
                break;
            case "btc4":

                ChangeColor(pre_color, 35, 255, 0);
                selectedcolor = pre_color.color;
                currentPosition_C.x = c4.transform.localPosition.x;
                line_C.transform.localPosition = currentPosition_C;
                Debug.Log("btc1");
                break;
            case "btc5":
                ChangeColor(pre_color, 0, 255, 255);
                selectedcolor = pre_color.color;
                currentPosition_C.x = c5.transform.localPosition.x;
                line_C.transform.localPosition = currentPosition_C;
                Debug.Log("btc5");
                break;
            case "btc6":
                ChangeColor(pre_color, 0, 0, 255);
                selectedcolor = pre_color.color;
                currentPosition_C.x = c6.transform.localPosition.x;
                line_C.transform.localPosition = currentPosition_C;
                Debug.Log("btc1");
                break;
            case "btc7":
                ChangeColor(pre_color, 255, 0, 255);
                selectedcolor = pre_color.color;
                currentPosition_C.x = c7.transform.localPosition.x;
                line_C.transform.localPosition = currentPosition_C;
                Debug.Log("btc1");
                break;
            case "bta1":
                ChangeAlpha(pre_color, 255);
                selectedcolor = pre_color.color;
                currentPosition_O.x = a1.transform.localPosition.x;
                line_O.transform.localPosition = currentPosition_O;
                Debug.Log("bta1"+line_O.transform.localPosition);
                break;
            case "bta2":
                ChangeAlpha(pre_color, 213);
                selectedcolor = pre_color.color;
                currentPosition_O.x = a2.transform.localPosition.x;
                line_O.transform.localPosition = currentPosition_O;
                Debug.Log("bta2" + line_O.transform.localPosition);
                break;
            case "bta3":
                ChangeAlpha(pre_color, 170);
                selectedcolor = pre_color.color;
                currentPosition_O.x = a3.transform.localPosition.x;
                line_O.transform.localPosition = currentPosition_O;
                Debug.Log("bta3" + line_O.transform.localPosition);
                break;
            case "bta4":
                ChangeAlpha(pre_color, 128);
                selectedcolor = pre_color.color;
                currentPosition_O.x = a4.transform.localPosition.x;
                line_O.transform.localPosition = currentPosition_O;
                Debug.Log("bta4" + line_O.transform.localPosition);
                break;
            case "bta5":
                ChangeAlpha(pre_color, 85);
                selectedcolor = pre_color.color;
                currentPosition_O.x = a5.transform.localPosition.x;
                line_O.transform.localPosition = currentPosition_O;
                Debug.Log("bta5" + line_O.transform.localPosition);
                break;
            case "bta6":
                ChangeAlpha(pre_color, 43);
                selectedcolor = pre_color.color;
                currentPosition_O.x = a6.transform.localPosition.x;
                line_O.transform.localPosition = currentPosition_O;
                Debug.Log("bta6" + line_O.transform.localPosition);
                break;
            case "bta7":
                ChangeAlpha(pre_color, 0);
                selectedcolor = pre_color.color;
                currentPosition_O.x = a7.transform.localPosition.x;
                line_O.transform.localPosition = currentPosition_O;
                Debug.Log("bta7" + line_O.transform.localPosition);
                break;
            case "t1":
                PaintColor(0, selectedcolor);
                Debug.Log("t1");
                break;
            case "t2":
                PaintColor(1, selectedcolor);
                Debug.Log("t2");
                break;
            case "t3":
                PaintColor(2, selectedcolor);
                Debug.Log("t3");
                break;
            case "t4":
                PaintColor(3, selectedcolor);
                Debug.Log("t4");
                break;
            case "t5":
                PaintColor(4, selectedcolor);
                Debug.Log("t5");
                break;
            case "t6":
                PaintColor(5, selectedcolor);
                Debug.Log("t6");
                break;
            case "t7":
                PaintColor(6, selectedcolor); 
                Debug.Log("t7");
                break;
            case "t8":
                PaintColor(7, selectedcolor);
                Debug.Log("t8");
                break;
            case "t9":
                PaintColor(8, selectedcolor);
                Debug.Log("t9");
                break;
            case "t10":
                PaintColor(9, selectedcolor);
                Debug.Log("t10");
                break;
            case "t11":
                PaintColor(10, selectedcolor);
                Debug.Log("t11");
                break;
            case "btx2":
                Revert(textureRef);
                currentPositionX.x = btx2.transform.position.x;
               // Xline.transform.position = currentPositionX;
                Xline.value=-4;
                now_dot.transform.position = dot.transform.position;
                now_dot.transform.localPosition = presentLocalPositionX + new Vector3(0f, 0.0f, 0.0f);
                dot_pos.x=(now_dot.transform.localPosition.x-initialLocalPosition.x)*(float)(textureRef.width/172.9);
                dot_pos.y = (now_dot.transform.localPosition.y - initialLocalPosition.y) * (float)(textureRef.width / 172.9);
                BezierRealTime();
                Debug.Log("btx2");
                break;
            case "btx3":
                Revert(textureRef);
                currentPositionX.x = btx3.transform.position.x;
                //Xline.transform.position = currentPositionX;
                Xline.value = -2.6f;
                now_dot.transform.position = dotx2.transform.position;
                now_dot.transform.localPosition = presentLocalPositionX + new Vector3(28.82f, 0.0f, 0.0f);
                dot_pos.x = (now_dot.transform.localPosition.x - initialLocalPosition.x) * (float)(textureRef.width / 172.9);
                dot_pos.y = (now_dot.transform.localPosition.y - initialLocalPosition.y) * (float)(textureRef.width / 172.9);
                BezierRealTime();
                Debug.Log("btx3");
                break;
            case "btx4":
                Revert(textureRef);
                currentPositionX.x = btx4.transform.position.x;
                // Xline.transform.position = currentPositionX;
                Xline.value = -1.5f;
                now_dot.transform.position = dotx3.transform.position;
                now_dot.transform.localPosition = presentLocalPositionX + new Vector3(57.63f, 0.0f, 0.0f);
                dot_pos.x = (now_dot.transform.localPosition.x - initialLocalPosition.x) * (float)(textureRef.width / 172.9);
                dot_pos.y = (now_dot.transform.localPosition.y - initialLocalPosition.y) * (float)(textureRef.width / 172.9);
                BezierRealTime();
                Debug.Log("btx4");
                break;
            case "btx5":
                Revert(textureRef);
                currentPositionX.x = btx5.transform.position.x;
                //Xline.transform.position = currentPositionX;
                Xline.value = -0.3f;
                now_dot.transform.position = dotx4.transform.position;
                now_dot.transform.localPosition = presentLocalPositionX + new Vector3(86.45f, 0.0f, 0.0f);
                dot_pos.x = (now_dot.transform.localPosition.x - initialLocalPosition.x) * (float)(textureRef.width / 172.9);
                dot_pos.y = (now_dot.transform.localPosition.y - initialLocalPosition.y) * (float)(textureRef.width / 172.9);
                BezierRealTime();
                Debug.Log("btx5");
                break;
            case "btx6":
                Revert(textureRef);
                currentPositionX.x = btx6.transform.position.x;
                // Xline.transform.position = currentPositionX;
                Xline.value = 1.2f;
                now_dot.transform.position = dotx5.transform.position;
                now_dot.transform.localPosition = presentLocalPositionX + new Vector3(115.27f, 0.0f, 0.0f);
                dot_pos.x = (now_dot.transform.localPosition.x - initialLocalPosition.x) * (float)(textureRef.width / 172.9);
                dot_pos.y = (now_dot.transform.localPosition.y - initialLocalPosition.y) * (float)(textureRef.width / 172.9);
                BezierRealTime();
                Debug.Log("btx6");
                break;
            case "btx7":               
                Revert(textureRef);
                currentPositionX.x = btx7.transform.position.x;
                // Xline.transform.position = currentPositionX;
                Xline.value = 2.4f;
                now_dot.transform.position = dotx6.transform.position;
                now_dot.transform.localPosition = presentLocalPositionX + new Vector3(144.08f, 0.0f, 0.0f);
                dot_pos.x = (now_dot.transform.localPosition.x - initialLocalPosition.x) * (float)(textureRef.width / 172.9);
                dot_pos.y = (now_dot.transform.localPosition.y - initialLocalPosition.y) * (float)(textureRef.width / 172.9);
                BezierRealTime();
                Debug.Log("btx7");
                break;
            case "btx8":
                Revert(textureRef);
                currentPositionX.x = btx8.transform.position.x;
                //Xline.transform.position = currentPositionX;
                Xline.value = 4;
                now_dot.transform.position = dotx7.transform.position;
                now_dot.transform.localPosition = presentLocalPositionX + new Vector3(172.9f, 0.0f, 0.0f);
                dot_pos.x = (now_dot.transform.localPosition.x - initialLocalPosition.x) * (float)(textureRef.width / 172.9);
                dot_pos.y = (now_dot.transform.localPosition.y - initialLocalPosition.y) * (float)(textureRef.width / 172.9);
                BezierRealTime();
                Debug.Log("btx8");
                break;
            case "bty1":
                Revert(textureRef);
                currentPositionY.z = bty1.transform.position.z;
               // Yline.transform.position = currentPositionY;
               Yline.value = -4;
                now_dot.transform.position = dot.transform.position;
                now_dot.transform.localPosition = presentLocalPositionY + new Vector3(0.0f, 0.0f, 0.0f);
                dot_pos.x = (now_dot.transform.localPosition.x - initialLocalPosition.x) * (float)(textureRef.width / 172.9);
                dot_pos.y = (now_dot.transform.localPosition.y - initialLocalPosition.y) * (float)(textureRef.width / 172.9);
                BezierRealTime();
                Debug.Log("bty1");
                break;

            case "bty2":
                Revert(textureRef);
                currentPositionY.z = bty2.transform.position.z;
                //Yline.transform.position = currentPositionY;
                Yline.value = -2.9f;
                now_dot.transform.position = doty2.transform.position;
                now_dot.transform.localPosition = presentLocalPositionY + new Vector3(0f, 43.225f, 0.0f);
                dot_pos.x = (now_dot.transform.localPosition.x - initialLocalPosition.x) * (float)(textureRef.width / 172.9);
                dot_pos.y = (now_dot.transform.localPosition.y - initialLocalPosition.y) * (float)(textureRef.width / 172.9);
                BezierRealTime();
                Debug.Log("bty2");
                break;

            case "bty3":
                Revert(textureRef);
                currentPositionY.z = bty3.transform.position.z;
                // Yline.transform.position = currentPositionY;
                Yline.value = -0.8f;
                now_dot.transform.position = doty3.transform.position;
                now_dot.transform.localPosition = presentLocalPositionY + new Vector3(0, 86.45f, 0.0f);
                dot_pos.x = (now_dot.transform.localPosition.x - initialLocalPosition.x) * (float)(textureRef.width / 172.9);
                dot_pos.y = (now_dot.transform.localPosition.y - initialLocalPosition.y) * (float)(textureRef.width / 172.9);
                BezierRealTime();
                Debug.Log("bty3");
                break;
            case "bty4":                
                Revert(textureRef);
                currentPositionY.z = bty4.transform.position.z;
                //Yline.transform.position = currentPositionY;
                Yline.value = 1.8f;
                now_dot.transform.position = doty4.transform.position;
                now_dot.transform.localPosition = presentLocalPositionY + new Vector3(0, 129.675f, 0.0f);
                dot_pos.x = (now_dot.transform.localPosition.x - initialLocalPosition.x) * (float)(172.9 / paintTexture.width);
                dot_pos.y = (now_dot.transform.localPosition.y - initialLocalPosition.y) * (float)(172.9 / paintTexture.width);
                BezierRealTime();
                Debug.Log("bty4");
                break;
            case "bty5":
                Revert(textureRef);
                currentPositionY.z = bty5.transform.position.z;
                // Yline.transform.position = currentPositionY;
                Yline.value = 4;
                now_dot.transform.position = doty5.transform.position;
                now_dot.transform.localPosition = presentLocalPositionY + new Vector3(0, 172.9f, 0.0f);
                dot_pos.x = (now_dot.transform.localPosition.x - initialLocalPosition.x) * (float)(textureRef.width / 172.9);
                dot_pos.y = (now_dot.transform.localPosition.y - initialLocalPosition.y) * (float)(textureRef.width / 172.9);
                BezierRealTime();
                Debug.Log("bty5");
                break;
        }
        }

    public void OnButtonReleased(VirtualButtonBehaviour vb)
    {

    }

    private void RegisterButtonEvents()
    {
        VirtualButtonBehaviour[] buttons = {
           c1,c2,c3,c4,c5,c6,c7,a1,a2,a3,a4,a5,a6,a7,
    bt_menu,bt_pre,bt_basic,bt_custom,bt_c,bt_a,t1, t2, t3, t4, t5, t6, t7, t8, t9, t10, t11,
    bt_advised1,bt_design1,red_green,yello_purple,green_orange,bone,bt_advised2, bt_design2, bt_mode1, bt_mode2, bt_mode3,btx2,btx3,btx4,
        btx5,btx6,btx7,btx8
        ,bty1,bty2,bty3,bty4,bty5
        ,bt_add,bt_revert,bt_back,bt_back2
        };

        foreach (var button in buttons)
        {
            button.RegisterOnButtonPressed(OnButtonPressed);
            button.RegisterOnButtonReleased(OnButtonReleased);
        }
    }

    private void SetallActive(bool state)
    {
        VirtualButtonBehaviour[] buttons = {
            c1,c2,c3,c4,c5,c6,c7,a1,a2,a3,a4,a5,a6,a7,bt_menu,bt_basic,bt_custom,bt_pre,bt_c,bt_a,
            t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,bt_advised1,bt_design1,
            red_green,yello_purple,green_orange,bone,bt_advised2,bt_design2,
            bt_mode1,bt_mode2,bt_mode3,bt_add,bt_revert,btx2,btx3,btx4,
        btx5,btx6,btx7,btx8
        ,bty1,bty2,bty3,bty4,bty5,bt_back,bt_back2
        };

        foreach (var button in buttons)
        {
            button.enabled = state;
            button.gameObject.SetActive(state);
        }

        GameObject[] gameObjects = {  line_O,line_C,menu, pre, basic,custom,b_color, b_alpha ,colorclick,alphaclick,
        advised_canvas1, design_canvas1, red_green_canvas,
        green_orange_canvas, yello_purple_canvas, bone_canvas,advised_canvas2,design_canvas2,mode1,mode2,mode3,
        border1,border2,border3,add,revert,dot,Slider_x,Slider_y,dot,pre_image,border_design,back,back2
        };
        foreach (var gameObject in gameObjects)
        {
            gameObject.SetActive(state);
        }

        pre_image.gameObject.SetActive(state);
        painting.gameObject.SetActive(state);
        control_point.gameObject.SetActive(state);
    }


    private void SetButtonState(VirtualButtonBehaviour[] buttons, bool state)
    {
        foreach (var button in buttons)
        {
            button.enabled = state;
            button.gameObject.SetActive(state);
        }
    }

    private void SetAlpha()
    {
        SetButtonState(new[] { a1, a2, a3, a4, a5, a6, a7 ,bt_menu,bt_a}, true);
        alphaclick.SetActive(true);
        line_O.SetActive(true);
        b_alpha.gameObject.SetActive(true);
        menu.SetActive(true);

    }

    private void SetColor()
    {
        SetButtonState(new[] { c1, c2, c3, c4, c5, c6, c7, bt_menu, bt_c }, true);
        colorclick.SetActive(true);
        line_C.SetActive(true);
        b_color.gameObject.SetActive(true);
        menu.SetActive(true);
    }

    private void ChangeColor(UnityEngine.UI.Image targetImage, float r, float g, float b)
    {
        Color currentColor = targetImage.color;
        Color newColor = new Color(r / 255f, g / 255f, b / 255f, currentColor.a);
        targetImage.color = newColor;
    }

    private void ChangeColor(RawImage targetImage, float r, float g, float b)
    {
        Color currentColor = targetImage.color;
        Color newColor = new Color(r / 255f, g / 255f, b / 255f, currentColor.a);
        targetImage.color = newColor;
    }


    private void ChangeAlpha(RawImage targetImage, float a)
    {
        Color currentColor = targetImage.color;
        Color newColor = new Color(currentColor.r, currentColor.g, currentColor.b, a / 255f);
        targetImage.color = newColor;
        selectedcolor = newColor;

    }

    private void PaintColor(int index, Color selectedColor)
    {
        if (index < 0 || index >= numSegments) return;

        segmentColors[index] = selectedColor;
        ApplyTexture(paintTexture);
    }

    private void ApplyTexture(Texture2D texture)
    {
        for (int i = 0; i < numSegments; i++)
        {
            int startX = (i * texture.width) / numSegments;
            int endX = ((i + 1) * texture.width) / numSegments;
            float transitionWidth = (endX - startX) * 0.1f;

            for (int x = startX; x < endX; x++)
            {
                float t = 1;
                if (x < startX + transitionWidth && i > 0)
                {
                    t = (x - startX) / transitionWidth;
                }
                else if (x > endX - transitionWidth && i < numSegments - 1)
                {
                    t = (endX - x) / transitionWidth;
                }

                Color blendedColor = segmentColors[i];
                if (t < 1)
                {
                    if (x < startX + transitionWidth && i > 0)
                    {
                        Color temp = Color.Lerp(segmentColors[i], segmentColors[i - 1], 0.5f);
                        blendedColor = Color.Lerp(temp, segmentColors[i], t);

                    }
                    else if (x > endX - transitionWidth && i < numSegments - 1)
                    {
                        Color temp=Color.Lerp(segmentColors[i], segmentColors[i + 1], 0.5f);
                        blendedColor = Color.Lerp(temp, segmentColors[i], t);

                    }
                }

                for (int y = 0; y < texture.height; y++)
                {
                    texture.SetPixel(x, y, blendedColor);
                }
            }
        }

        texture.Apply();
    }

    private void ModifyTextureByBezier(Texture2D texture, double ax0, double ay0, double ax1, double ay1)
    {
        if (texture == null)
        {
            Debug.LogError("Texture is null!");
            return;
        }
        double x0, x1, y0, y1;
        var points = new (double ax, double ay)[]
        {
            (ax0, ay0),
            (ax1, ay1),
        };
        Array.Sort(points, (p1, p2) => p1.ax.CompareTo(p2.ax));
        x0 = points[0].ax;
        y0 = points[0].ay;
        x1 = points[1].ax;
        y1 = points[1].ay;
        Debug.Log(texture.width + " " + texture.height);
        double k = 0.001953;
        int[] Barray = new int[texture.width];
        for (int i = 0; i < texture.width; i++) Barray[i] = 0;
        for (int x = 0; x < texture.width; x++)
        {
            double t = k * x;
            int By = (int)((1-t)*x0+t*x1);
            int Bx = (int)((1-t)*y0+t*y1);
            if (Bx < texture.width && Barray[Bx] == 0)
            {
                Barray[Bx] = By;
            }
            // Debug.Log(Bx + " " + By);
            for (int y = 0; y < texture.height; y++)
            {
                if (y > By)
                {
                    texture.SetPixel(Bx, y, new Color(0, 0, 0, 0));
                }
            }
        }
        for (int x = 0; x < texture.width; x++)
        {
            if (Barray[x] == 0 && x > 0 && x < texture.width - 1)
            {
                if (Barray[x - 1] != 0) Barray[x] = Barray[x - 1];
                else if (Barray[x + 1] != 0) Barray[x] = Barray[x + 1];
            }
            if (Barray[x] == 0 && x == 0) Barray[x] = Barray[x + 1];
            if (Barray[x] == 0 && x == texture.width - 1) Barray[x] = Barray[x - 1];
            for (int y = 0; y < texture.height; y++)
            {
                if (y > Barray[x])
                {
                    texture.SetPixel(x, y, new Color(0, 0, 0, 0));
                }

            }
        }
        texture.Apply();
        Debug.Log("Bezier success:" + x0 + ',' + y0 + ' ' + x1 + ',' + y1 );
    }

    private void ModifyTextureByBezier(Texture2D texture, double ax0, double ay0, double ax1, double ay1,
            double ax2, double ay2)
    {
        if (texture == null)
        {
            Debug.LogError("Texture is null!");
            return;
        }
        double x0, x1, x2, y0, y1, y2;
        var points = new (double ax, double ay)[]
        {
            (ax0, ay0),
            (ax1, ay1),
            (ax2, ay2)
        };
        Array.Sort(points, (p1, p2) => p1.ax.CompareTo(p2.ax));
        x0 = points[0].ax;
        y0 = points[0].ay;
        x1 = points[1].ax;
        y1 = points[1].ay;
        x2 = points[2].ax;
        y2 = points[2].ay;
        Debug.Log(texture.width + " " + texture.height);
        double k = 0.001953;
        int[] Barray = new int[texture.width];
        for (int i = 0; i < texture.width ; i++) Barray[i] = 0;
        for (int x = 0; x < texture.width; x++)
        {
            double t = k * x;
            int By = (int)(  2* t * (1-t) * y1 + t * t  * y2
                + y0  * (1 - t) * (1 - t));
            int Bx = (int)( 2* t * (1-t)  * x1 +  t * t *  x2
                + x0  * (1 - t) * (1 - t));
            if (Bx < texture.width && Barray[Bx] == 0)
            {
                Barray[Bx] = By;
            }
            // Debug.Log(Bx + " " + By);
            for (int y = 0; y < texture.height; y++)
            {
                if (y > By)
                {
                    texture.SetPixel(Bx, y, new Color(0, 0, 0, 0));
                }
            }
        }
        for (int x = 0; x < texture.width; x++)
        {
            if (Barray[x] == 0 && x >0 && x < texture.width-1)
            {
                if (Barray[x - 1] != 0) Barray[x] = Barray[x - 1];
                else if (Barray[x + 1] != 0) Barray[x] = Barray[x + 1];
            }
            if(Barray[x] == 0 && x == 0) Barray[x]=Barray[x +1];
            if (Barray[x] == 0 && x == texture.width-1) Barray[x] = Barray[x - 1];
            for (int y = 0; y < texture.height; y++)
            {
                if (y > Barray[x])
                {
                    texture.SetPixel(x, y, new Color(0, 0, 0, 0));
                }

            }
        }
        texture.Apply();
        Debug.Log("Bezier success:"+x0+','+y0+' ' + x1 + ',' + y1+ ' ' + x2 + ',' + y2 + ' ');
    }
    private void ModifyTextureByBezier(Texture2D texture, double ax0, double ay0, double ax1, double ay1,
        double ax2, double ay2, double ax3, double ay3)
    {
        Revert(texture);
        double x0, x1, x2,x3, y0, y1, y2,y3;
        var points = new (double ax, double ay)[]
        {
            (ax0, ay0),
            (ax1, ay1),
            (ax3, ay3),
            (ax2, ay2)
        };
        Array.Sort(points, (p1, p2) => p1.ax.CompareTo(p2.ax));
        x0=points[0].ax;
        y0=points[0].ay;
        x1 = points[1].ax;
        y1 = points[1].ay;
        x2 = points[2].ax;
        y2 = points[2].ay;
        x3 = points[3].ax;
        y3 = points[3].ay;
        Debug.Log(texture.width + " " + texture.height);
        double k = 0.001953;
        int[] Barray = new int[texture.width];
        for (int i = 0; i < texture.width; i++) Barray[i] = 0;
        for (int x = 0; x < texture.width; x++)
        {
            double t = k * x;
            int By = (int)(y3 * t * t * t + 3 * t * (1 - t) * (1 - t) * y1 + 3 * t * t * (1 - t) * y2
                + y0 * (1 - t) * (1 - t) * (1 - t));
            int Bx = (int)(x3 * t * t * t + 3 * t * (1 - t) * (1 - t) * x1 + 3 * t * t * (1 - t) * x2
                + x0 * (1 - t) * (1 - t) * (1 - t));
            if (Bx < texture.width && Barray[Bx] == 0)
            {
                Barray[Bx] = By;
            }
            // Debug.Log(Bx + " " + By);
            for (int y = 0; y < texture.height; y++)
            {
                if (y > By)
                {
                    texture.SetPixel(Bx, y, new Color(0, 0, 0, 0));
                }
            }
        }
        for (int x = 0; x < texture.width; x++)
        {
            if (x >= x0 || x <= x3)
            {
                if (Barray[x] == 0 && x > 0 && x < texture.width - 1)
                {
                    if (Barray[x - 1] != 0) Barray[x] = Barray[x - 1];
                    else if (Barray[x + 1] != 0) Barray[x] = Barray[x + 1];
                }
                if (Barray[x] == 0 && x == 0) Barray[x] = Barray[x + 1];
                if (Barray[x] == 0 && x == texture.width - 1) Barray[x] = Barray[x - 1];
            }
            for (int y = 0; y < texture.height; y++)
            {
                if (y > Barray[x])
                {
                    texture.SetPixel(x, y, new Color(0, 0, 0, 0));
                }

            }
        }
        texture.Apply();
        Debug.Log("Bezier success");
    }

    private void ModifyTextureByBezier(Texture2D texture, double ax0, double ay0, double ax1, double ay1,
        double ax2, double ay2, double ax3, double ay3, double ax4, double ay4)
    {
        Revert(texture);
        double x0, x1, x2, x3,x4, y0, y1, y2, y3,y4;
        var points = new (double ax, double ay)[]
        {
            (ax0, ay0),
            (ax1, ay1),
            (ax3, ay3),
            (ax2, ay2),
            (ax4,ay4)
        };
        Array.Sort(points, (p1, p2) => p1.ax.CompareTo(p2.ax));
        x0 = points[0].ax;
        y0 = points[0].ay;
        x1 = points[1].ax;
        y1 = points[1].ay;
        x2 = points[2].ax;
        y2 = points[2].ay;
        x3 = points[3].ax;
        y3 = points[3].ay;
        x4 = points[4].ax;
        y4 = points[4].ay;
        Debug.Log(texture.width + " " + texture.height);
        double k = 0.001953;
        int[] Barray = new int[texture.width];
        for (int i = 0; i < texture.width; i++) Barray[i] = 0;
        for (int x = 0; x < texture.width; x++)
        {
            double t = k * x;
            int By = (int)(y4 * t * t * t*t+y3 * t * t * t*(1-t)*4 + 4 * t *(1-t)* (1 - t) * (1 - t) * y1 + 6 * t * t *(1-t)* (1 - t) * y2
                + y0 * (1 - t) * (1 - t) * (1 - t)*(1-t));
            int Bx = (int)(x4 * t * t * t * t + x3 * t * t * t * (1 - t) * 4 + 4 * t * (1 - t) * (1 - t) * (1 - t) * x1 + 6 * t * t * (1 - t) * (1 - t) * x2
                + x0 * (1 - t) * (1 - t) * (1 - t) * (1 - t));
            if (Bx < texture.width && Barray[Bx] == 0)
            {
                Barray[Bx] = By;
            }
            // Debug.Log(Bx + " " + By);
            for (int y = 0; y < texture.height; y++)
            {
                if (y > By)
                {
                    texture.SetPixel(Bx, y, new Color(0, 0, 0, 0));
                }
            }
        }
        for (int x = 0; x < texture.width; x++)
        {
            if (Barray[x] == 0 && x > 0 && x < texture.width - 1)
            {
                if (Barray[x - 1] != 0) Barray[x] = Barray[x - 1];
                else if (Barray[x + 1] != 0) Barray[x] = Barray[x + 1];
            }
            if (Barray[x] == 0 && x == 0) Barray[x] = Barray[x + 1];
            if (Barray[x] == 0 && x == texture.width - 1) Barray[x] = Barray[x - 1];
            for (int y = 0; y < texture.height; y++)
            {
                if (y > Barray[x])
                {
                    texture.SetPixel(x, y, new Color(0, 0, 0, 0));
                }

            }
        }
        texture.Apply();
        Debug.Log("Bezier success");
    }

    private void ModifyTextureByBezier(Texture2D texture, double ax0, double ay0, double ax1, double ay1,
        double ax2, double ay2, double ax3, double ay3, double ax4, double ay4, double ax5, double ay5)
    {
        Revert(texture);
        double x0, x1, x2, x3, x4,x5, y0, y1, y2, y3, y4,y5;
        var points = new (double ax, double ay)[]
        {
            (ax0, ay0),
            (ax1, ay1),
            (ax3, ay3),
            (ax2, ay2),
            (ax4,ay4),
            (ax5,ay5)
        };
        Array.Sort(points, (p1, p2) => p1.ax.CompareTo(p2.ax));
        x0 = points[0].ax;
        y0 = points[0].ay;
        x1 = points[1].ax;
        y1 = points[1].ay;
        x2 = points[2].ax;
        y2 = points[2].ay;
        x3 = points[3].ax;
        y3 = points[3].ay;
        x4 = points[4].ax;
        y4 = points[4].ay;
        x5 = points[5].ax;
        y5 = points[5].ay;
        Debug.Log(texture.width + " " + texture.height);
        double k = 0.001953;
        int[] Barray = new int[texture.width];
        for (int i = 0; i < texture.width; i++) Barray[i] = 0;
        for (int x = 0; x < texture.width; x++)
        {
            double t = k * x;
            int By = (int)(y5 * t * t * t * t*t +y4*5*(1-t)*t*t*t*t+ y3 * t * t * t * (1 - t)*(1-t) * 10 + 5 * t * (1 - t) * (1 - t) * (1 - t)*(1-t) * y1 + 10 * t * t * (1 - t) * (1 - t) 
                *(1-t)* y2+ y0 * (1 - t) * (1 - t) * (1 - t) * (1 - t)*(1-t));
            int Bx = (int)(x5 * t * t * t * t * t + x4 * 5 * (1 - t) * t * t * t * t + x3 * t * t * t * (1 - t) * (1 - t) * 10 + 5 * t * (1 - t) * (1 - t) * (1 - t) * (1 - t) * x1 + 10 * t * t * (1 - t) * (1 - t)
                * (1 - t) * x2 + x0 * (1 - t) * (1 - t) * (1 - t) * (1 - t) * (1 - t));
            if (Bx < texture.width && Barray[Bx] == 0)
            {
                Barray[Bx] = By;
            }
            // Debug.Log(Bx + " " + By);
            for (int y = 0; y < texture.height; y++)
            {
                if (y > By)
                {
                    texture.SetPixel(Bx, y, new Color(0, 0, 0, 0));
                }
            }
        }
        for (int x = 0; x < texture.width; x++)
        {
            if (Barray[x] == 0 && x > 0 && x < texture.width - 1)
            {
                if (Barray[x - 1] != 0) Barray[x] = Barray[x - 1];
                else if (Barray[x + 1] != 0) Barray[x] = Barray[x + 1];
            }
            if (Barray[x] == 0 && x == 0) Barray[x] = Barray[x + 1];
            if (Barray[x] == 0 && x == texture.width - 1) Barray[x] = Barray[x - 1];
            for (int y = 0; y < texture.height; y++)
            {
                if (y > Barray[x])
                {
                    texture.SetPixel(x, y, new Color(0, 0, 0, 0));
                }

            }
        }
        texture.Apply();
        Debug.Log("Bezier success");
    }

    private void BezierRealTime()
    {
        if (num_points >= 2)
            switch (num_points)
        {
                case 2:
                    ModifyTextureByBezier(textureRef, dot_array[0].x, dot_array[0].y, dot_pos.x, dot_pos.y);
                    break;
                case 3:
                    ModifyTextureByBezier(textureRef, dot_array[0].x, dot_array[0].y, dot_array[1].x,
                    dot_array[1].y, dot_pos.x, dot_pos.y);
                    break;
                case 4:
                    ModifyTextureByBezier(textureRef, dot_array[0].x, dot_array[0].y, dot_array[1].x,
                    dot_array[1].y, dot_array[2].x, dot_array[2].y,dot_pos.x, dot_pos.y);
                    break;
                case 5:
                    ModifyTextureByBezier(textureRef, dot_array[0].x, dot_array[0].y, dot_array[1].x,
                    dot_array[1].y, dot_array[2].x, dot_array[2].y, dot_array[3].x, dot_array[3].y, dot_pos.x, dot_pos.y);
                    break;
                case 6:
                    ModifyTextureByBezier(textureRef, dot_array[0].x, dot_array[0].y, dot_array[1].x,
                    dot_array[1].y, dot_array[2].x, dot_array[2].y, dot_array[3].x, dot_array[3].y,
                    dot_array[4].x, dot_array[4].y, dot_pos.x, dot_pos.y);
                    break;
            }
            
      
    }

    private void Revert(Texture2D texture)
    {
       for(int x=0;x< texture.width;x++)
        {
            Color pixel_now = texture.GetPixel(x, 1);
            for(int y=0;y< texture.height;y++)
            {
                texture.SetPixel(x, y, pixel_now);
            }
        }
    }
}
