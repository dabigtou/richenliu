using Vuforia;
using UnityEngine;
using TMPro;

public class Histogram : MonoBehaviour
{
    public GameObject vessel1,vessel2,finger,bone,skin,chartvessel,chartbone,chartskin;
    public VirtualButtonBehaviour bt19;
    public VirtualButtonBehaviour bt20;
    public VirtualButtonBehaviour bt21;
    private bool isActive1 = false;
    private bool isActive2 = false;
    private bool isActive3 = false;
    public TMPro.TextMeshProUGUI text;

    int cnt = 0;
    float time = 0;
    void Start()
    {
        bt19.RegisterOnButtonPressed(OnButtonPressed);
        bt19.RegisterOnButtonReleased(OnButtonReleased);
        bt20.RegisterOnButtonPressed(OnButtonPressed);
        bt20.RegisterOnButtonReleased(OnButtonReleased);
        bt21.RegisterOnButtonPressed(OnButtonPressed);
        bt21.RegisterOnButtonReleased(OnButtonReleased);
    //    Debug.Log($"Button bt19: {bt19 != null}");
    //    Debug.Log($"Button bt20: {bt20 != null}");
    //    Debug.Log($"Button bt21: {bt21 != null}");

        vessel1.SetActive(false);
        vessel2.SetActive(false);
        finger.SetActive(false);
        bone.SetActive(false);
        skin.SetActive(false);
        chartvessel.SetActive(false);
        chartbone.SetActive(false);
        chartskin.SetActive(false);
      

    }

    public void OnButtonPressed(VirtualButtonBehaviour vb)
    {
        switch (vb.VirtualButtonName)
        {
            case "bt19":
                 if (isActive1== false)
                  {
                //setallactivefalse();
                vessel1.SetActive(true);
                vessel2.SetActive(true);
                chartvessel.SetActive(true);
              //  bone.SetActive(false);
              //  chartbone.SetActive(false);
              //  skin.SetActive(false);
              //  chartskin.SetActive(false);
                        isActive1 = true;
                    }
                   else
                   {
                       vessel1.SetActive(false);
                       vessel2.SetActive(false);
                       chartvessel.SetActive(false);
                       isActive1 = false;
                   }
        //        Debug.Log("bt19");
                break;
            case "bt20":
                   if (isActive2 == false)
                    {
                //setallactivefalse();
                
              //  vessel1.SetActive(false);
              //  vessel2.SetActive(false);
              //  chartvessel.SetActive(false);
                bone.SetActive(true);
                chartbone.SetActive(true);
              //  skin.SetActive(false);
              //  chartskin.SetActive(false);
                        isActive2 = true;
                    }
                   else
                    {
                         bone.SetActive(false);
                         chartbone.SetActive(false);
                         isActive2 = false;
                      }
         //       Debug.Log("bt20");
                break;
            case "bt21":
                  if (isActive3 == false)
                  {
               // setallactivefalse();

             //   vessel1.SetActive(false);
             //   vessel2.SetActive(false);
             //   chartvessel.SetActive(false);
             //   bone.SetActive(false);
             //   chartbone.SetActive(false);
                skin.SetActive(true);
                chartskin.SetActive(true);
                      isActive3 = true;
                  }
                  else
                  {
                   skin.SetActive(false);
                    chartskin.SetActive(false);
                    isActive3 = false;
                 }
        //        Debug.Log("bt21");
                break;
            

        }
    }

    public void OnButtonReleased(VirtualButtonBehaviour vb)
    {
    //    Debug.Log($"{vb.VirtualButtonName} Released");
        cnt++;
        if(cnt == 3)
        {
            Debug.Log("Time = " + time);
            text.text = "Time = " + time.ToString("F2");
            cnt++;
        }
    }

    
   void setallactivefalse()
    {
        GameObject[] gameObjects = { vessel1, vessel2, finger, bone, skin, chartvessel, chartbone, chartskin };

        foreach (var gameobject in gameObjects)
        {
            gameObject.SetActive(false);
        }
    }
    private void Update()
    {
        time += Time.deltaTime;
    }
}
