using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR;
using Vuforia;

public class Main_controller : MonoBehaviour
{   
    public GameObject navigation, slicing, foucus_context, histogram, transfer_function, exploded_view,b_menu,Xline,Yline,Zline,
        canvas_main,image_target,rotation,panning,lung,brain,canvas_panning,MRI,image1,vessel1,veseel2,finger,bone,skin,magnifier
        ,AROBJ,model_lung,Canvas_UI,line_O,line_C,MRI_fc;
    public VirtualButtonBehaviour nav, sli, fc, his, tf_func, exp,menu, btx2, btx3, btx4,
        btx5, btx6, btx7, btx8, bty1, bty2, bty3, bty4, bty5, btz2, btz3, btz4,
        btz5, btz6, btz7, btz8,bt_rotate,bt_pan,bt_lung,bt_brain,bth_1,bth_2,bth_3,color,pre,alpha,c1,c2,c3,c4,c5,p1,p2
        ,p3,p4,p5,a1,a2,a3,a4,a5;
    private Dictionary<string, MonoBehaviour> scriptsDict = new Dictionary<string, MonoBehaviour>();
    void Start()
    {
        
        SetAllActive(false);
        if (image_target == null)
        {
            Debug.LogError("image_target is not assigned in Inspector!");
            return; // ��ֹ��������ִ�е����쳣
        }

        // �Զ���ȡ��ǰ GameObject �ϵ����нű����������ֵ�
        MonoBehaviour[] scripts = image_target.GetComponents<MonoBehaviour>();
        foreach (MonoBehaviour script in scripts)
        {
            if (script != null && script != this) // ȷ�� script ��Ϊ���Ҳ��ǵ�ǰ�ű�
            {
                scriptsDict[script.GetType().Name] = script;
            }
        }
        VirtualButtonBehaviour[] vbs ={
            nav, sli, fc, his, tf_func, exp,menu
        };
        GameObject[] OBJs ={
                 navigation, slicing, foucus_context, histogram, transfer_function, exploded_view,b_menu
                      };
        foreach (var bt in vbs)
        {
            bt.enabled = true;
            bt.gameObject.SetActive(true);
        }
        foreach (var OBJ in OBJs)
        {
            OBJ.SetActive(true);
        }
        Debug.Log("success");
        RegisterButtonEvents();
    }
    void Update()
    {
        
    }
    public void OnButtonPressed(VirtualButtonBehaviour vb)
    {
        switch(vb.VirtualButtonName)
        {
            case "mymenu":
                DisableScript("explodedview");
                DisableScript("FocusContext");
                DisableScript("Histogram");
                DisableScript("RotateController");
                DisableScript("TransferFunction");
                DisableScript("Slicing2");
                SetAllActive(false);
                VirtualButtonBehaviour[] vbs ={
            nav, sli, fc, his, tf_func, exp,menu
        };
                GameObject[] OBJs ={
                navigation, slicing, foucus_context, histogram, transfer_function, exploded_view,b_menu       };
                foreach (var bt in vbs)
                {
                    bt.enabled = true;
                    bt.gameObject.SetActive(true);
                }
                foreach (var OBJ in OBJs)
                {
                    OBJ.SetActive(true);
                }
                break;
            case "nav":
                SetAllActive(false);
                VirtualButtonBehaviour[] vbs3 =
                {
                    menu,bt_rotate,bt_pan
                };
                foreach (var OBJ in vbs3)
                {
                    OBJ.enabled= true;
                    OBJ.gameObject.SetActive(true);
                }
                rotation.SetActive(true);
                rotation.SetActive(true);
                panning.SetActive(true);
                b_menu.SetActive(true);
                break;
            case "rotate":
                SetAllActive(false);
                VirtualButtonBehaviour[] vbs2 ={
        btx2, btx3, btx4,
        btx5, btx6, btx7, btx8, bty1, bty2, bty3, bty4, bty5, btz2, btz3, btz4,
        btz5, btz6, btz7, btz8,menu        };
                GameObject[] OBJs2 ={
            canvas_main,image1,b_menu
        };
                foreach (var bt in vbs2)
                {
                    bt.enabled = true;
                    bt.gameObject.SetActive(true);
                }
                foreach (var OBJ in OBJs2)
                {
                    OBJ.SetActive(true);
                }
           //     EnableOnlyScript("RotateController");
                break;
            case "pan":
                SetAllActive(false);
                menu.enabled = true;
                menu.gameObject.SetActive(true);
                b_menu.SetActive(true);
                canvas_panning.SetActive(true);
                menu.gameObject.SetActive(true);
                b_menu.SetActive(true);
                break;
            case "sli":
                SetAllActive(false);
                SetButtonState(new[] {btx2, btx3, btx4,
        btx5, btx6, btx7, btx8, bty1, bty2, bty3, bty4, bty5, btz2, btz3, btz4,
        btz5, btz6, btz7, btz8 ,menu},true);
                MRI.SetActive(true);
                b_menu.SetActive(true);
                EnableOnlyScript("Slicing2");
                break;
            case "fc":
                SetAllActive(false);
                SetButtonState(new[] {btx2, btx3, btx4,
        btx5, btx6, btx7, btx8, bty1, bty2, bty3, bty4, bty5 ,menu}, true);
                canvas_main.SetActive(true);
                MRI_fc.SetActive(true);
                magnifier.SetActive(true);
                b_menu.SetActive(true);
                Xline.SetActive(true);
                Yline.SetActive(true);
                EnableOnlyScript("FocusContext");
                break;
            case "his":
                SetAllActive(false);
                SetButtonState(new[] {bth_1,bth_2,bth_3,menu}, true);
                AROBJ.SetActive(true);
                canvas_main.SetActive(true);
                b_menu.SetActive (true);
                EnableOnlyScript("Histogram");
                break;
            case "exp":
                SetAllActive(false);
                model_lung.SetActive(true);
                menu.enabled = true;
                menu.gameObject.SetActive(true);
                b_menu.SetActive(true);
                EnableOnlyScript("explodedview");
                break;
            case "tf_func":
                SetAllActive(false);
                Canvas_UI.SetActive(true);
                canvas_main.SetActive (true);
                vessel1.SetActive(true);
                veseel2.SetActive(true);
                finger.SetActive(true);
                bone.SetActive(true);
                skin.SetActive(true);
                line_C.SetActive(true);
                line_O.SetActive(true);
                SetButtonState(new[] { color,pre,alpha,c1,c2,c3,c4,c5,p1,p2
        ,p3,p4,p5,a1,a2,a3,a4,a5}, true);
                menu.enabled = true;
                menu.gameObject.SetActive(true);
                b_menu.SetActive(true);
                EnableOnlyScript("TransferFunction");
                break;
        }
    }

    public void OnButtonReleased(VirtualButtonBehaviour vb)
    {
    }

    private void SetAllActive(bool state)
    {
        VirtualButtonBehaviour[] vbs={
           nav, sli, fc, his, tf_func, exp,menu, btx2, btx3, btx4,
        btx5, btx6, btx7, btx8, bty1, bty2, bty3, bty4, bty5, btz2, btz3, btz4,
        btz5, btz6, btz7, btz8,bt_rotate,bt_pan,bt_lung,bt_brain,bth_1,bth_2,bth_3,color,pre,alpha,c1,c2,c3,c4,c5,p1,p2
        ,p3,p4,p5,a1,a2,a3,a4,a5
    };
        GameObject[] OBJs ={
           navigation, slicing, foucus_context, histogram, transfer_function, exploded_view,b_menu,Xline,Yline,Zline,
        canvas_main,rotation,panning,lung,brain,canvas_panning,MRI,image1,vessel1,veseel2,finger,bone,skin,magnifier
        ,AROBJ,model_lung,Canvas_UI,line_O,line_C,MRI_fc
        };
        foreach(var vb in vbs)
        {
            vb.enabled= false; 
            vb.gameObject.SetActive(false);
        }
        foreach(var OBJ in OBJs)
        {
            OBJ.SetActive(false);
        }
    }
    private void RegisterButtonEvents()
    {
        VirtualButtonBehaviour[] buttons = {
          nav, sli, fc, his, tf_func, exp,menu, btx2, btx3, btx4,
        btx5, btx6, btx7, btx8, bty1, bty2, bty3, bty4, bty5, btz2, btz3, btz4,
        btz5, btz6, btz7, btz8,bt_rotate,bt_pan,bt_lung,bt_brain,bth_1,bth_2,bth_3,color,pre,alpha,c1,c2,c3,c4,c5,p1,p2
        ,p3,p4,p5,a1,a2,a3,a4,a5
        };

        foreach (var button in buttons)
        {
            button.RegisterOnButtonPressed(OnButtonPressed);
            button.RegisterOnButtonReleased(OnButtonReleased);
        }
    }

    public void EnableScript(string scriptName)
    {
        if (scriptsDict.ContainsKey(scriptName))
            scriptsDict[scriptName].enabled = true;
        else
            Debug.LogWarning($"δ�ҵ��ű�: {scriptName}");
    }

    // ����ָ���ű�
    public void DisableScript(string scriptName)
    {
        if (scriptsDict.ContainsKey(scriptName))
            scriptsDict[scriptName].enabled = false;
        else
            Debug.LogWarning($"δ�ҵ��ű�: {scriptName}");
    }

    // �л�ָ���ű���״̬
    public void ToggleScript(string scriptName)
    {
        if (scriptsDict.ContainsKey(scriptName))
            scriptsDict[scriptName].enabled = !scriptsDict[scriptName].enabled;
        else
            Debug.LogWarning($"δ�ҵ��ű�: {scriptName}");
    }

    public void EnableOnlyScript(string scriptName)
    {
        DisableScript("explodedview");
        DisableScript("FocusContext");
        DisableScript("Histogram");
        DisableScript("RotateController");
        DisableScript("TransferFunction");
        DisableScript("Slicing2");
        EnableScript(scriptName);
    }

    private void SetButtonState(VirtualButtonBehaviour[] buttons, bool state)
    {
        foreach (var button in buttons)
        {
            button.enabled = state;
            button.gameObject.SetActive(state);
        }
    }

    private void SetObjectState(GameObject[] buttons, bool state)
    {
        foreach (var button in buttons)
        {
            button.SetActive(state);
        }
    }
}

