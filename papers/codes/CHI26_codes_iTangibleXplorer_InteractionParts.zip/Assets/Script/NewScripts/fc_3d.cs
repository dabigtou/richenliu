using UnityEngine;
using Vuforia;

public class fc_3d : MonoBehaviour
{
    public GameObject magnifier;
    public GameObject Xline, Yline;
    public GameObject excluder_z;
    public Camera ARcamera;
    public VirtualButtonBehaviour btx2;
    public VirtualButtonBehaviour btx3;
    public VirtualButtonBehaviour btx4;
    public VirtualButtonBehaviour btx5;
    public VirtualButtonBehaviour btx6;
    public VirtualButtonBehaviour btx7;
    public VirtualButtonBehaviour btx8;
    public VirtualButtonBehaviour bty1;
    public VirtualButtonBehaviour bty2;
    public VirtualButtonBehaviour bty3;
    public VirtualButtonBehaviour bty4;
    public VirtualButtonBehaviour bty5;
    private TrackableBehaviour mTrackableBehaviour;
    private Vector3 initialLocalPosition;


    public float position_far = 3.5f;
    public float position_near = 2.0f;
    private float fixed_z;
    void Start()
    {
        //  mTrackableBehaviour = GetComponent<TrackableBehaviour>();
        //  if (mTrackableBehaviour)
        //  {
        //      mTrackableBehaviour.RegisterOnTrackableStatusChanged(OnTrackableStatusChanged);
        //  }                //Tracklble �ӿڵ���


        btx2.RegisterOnButtonPressed(OnButtonPressed);
        btx2.RegisterOnButtonReleased(OnButtonReleased);
        btx3.RegisterOnButtonPressed(OnButtonPressed);
        btx3.RegisterOnButtonReleased(OnButtonReleased);
        btx4.RegisterOnButtonPressed(OnButtonPressed);
        btx4.RegisterOnButtonReleased(OnButtonReleased);
        btx5.RegisterOnButtonPressed(OnButtonPressed);
        btx5.RegisterOnButtonReleased(OnButtonReleased);
        btx6.RegisterOnButtonPressed(OnButtonPressed);
        btx6.RegisterOnButtonReleased(OnButtonReleased);
        btx7.RegisterOnButtonPressed(OnButtonPressed);
        btx7.RegisterOnButtonReleased(OnButtonReleased);
        btx8.RegisterOnButtonPressed(OnButtonPressed);
        btx8.RegisterOnButtonReleased(OnButtonReleased);
        bty1.RegisterOnButtonPressed(OnButtonPressed);
        bty1.RegisterOnButtonReleased(OnButtonReleased);
        bty2.RegisterOnButtonPressed(OnButtonPressed);
        bty2.RegisterOnButtonReleased(OnButtonReleased);
        bty3.RegisterOnButtonPressed(OnButtonPressed);
        bty3.RegisterOnButtonReleased(OnButtonReleased);
        bty4.RegisterOnButtonPressed(OnButtonPressed);
        bty4.RegisterOnButtonReleased(OnButtonReleased);
        bty5.RegisterOnButtonPressed(OnButtonPressed);
        bty5.RegisterOnButtonReleased(OnButtonReleased);
        initialLocalPosition = magnifier.transform.localPosition;
        Xline.SetActive(true);
        Yline.SetActive(true);

        fixed_z = excluder_z.transform.position.z;
    }

    private void Update()
    {
      //  CheckDistance();
    }
    // x,y������
    /*  private void Update()
      {
          EnableButtonsForCloseDistance();
      }
      public void OnTrackableStatusChanged(TrackableBehaviour.StatusChangeResult statusChangeResult)
      {
          TrackableBehaviour.Status newStatus = statusChangeResult.NewStatus;
          if (newStatus == TrackableBehaviour.Status.DETECTED || newStatus == TrackableBehaviour.Status.TRACKED)
          {
              EnableButtonsForCloseDistance();
          }
      }
    */
    public void OnButtonPressed(VirtualButtonBehaviour vb)
    {
        Vector3 presentLocalPositionX = new Vector3(initialLocalPosition.x, magnifier.transform.localPosition.y, magnifier.transform.localPosition.z);
        Vector3 presentLocalPositionY = new Vector3(magnifier.transform.localPosition.x, initialLocalPosition.y, magnifier.transform.localPosition.z);
        Vector3 currentPositionX = Xline.transform.localPosition;
        Vector3 currentPositionY = Yline.transform.localPosition;

        switch (vb.VirtualButtonName)
        {

            case "btx2":
                currentPositionX.x = btx2.transform.localPosition.x;
                Xline.transform.localPosition = currentPositionX;
                magnifier.transform.localPosition = presentLocalPositionX + new Vector3(0f, 0.0f, 0.0f);
                Debug.Log("btx2");
                break;
            case "btx3":
                currentPositionX.x = btx3.transform.localPosition.x;
                Xline.transform.localPosition = currentPositionX;
                magnifier.transform.localPosition = presentLocalPositionX + new Vector3(8f, 0.0f, 0.0f);
                Debug.Log("btx3");
                break;
            case "btx4":
                currentPositionX.x = btx4.transform.localPosition.x;
                Xline.transform.localPosition = currentPositionX;
                magnifier.transform.localPosition = presentLocalPositionX + new Vector3(16f, 0.0f, 0.0f);
                Debug.Log("btx4");
                break;
            case "btx5":
                currentPositionX.x = btx5.transform.localPosition.x;
                Xline.transform.localPosition = currentPositionX;
                magnifier.transform.localPosition = presentLocalPositionX + new Vector3(24f, 0.0f, 0.0f);
                Debug.Log("btx5");
                break;
            case "btx6":
                currentPositionX.x = btx6.transform.localPosition.x;
                Xline.transform.localPosition = currentPositionX;
                magnifier.transform.localPosition = presentLocalPositionX + new Vector3(32f, 0.0f, 0.0f);
                Debug.Log("btx6");
                break;
            case "btx7":
                currentPositionX.x = btx7.transform.localPosition.x;
                Xline.transform.localPosition = currentPositionX;
                magnifier.transform.localPosition = presentLocalPositionX + new Vector3(40f, 0.0f, 0.0f);
                Debug.Log("btx7");
                break;
            case "btx8":
                currentPositionX.x = btx8.transform.localPosition.x;
                Xline.transform.localPosition = currentPositionX;
                magnifier.transform.localPosition = presentLocalPositionX + new Vector3(48f, 0.0f, 0.0f);
                Debug.Log("btx8");
                break;

            case "bty1":
                currentPositionY.z = bty1.transform.localPosition.z;
                Yline.transform.localPosition = currentPositionY;
                magnifier.transform.localPosition = presentLocalPositionY + new Vector3(0.0f, 0.0f, 0.0f);
                Debug.Log("bty1");
                break;

            case "bty2":
                currentPositionY.z = bty2.transform.localPosition.z;
                Yline.transform.localPosition = currentPositionY;
                magnifier.transform.localPosition = presentLocalPositionY + new Vector3(0.0f, 13f, 0.0f);
                Debug.Log("bty2");
                break;

            case "bty3":
                currentPositionY.z = bty3.transform.localPosition.z;
                Yline.transform.localPosition = currentPositionY;
                magnifier.transform.localPosition = presentLocalPositionY + new Vector3(0.0f, 26f, 0.0f);
                Debug.Log("bty3");
                break;
            case "bty4":
                currentPositionY.z = bty4.transform.localPosition.z;
                Yline.transform.localPosition = currentPositionY;
                magnifier.transform.localPosition = presentLocalPositionY + new Vector3(0.0f, 39f, 0.0f);
                Debug.Log("bty4");
                break;
            case "bty5":
                currentPositionY.z = bty5.transform.localPosition.z;
                Yline.transform.localPosition = currentPositionY;
                magnifier.transform.localPosition = presentLocalPositionY + new Vector3(0.0f, 52f, 0.0f);
                Debug.Log("bty5");
                break;

        }
    }

    private void CheckDistance()
    {
        float distance = Vector3.Distance(transform.position, ARcamera.transform.position);

        if (distance >= position_near && distance <= position_far)
        {

            excluder_z.SetActive(true);
            double realtime_z = -(distance - position_near) / (position_far - position_near) * 0.9 + 0.45;
            //  Vector3 presentPositionY = new Vector3(excluder_slicing.transform.localPosition.x, (float)realtime_z, excluder_slicing.transform.localPosition.z);
            Vector3 presentPositionZ = new Vector3(excluder_z.transform.localPosition.x, excluder_z.transform.localPosition.y, (float)realtime_z);
            excluder_z.transform.localPosition = presentPositionZ;
            float magnifier_z = transform.localPosition.z - 33 + 246;
            Vector3 presentPositionM = new Vector3(magnifier.transform.position.x, magnifier.transform.position.y, magnifier_z);
            // magnifier.transform.position= presentPositionM;
            //   excluder_slicing.transform.localPosition = presentPositionZ;

        }

        else
        {

            excluder_z.SetActive(false);

        }
        //  if (distance > distanceThreshold)
        // {
        //      EnableButtonsForFarDistance();
        // Debug.Log("far");
        //  }
        //  else
        //  {
        //      EnableButtonsForCloseDistance();
        //  Debug.Log("close");
        //  }

        Debug.Log(distance);
    }

    public void OnButtonReleased(VirtualButtonBehaviour vb)
    {
        // Add any functionality needed when a button is released.
    }


    private void SetButtonState(VirtualButtonBehaviour[] buttons, bool state)
    {
        foreach (var button in buttons)
        {
            button.enabled = state;
            button.gameObject.SetActive(state);
        }
    }

    /*   private void EnableHorizontalButtons()
       {
           Xline.SetActive(true);
           Yline.SetActive(false);
           SetButtonState(new[] { btxy, btx2, btx3, btx4, btx5, btx6 }, true);
           SetButtonState(new[] { btx7, btx8, btx9, btx1, bt11, bt12 }, false);
           Xline.SetActive(true); 
           Yline.SetActive(false);
       }
    */
    /*   private void EnableVerticalButtons()
       {
           Xline.SetActive(false);
           Yline.SetActive(true);
           SetButtonState(new[] { btx7, btx8, btx9, btx1, bt11, bt12 }, true);
           SetButtonState(new[] { btxy, btx2, btx3, btx4, btx5, btx6 }, false);
           Yline.SetActive(true);
           Xline.SetActive(false);
       }
    */

    /* private void EnableButtonsForCloseDistance()
     {
         float yRotation = transform.rotation.eulerAngles.y;


         if (yRotation > 180f)
         {
             yRotation -= 360f;
         }

         if (Mathf.Abs(yRotation) <= 45f || Mathf.Abs(yRotation) >= 135f)
         {
             EnableHorizontalButtons();
             // Debug.Log("horizontal");
         }
         else
         {
             EnableVerticalButtons();
             //  Debug.Log("vertical");
         }
     }*/
}

