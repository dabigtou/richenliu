using UnityEngine;

public class SlerpSyncRotation : MonoBehaviour
{
    public Transform target;
    public float speed = 5f;

    void Update()
    {

        if (target != null)
        {
            transform.rotation = Quaternion.Slerp(transform.rotation, target.rotation, Time.deltaTime * speed) * Quaternion.Euler(90, 0, 0);
        }
    }
}
