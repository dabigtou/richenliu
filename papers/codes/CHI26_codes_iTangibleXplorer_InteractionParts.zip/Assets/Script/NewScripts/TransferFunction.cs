using Unity.Collections.LowLevel.Unsafe;
using UnityEngine;
using UnityEngine.UI;
using Vuforia;
using TMPro;
public class TransferFunction : MonoBehaviour
{
    float time = 0;
    int cnt = 0;
    public TMPro.TextMeshProUGUI text;
    public VirtualButtonBehaviour bt1;
    public VirtualButtonBehaviour bt2;
    public VirtualButtonBehaviour bt3;
    public VirtualButtonBehaviour bt4;
    public VirtualButtonBehaviour bt5;
    public VirtualButtonBehaviour bt6;

    public VirtualButtonBehaviour bt7;
    public VirtualButtonBehaviour bt8;
    public VirtualButtonBehaviour bt9;
    public VirtualButtonBehaviour bt10;
    public VirtualButtonBehaviour bt11;
    public VirtualButtonBehaviour bt12;

    public VirtualButtonBehaviour bt13;
    public VirtualButtonBehaviour bt14;
    public VirtualButtonBehaviour bt15;
    public VirtualButtonBehaviour bt16;
    public VirtualButtonBehaviour bt17;
    public VirtualButtonBehaviour bt18;

    public VirtualButtonBehaviour bt22;
    public VirtualButtonBehaviour bt23;

    public UnityEngine.UI.Image vessel1, vessel2, finger, bone,skin,btP,btC,btO;
    public RawImage Alpha;
    public GameObject line_O, line_C;
    private Vector3 initialPosition_O;
    private Vector3 initialPosition_C;

    public GameObject Slidercontroller;
    public GameObject Colorpick,hue,alpha,slider;
    private Slider sliderComponent;
    bool isActive;

    void Start()
    {
        bt1.RegisterOnButtonPressed(OnButtonPressed);
        bt1.RegisterOnButtonReleased(OnButtonReleased);
        bt2.RegisterOnButtonPressed(OnButtonPressed);
        bt2.RegisterOnButtonReleased(OnButtonReleased);
        bt3.RegisterOnButtonPressed(OnButtonPressed);
        bt3.RegisterOnButtonReleased(OnButtonReleased);
        bt4.RegisterOnButtonPressed(OnButtonPressed);
        bt4.RegisterOnButtonReleased(OnButtonReleased);
        bt5.RegisterOnButtonPressed(OnButtonPressed);
        bt5.RegisterOnButtonReleased(OnButtonReleased);
        bt6.RegisterOnButtonPressed(OnButtonPressed);
        bt6.RegisterOnButtonReleased(OnButtonReleased);
        bt7.RegisterOnButtonPressed(OnButtonPressed); 
        bt7.RegisterOnButtonReleased(OnButtonReleased);
        bt8.RegisterOnButtonPressed(OnButtonPressed);
        bt8.RegisterOnButtonReleased(OnButtonReleased);
        bt9.RegisterOnButtonPressed(OnButtonPressed);
        bt9.RegisterOnButtonReleased(OnButtonReleased);
        bt10.RegisterOnButtonPressed(OnButtonPressed);
        bt10.RegisterOnButtonReleased(OnButtonReleased);
        bt11.RegisterOnButtonPressed(OnButtonPressed);
        bt11.RegisterOnButtonReleased(OnButtonReleased);
        bt12.RegisterOnButtonPressed(OnButtonPressed);
        bt12.RegisterOnButtonReleased(OnButtonReleased);
        bt13.RegisterOnButtonPressed(OnButtonPressed);
        bt13.RegisterOnButtonReleased(OnButtonReleased);
        bt14.RegisterOnButtonPressed(OnButtonPressed);
        bt14.RegisterOnButtonReleased(OnButtonReleased);
        bt15.RegisterOnButtonPressed(OnButtonPressed);
        bt15.RegisterOnButtonReleased(OnButtonReleased);
        bt16.RegisterOnButtonPressed(OnButtonPressed);
        bt16.RegisterOnButtonReleased(OnButtonReleased);
        bt17.RegisterOnButtonPressed(OnButtonPressed);
        bt17.RegisterOnButtonReleased(OnButtonReleased);
        bt18.RegisterOnButtonPressed(OnButtonPressed);
        bt18.RegisterOnButtonReleased(OnButtonReleased);
        bt22.RegisterOnButtonPressed(OnButtonPressed);
        bt22.RegisterOnButtonReleased(OnButtonReleased);
        bt23.RegisterOnButtonPressed(OnButtonPressed);
        bt23.RegisterOnButtonReleased(OnButtonReleased);
        sliderComponent = Slidercontroller.GetComponent<Slider>();

        isActive= false;
        SetButtonState(new[] { bt1, bt7, bt13 }, true);
        SetButtonState(new[] { bt2, bt3, bt4, bt5, bt6 }, false);
        SetButtonState(new[] { bt8, bt9, bt10, bt11, bt12, bt22, bt23 }, false);
        SetButtonState(new[] { bt14, bt15, bt16, bt17, bt18 }, false);

         initialPosition_C = line_C.transform.localPosition;
         initialPosition_O= line_O.transform.localPosition;

        ChangeColor(Alpha, 255, 255, 255);
    }

    public void OnButtonPressed(VirtualButtonBehaviour vb)
    {
        Vector3 currentPosition_O = line_O.transform.localPosition;
        Vector3 currentPosition_C = line_C.transform.localPosition;

        switch (vb.VirtualButtonName)
        {
            case "bt1":
                if(isActive==false)
                {
                    ChangeColor(btP, 150, 205, 255);
                    Setgroup1();
                    isActive = !isActive;
                }
                else
                {
                    ChangeColor(btP, 255, 255, 255);
                    SetAll();
                    isActive=!isActive;
                }
                Debug.Log("bt1");
                break;
            case "bt2":
                sliderComponent.value = -4f;
                SetPrewview(vessel1, vessel2, finger, bone, skin);
                
                Debug.Log("bt2");
                break;
            case "bt3":
                sliderComponent.value = -2.3f;
                SetPrewview(vessel2, vessel1, finger, bone, skin);
              
                Debug.Log("bt3");
                break;
            case "bt4":
                sliderComponent.value = -0.31f;

                SetPrewview(finger, vessel2, vessel1, bone, skin);
                Debug.Log("bt4");
                break;
            case "bt5":
                sliderComponent.value =1.76f;

                SetPrewview(bone, vessel2, finger, vessel1, skin);
                Debug.Log("bt5");
                break;
            case "bt6":
                sliderComponent.value = 4f;

                SetPrewview(skin, vessel2, finger, bone, vessel1);
                Debug.Log("bt6");
                break;
            case "bt7":
                cnt++;
                if (isActive == false)
                {
                    ChangeColor(btC, 150, 205, 255);
                    Setgroup2();
                    isActive = !isActive;
                }
                else
                {
                    ChangeColor(btC, 255, 255, 255);
                    SetAll();
                    isActive = !isActive;
                }
                Debug.Log("bt7");
                break;
            case "bt8":
                cnt++;
                ChangeColor(vessel1, 255, 0, 0);
                ChangeColor(vessel2, 255, 0, 0);
                ChangeColor(finger, 255, 0, 0);
                ChangeColor(bone, 255, 0, 0);
                ChangeColor(skin, 255, 0, 0);
                ChangeColor(Alpha, 255, 0, 0);
                currentPosition_C.x = bt8.transform.localPosition.x;
                line_C.transform.localPosition = currentPosition_C;
                Debug.Log("bt8");
                break;
            case "bt9":
                cnt++;
                currentPosition_C.x = bt9.transform.localPosition.x;
               line_C.transform.localPosition = currentPosition_C;

                ChangeColor(vessel1, 255, 136, 0);
                ChangeColor(vessel2 , 255, 136, 0);
                ChangeColor(finger, 255, 136,0);
                ChangeColor(bone, 255, 136, 0);
                ChangeColor(skin, 255, 136, 0);
                ChangeColor(Alpha, 255, 136, 0);

                Debug.Log("bt9");
                break;
            case "bt10":
                cnt++;
                currentPosition_C.x = bt10.transform.localPosition.x;
                line_C.transform.localPosition = currentPosition_C;

                ChangeColor(vessel1, 255, 252, 0);
                ChangeColor(vessel2, 255, 252, 0);
                ChangeColor(finger, 255, 252, 0);
                ChangeColor(bone, 255, 252, 0);
                ChangeColor(skin, 255, 252, 0);
                ChangeColor(Alpha, 255, 252, 0);

                Debug.Log("bt10");
                break;
            case "bt11":
                cnt++;
              currentPosition_C.x = bt11.transform.localPosition.x;
              line_C.transform.localPosition = currentPosition_C;
                ChangeColor(vessel1, 35, 255, 0);
                ChangeColor(vessel2, 35, 255, 0);
                ChangeColor(finger, 35, 255, 0);
                ChangeColor(bone, 35, 255, 0);
                ChangeColor(skin, 35, 255, 0);
                ChangeColor(Alpha, 35, 255, 0);

                Debug.Log("bt11");
                break;
            case "bt12":
                cnt++;
                currentPosition_C.x = bt12.transform.localPosition.x;
                line_C.transform.localPosition = currentPosition_C;

                ChangeColor(vessel1, 0, 255, 255);
                ChangeColor(vessel2, 0, 255, 255);
                ChangeColor(finger, 0, 255, 255);
                ChangeColor(bone, 0, 255, 255);
                ChangeColor(skin, 0, 255, 255);
                ChangeColor(Alpha, 0, 155, 255);

                Debug.Log("bt12");
                break;
            case "btextra1":
                currentPosition_C.x = bt22.transform.localPosition.x;
                line_C.transform.localPosition = currentPosition_C;

                ChangeColor(vessel1, 0, 0, 255);
                ChangeColor(vessel2, 0, 0, 255);
                ChangeColor(finger, 0, 0, 255);
                ChangeColor(bone, 0, 0, 255);
                ChangeColor(skin, 0, 0, 255);
                ChangeColor(Alpha, 0, 0, 255);

                Debug.Log("bt22");
                break;
            case "btextra2":
                currentPosition_C.x = bt23.transform.localPosition.x;
                line_C.transform.localPosition = currentPosition_C;

                ChangeColor(vessel1, 255, 0, 255);
                ChangeColor(vessel2, 255, 0, 255);
                ChangeColor(finger, 255, 0, 255);
                ChangeColor(bone, 255, 0, 255);
                ChangeColor(skin, 255, 0, 255);
                ChangeColor(Alpha, 175, 0, 255);

                Debug.Log("bt23");
                break;

            case "bt13":
                if (isActive == false)
                {
                    ChangeColor(btO, 150, 205, 255);
                    Setgroup3();
                    isActive = !isActive;
                }
                else
                {
                    ChangeColor(btO, 255, 255, 255);
                    SetAll();
                    isActive = !isActive;
                }
                Debug.Log("bt13");
                break;
            case "bt14":
                currentPosition_O.x = bt14.transform.localPosition.x;
                line_O.transform.localPosition = currentPosition_O;
                ChangeAlpha(vessel1,255);
                ChangeAlpha(vessel2,255);
                ChangeAlpha(finger,255);
                ChangeAlpha(bone,255);
                ChangeAlpha(skin,255);
                Debug.Log("bt14");
                break;
            case "bt15":
                currentPosition_O.x = bt15.transform.localPosition.x;
                line_O.transform.localPosition = currentPosition_O;
                ChangeAlpha(vessel1, 204);
                ChangeAlpha(vessel2, 204);
                ChangeAlpha(finger, 204);
                ChangeAlpha(bone, 204);
                ChangeAlpha(skin, 204);
                Debug.Log("bt15");
                break;
            case "bt16":
                currentPosition_O.x = bt16.transform.localPosition.x;
                line_O.transform.localPosition = currentPosition_O;

                ChangeAlpha(vessel1, 153);
                ChangeAlpha(vessel2, 153);
                ChangeAlpha(finger, 153);
                ChangeAlpha(bone, 153);
                ChangeAlpha(skin, 153);
                Debug.Log("bt16");
                break;
            case "bt17":
                currentPosition_O.x = bt17.transform.localPosition.x;
                line_O.transform.localPosition = currentPosition_O;

                ChangeAlpha(vessel1, 102);
                ChangeAlpha(vessel2, 102);
                ChangeAlpha(finger, 102);
                ChangeAlpha(bone, 102);
                ChangeAlpha(skin, 102);
                Debug.Log("bt17");
                break;
            case "bt18":
                currentPosition_O.x = bt18.transform.localPosition.x;
                line_O.transform.localPosition = currentPosition_O;

                ChangeAlpha(vessel1, 51);
                ChangeAlpha(vessel2, 51);
                ChangeAlpha(finger, 51);
                ChangeAlpha(bone, 51);
                ChangeAlpha(skin, 51);
                Debug.Log("bt18");
                break;
         

        }
    }

    public void OnButtonReleased(VirtualButtonBehaviour vb)
    {

    }

    private void SetPrewview(UnityEngine.UI.Image image1, UnityEngine.UI.Image image2, UnityEngine.UI.Image image3, UnityEngine.UI.Image image4, UnityEngine.UI.Image image5)
    {
        image1.gameObject.SetActive(true);
        image2.gameObject.SetActive(false);
        image3.gameObject.SetActive(false);
        image4.gameObject.SetActive(false);
        image5.gameObject.SetActive(false);
    }
     
    private void ChangeColor(UnityEngine.UI.Image targetImage, float r,float g,float b)
    {
        Color currentColor = targetImage.color;
        Color newColor = new Color(r/255f, g/255f, b/255f, currentColor.a);
        targetImage.color = newColor;
    }

    private void ChangeColor(RawImage targetImage, float r, float g, float b)
    {
        Color currentColor = targetImage.color;
        Color newColor = new Color(r / 255f, g / 255f, b / 255f, currentColor.a);
        targetImage.color = newColor;
    }

    private void ChangeAlpha(UnityEngine.UI.Image targetImage,  float a)
    {
        Color currentColor = targetImage.color;
        Color newColor = new Color(currentColor.r,currentColor.g,currentColor.b,a/255f);
        targetImage.color = newColor;
    }

   

    private void Setgroup1()
    {
        SetButtonState(new[] { bt1,bt2, bt3, bt4, bt5, bt6 }, true);
        SetButtonState(new[] { bt7,bt8, bt9, bt10, bt11, bt12,bt22,bt23 }, false);
        SetButtonState(new[] { bt13,bt14, bt15, bt16, bt17, bt18 }, false);
        slider.SetActive(true);
        
        hue.SetActive(false);
        Colorpick.SetActive(false);
        alpha.SetActive(false);
        line_C.SetActive(false);
        line_O.SetActive(false);
       // Colorpick,hue,alpha,slider
    }

    private void Setgroup2()
    {
        SetButtonState(new[] {bt1, bt2, bt3, bt4, bt5, bt6 }, false);
        SetButtonState(new[] {bt7, bt8, bt9, bt10, bt11, bt12, bt22, bt23 }, true);
        SetButtonState(new[] { bt13, bt15, bt16, bt17, bt18 }, false);
        slider.SetActive(false);
        hue.SetActive(true);
        Colorpick.SetActive(true);
        alpha.SetActive(false);
        line_C.SetActive(true);
        line_O.SetActive(false);
    }

    private void Setgroup3()
    {
        SetButtonState(new[] { bt2, bt3, bt4, bt5, bt6 }, false);
        SetButtonState(new[] { bt7,bt8, bt9, bt10, bt11, bt12, bt22, bt23 }, false);
        SetButtonState(new[] { bt13,bt14, bt15, bt16, bt17, bt18 }, true);
        slider.SetActive(false);
        hue.SetActive(false);
        Colorpick.SetActive(false);
        alpha.SetActive(true);
        line_C.SetActive(false);
        line_O.SetActive(true);
    }

    private void SetAll()
    {
        slider.SetActive(true);
        hue.SetActive(true);
        Colorpick.SetActive(true);
        alpha.SetActive(true);
        SetButtonState(new[] { bt1, bt7, bt13 }, true);
        SetButtonState(new[] { bt2, bt3, bt4, bt5, bt6 }, false);
        SetButtonState(new[] { bt8, bt9, bt10, bt11, bt12, bt22, bt23 }, false);
        SetButtonState(new[] { bt14, bt15, bt16, bt17, bt18 }, false);
    }
    private void SetButtonState(VirtualButtonBehaviour[] buttons, bool state)
    {
        foreach (var button in buttons)
        {
            button.enabled = state;
            button.gameObject.SetActive(state);
        }
    }
     
    public void press_btn()
    {
        time = 0;
    }
    private void Update()
    {
        time += Time.deltaTime; ;
        if (cnt >= 7 && cnt <= 100)
        {
            Debug.Log("Time = " + time);
            cnt = 101;
            text.text = "Time = " + time;
        }
        Debug.Log(cnt);
    }
}
