using UnityEngine;
using Vuforia;
public class Slicing3 : MonoBehaviour
{
    public GameObject excluder_x;
    public GameObject excluder_y;
    public GameObject excluder_z;
   // public GameObject excluder_slicing;
    /*   public GameObject excluder2;
       public GameObject excluder3;
       public GameObject excluder4;
       public GameObject excluder5;
       public GameObject excluder6;
       public GameObject excluder7;
       public GameObject excluder8;*/
    public Camera ARcamera;
    public GameObject Xline, Yline; // ���� Xline, Yline, Zline
    public VirtualButtonBehaviour btx2;
    public VirtualButtonBehaviour btx3;
    public VirtualButtonBehaviour btx4;
    public VirtualButtonBehaviour btx5;
    public VirtualButtonBehaviour btx6;
    public VirtualButtonBehaviour btx7;
    public VirtualButtonBehaviour btx8;
    public VirtualButtonBehaviour bty1;
    public VirtualButtonBehaviour bty2;
    public VirtualButtonBehaviour bty3;
    public VirtualButtonBehaviour bty4;
    public VirtualButtonBehaviour bty5;

    private Vector3 initiallocalPosition_x, initiallocalPosition_y, initiallocalPosition_z;
    private Vector3 initiallocalX;
    // private Vector3 initialXlinePos, initialYlinePos, initialZlinePos; // �洢�����ĳ�ʼ localPosition
    private TrackableBehaviour mTrackableBehaviour;
    public float distanceThreshold = 5f;

    public float position_far=3.5f;
    public float position_near=2.0f;

    void Start()
    {
        // mTrackableBehaviour = GetComponent<TrackableBehaviour>();
        // if (mTrackableBehaviour)
        // {
        //    mTrackableBehaviour.RegisterOnTrackableStatusChanged(OnTrackableStatusChanged);
        // }

        RegisterButtonEvents();

        // �洢��ʼ��ת�������� localPosition
        initiallocalPosition_x = excluder_x.transform.localPosition;
        initiallocalPosition_y = excluder_y.transform.localPosition;
        initiallocalPosition_z = excluder_z.transform.localPosition;
        initiallocalX = Yline.transform.localPosition;
        //  initialXlinePos = Xline.transform.localPosition;
        //  initialYlinePos = Yline.transform.localPosition;
        //  initialZlinePos = Zline.transform.localPosition;

        // ��ʼ�������ͽ��ð�ť
        EnableAllButtons();
        //InvokeRepeating("LogEulerAngles", 0f, 5f);

    }

    private void Update()
    {
        CheckDistance();

    }

    //  void LogEulerAngles()
    //{
    // ��ȡ�����ŷ����
    //  Vector3 eulerAngles = transform.eulerAngles;

    // ���ŷ���ǵ�����̨
    //Debug.Log("Euler Angles: " + eulerAngles);
    // }

    public void OnTrackableStatusChanged(TrackableBehaviour.StatusChangeResult statusChangeResult)
    {
        TrackableBehaviour.Status newStatus = statusChangeResult.NewStatus;
        if (newStatus == TrackableBehaviour.Status.DETECTED || newStatus == TrackableBehaviour.Status.TRACKED)
        {
            CheckDistance();
        }
    }

    private void RegisterButtonEvents()
    {
        VirtualButtonBehaviour[] buttons = {
            btx2, btx3, btx4, btx5, btx6, btx7, btx8, bty1, bty2,
            bty3, bty4, bty5 };

        foreach (var button in buttons)
        {
            button.RegisterOnButtonPressed(OnButtonPressed);
            button.RegisterOnButtonReleased(OnButtonReleased);
        }
    }

    private void CheckDistance()
    {
        float distance = Vector3.Distance(transform.position, ARcamera.transform.position);

         if(distance>=position_near&&distance<=position_far)
        {

            excluder_x.SetActive(false);
            excluder_y.SetActive(false);
            excluder_z.SetActive(true);
            Xline.SetActive(false);
            Yline.SetActive(false);
            double realtime_z=-(distance- position_near) /(position_far-position_near)*0.9+0.45;
          //  Vector3 presentPositionY = new Vector3(excluder_slicing.transform.localPosition.x, (float)realtime_z, excluder_slicing.transform.localPosition.z);
            Vector3 presentPositionZ = new Vector3(excluder_z.transform.localPosition.x, excluder_z.transform.localPosition.y, (float)realtime_z);
            excluder_z.transform.localPosition = presentPositionZ;
         //   excluder_slicing.transform.localPosition = presentPositionZ;

        }

        else
        {
            excluder_x.SetActive(true);
            excluder_y.SetActive(true);
            excluder_z.SetActive(false);
            Xline.SetActive(true);
            Yline.SetActive(true);
        }
        //  if (distance > distanceThreshold)
        // {
        //      EnableButtonsForFarDistance();
        // Debug.Log("far");
        //  }
        //  else
        //  {
        //      EnableButtonsForCloseDistance();
        //  Debug.Log("close");
        //  }

        Debug.Log(distance);
    }

    private void DisableAllButtons()
    {
        VirtualButtonBehaviour[] buttons = {
            btx2, btx3, btx4, btx5, btx6, btx7, btx8, bty1, bty2,
            bty3, bty4, bty5
        };

        foreach (var button in buttons)
        {
            button.enabled = false;
            button.gameObject.SetActive(false);
        }
    }

    public void OnButtonPressed(VirtualButtonBehaviour vb)
    {
        Vector3 presentPositionX = new Vector3(initiallocalPosition_x.x, excluder_x.transform.localPosition.y, excluder_x.transform.localPosition.z);
        Vector3 presentPositionY = new Vector3(excluder_y.transform.localPosition.x, initiallocalPosition_y.y, excluder_y.transform.localPosition.z);
        Vector3 presentPositionZ = new Vector3(excluder_z.transform.localPosition.x, excluder_z.transform.localPosition.y, initiallocalPosition_z.z);
     /*   Vector3 presentPositionX2 = new Vector3(initiallocalPosition2.x, excluder2.transform.localPosition.y, excluder2.transform.localPosition.z);
        Vector3 presentPositionY2 = new Vector3(excluder2.transform.localPosition.x, initiallocalPosition2.y, excluder2.transform.localPosition.z);
        Vector3 presentPositionZ2 = new Vector3(excluder2.transform.localPosition.x, excluder2.transform.localPosition.y, initiallocalPosition2.z);
        Vector3 presentPositionX3 = new Vector3(initiallocalPosition3.x, excluder3.transform.localPosition.y, excluder3.transform.localPosition.z);
        Vector3 presentPositionY3 = new Vector3(excluder3.transform.localPosition.x, initiallocalPosition3.y, excluder3.transform.localPosition.z);
        Vector3 presentPositionZ3= new Vector3(excluder3.transform.localPosition.x, excluder3.transform.localPosition.y, initiallocalPosition3.z);
        Vector3 presentPositionX4 = new Vector3(initiallocalPosition4.x, excluder4.transform.localPosition.y, excluder4.transform.localPosition.z);
        Vector3 presentPositionY4 = new Vector3(excluder4.transform.localPosition.x, initiallocalPosition4.y, excluder4.transform.localPosition.z);
        Vector3 presentPositionZ4 = new Vector3(excluder4.transform.localPosition.x, excluder4.transform.localPosition.y, initiallocalPosition4.z);
        Vector3 presentPositionX5 = new Vector3(initiallocalPosition5.x, excluder5.transform.localPosition.y, excluder5.transform.localPosition.z);
        Vector3 presentPositionY5 = new Vector3(excluder5.transform.localPosition.x, initiallocalPosition5.y, excluder5.transform.localPosition.z);
        Vector3 presentPositionZ5 = new Vector3(excluder5.transform.localPosition.x, excluder5.transform.localPosition.y, initiallocalPosition5.z);
        Vector3 presentPositionX6 = new Vector3(initiallocalPosition6.x, excluder6.transform.localPosition.y, excluder6.transform.localPosition.z);
        Vector3 presentPositionY6 = new Vector3(excluder6.transform.localPosition.x, initiallocalPosition6.y, excluder6.transform.localPosition.z);
        Vector3 presentPositionZ6 = new Vector3(excluder6.transform.localPosition.x, excluder6.transform.localPosition.y, initiallocalPosition6.z);
        Vector3 presentPositionX7 = new Vector3(initiallocalPosition7.x, excluder7.transform.localPosition.y, excluder7.transform.localPosition.z);
        Vector3 presentPositionY7 = new Vector3(excluder7.transform.localPosition.x, initiallocalPosition7.y, excluder7.transform.localPosition.z);
        Vector3 presentPositionZ7 = new Vector3(excluder7.transform.localPosition.x, excluder7.transform.localPosition.y, initiallocalPosition7.z);
        Vector3 presentPositionX8 = new Vector3(initiallocalPosition8.x, excluder8.transform.localPosition.y, excluder8.transform.localPosition.z);
        Vector3 presentPositionY8 = new Vector3(excluder8.transform.localPosition.x, initiallocalPosition8.y, excluder8.transform.localPosition.z);
        Vector3 presentPositionZ8 = new Vector3(excluder8.transform.localPosition.x, excluder8.transform.localPosition.y, initiallocalPosition8.z);*/
      
        Vector3 currentPositionX = Xline.transform.localPosition;
        Vector3 currentPositionY = Yline.transform.localPosition;
        currentPositionY.x = initiallocalX.x;

        switch (vb.VirtualButtonName)
        {
            case "btx2":
                excluder_x.transform.localPosition = presentPositionX + new Vector3(0f, 0.0f, 0.0f);
                currentPositionX.x = btx2.transform.localPosition.x;
              /*  excluder2.transform.localPosition = presentPositionX2 + new Vector3(0f, 0.0f, 0.0f);
                currentPositionX.x = btx2.transform.localPosition.x;
                excluder3.transform.localPosition = presentPositionX3 + new Vector3(0f, 0.0f, 0.0f);
                currentPositionX.x = btx2.transform.localPosition.x;
                excluder4.transform.localPosition = presentPositionX4 + new Vector3(0f, 0.0f, 0.0f);
                currentPositionX.x = btx2.transform.localPosition.x;
                excluder5.transform.localPosition = presentPositionX5 + new Vector3(0f, 0.0f, 0.0f);
                currentPositionX.x = btx2.transform.localPosition.x;
                excluder6.transform.localPosition = presentPositionX6 + new Vector3(0f, 0.0f, 0.0f);
                currentPositionX.x = btx2.transform.localPosition.x;
                excluder7.transform.localPosition = presentPositionX7 + new Vector3(0f, 0.0f, 0.0f);
                currentPositionX.x = btx2.transform.localPosition.x;
                excluder8.transform.localPosition = presentPositionX8 + new Vector3(0f, 0.0f, 0.0f);
                currentPositionX.x = btx2.transform.localPosition.x;*/
                Xline.transform.localPosition = currentPositionX;
                Debug.Log("btx2");
                break;
            case "btx3":
                excluder_x.transform.localPosition = presentPositionX + new Vector3(-0.15f, 0.0f, 0.0f);
                currentPositionX.x = btx3.transform.localPosition.x;
            /*    excluder2.transform.localPosition = presentPositionX2 + new Vector3(0f, 0.0f, 0.0f);
                currentPositionX.x = btx3.transform.localPosition.x;
                excluder3.transform.localPosition = presentPositionX3 + new Vector3(0f, 0.0f, 0.0f);
                currentPositionX.x = btx3.transform.localPosition.x;
                excluder4.transform.localPosition = presentPositionX4 + new Vector3(0f, 0.0f, 0.0f);
                currentPositionX.x = btx3.transform.localPosition.x;
                excluder5.transform.localPosition = presentPositionX5 + new Vector3(0f, 0.0f, 0.0f);
                currentPositionX.x = btx3.transform.localPosition.x;
                excluder6.transform.localPosition = presentPositionX6 + new Vector3(0f, 0.0f, 0.0f);
                currentPositionX.x = btx3.transform.localPosition.x;
                excluder7.transform.localPosition = presentPositionX7 + new Vector3(0f, 0.0f, 0.0f);
                currentPositionX.x = btx3.transform.localPosition.x;
                excluder8.transform.localPosition = presentPositionX8 + new Vector3(0f, 0.0f, 0.0f);
                currentPositionX.x = btx3.transform.localPosition.x;*/
                Xline.transform.localPosition = currentPositionX;
                Debug.Log("btx3");
                break;
            case "btx4":
                excluder_x.transform.localPosition = presentPositionX + new Vector3(-0.3f, 0.0f, 0.0f);
                currentPositionX.x = btx4.transform.localPosition.x;
                Xline.transform.localPosition = currentPositionX;
                Debug.Log("btx4");
                break;
            case "btx5":
                excluder_x.transform.localPosition = presentPositionX + new Vector3(-0.45f, 0.0f, 0.0f);
                currentPositionX.x = btx5.transform.localPosition.x;
                Xline.transform.localPosition = currentPositionX;
                Debug.Log("btx5");
                break;
            case "btx6":
                excluder_x.transform.localPosition = presentPositionX + new Vector3(-0.6f, 0.0f, 0.0f);
                currentPositionX.x = btx6.transform.localPosition.x;
                Xline.transform.localPosition = currentPositionX;
                Debug.Log("btx6");
                break;
            case "btx7":
                excluder_x.transform.localPosition = presentPositionX + new Vector3(-0.75f, 0.0f, 0.0f);
                currentPositionX.x = btx7.transform.localPosition.x;
                Xline.transform.localPosition = currentPositionX;
                Debug.Log("btx7");
                break;
            case "btx8":
                excluder_x.transform.localPosition = presentPositionX + new Vector3(-0.90f, 0.0f, 0.0f);
                currentPositionX.x = btx8.transform.localPosition.x;
                Xline.transform.localPosition = currentPositionX;
                Debug.Log("btx8");
                break;
            case "bty1":
                excluder_y.transform.localPosition = presentPositionY + new Vector3(0.0f, 0.0f, 0.0f);
                currentPositionY.z = bty1.transform.localPosition.z;
                Yline.transform.localPosition = currentPositionY;
                Debug.Log("bty1");
                break;
            case "bty2":
                excluder_y.transform.localPosition = presentPositionY + new Vector3(0.0f, 0.225f, 0.0f);
                currentPositionY.z = bty2.transform.localPosition.z;
                Yline.transform.localPosition = currentPositionY;
                Debug.Log("bty2");
                break;
            case "bty3":
                excluder_y.transform.localPosition = presentPositionY + new Vector3(0.0f, 0.45f, 0.0f);
                currentPositionY.z = bty3.transform.localPosition.z;
                Yline.transform.localPosition = currentPositionY;
                Debug.Log("bty3");
                break;
            case "bty4":
                excluder_y.transform.localPosition = presentPositionY + new Vector3(0.0f, 0.675f, 0.0f);
                currentPositionY.z = bty4.transform.localPosition.z;
                Yline.transform.localPosition = currentPositionY;
                Debug.Log("bty4");
                break;
            case "bty5":
                excluder_y.transform.localPosition = presentPositionY + new Vector3(0.0f, 0.9f, 0.0f);
                currentPositionY.z = bty5.transform.localPosition.z;
                Yline.transform.localPosition = currentPositionY;
                Debug.Log("bty5");
                break;
           
        }
    }

    public void OnButtonReleased(VirtualButtonBehaviour vb)
    {
        // �ɸ�����Ҫ�����߼�
    }
    private void SetButtonState(VirtualButtonBehaviour[] buttons, bool state)
    {
        foreach (var button in buttons)
        {
            button.enabled = state;
            button.gameObject.SetActive(state);
        }
    }

    private void EnableAllButtons()
    {
        SetButtonState(new[] { btx2, btx3, btx4, btx5, btx6, btx7 }, true);
        SetButtonState(new[] { btx8, bty1, bty2, bty3, bty4, bty5 }, true);
        Xline.SetActive(true);
        Yline.SetActive(true);
    }

    private void EnableVerticalButtons()
    {
        SetButtonState(new[] { btx8, bty1, bty2, bty3, bty4, bty5 }, true);
        SetButtonState(new[] { btx2, btx3, btx4, btx5, btx6, btx7 }, false);
        Xline.SetActive(false);
        Yline.SetActive(true);
    }

 

  
    /*  private void EnableButtonsForCloseDistance()
      {
          Quaternion currentRotation = transform.rotation;

          float yRotation = currentRotation.eulerAngles.y;

          SetButtonState(new[] { bt13, bt14, bt15, bt16, bt17, bt18 }, false);

          if (yRotation > 180f)
          {
              yRotation -= 360f;
          }

          if (Mathf.Abs(yRotation) <= 45f || Mathf.Abs(yRotation) >= 135f)
          {
              EnableHorizontalButtons();
              // Debug.Log("horizontal");
          }
          else
          {
              EnableVerticalButtons();
              //  Debug.Log("vertical");
          }
      }


  */

}
