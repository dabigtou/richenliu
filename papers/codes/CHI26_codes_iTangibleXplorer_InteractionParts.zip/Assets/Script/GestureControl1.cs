using UnityEngine.UI;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GestureControl1 : MonoBehaviour
{
    
    public GameObject mControObj;
    public GameObject mControObj1;
    public GameObject brain;
    public int flag = 0;



    private void Update()
    {
    
        mControObj1.transform.localRotation = transform.rotation;
        if(flag==1)
            brain.transform.localRotation = transform.rotation;
      


    }
    
   

    
   
    
 

}