using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class button : MonoBehaviour
{
    private bool isclick = false;
    public void Click()
    {
        if(isclick==false)
        {
            gameObject.SetActive(false);
            isclick = true;
        }
        else
        {
            gameObject.SetActive(true);
            isclick = false;
        }

    }
  
}
