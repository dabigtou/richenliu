using UnityEngine.UI;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FingerPalm1 : MonoBehaviour
{

    public Slider slider, slider2;
    public RawImage ri;
    public Image img1, img2, img3, img4,img5,img6,img7,img8,img9,img10,img11;

    public Scrollbar scrollbarHue;//ɫ����
    public Scrollbar scrollbarHue2;//͸����
    int flag = 1;

    public Button b1, b2, b3;
    public GameObject main;
    private void Update()
    {



        img1.color = ri.color;
        img2.color = ri.color;
        img3.color = ri.color;
        img4.color = ri.color;
        img5.color = ri.color;
        img6.color = ri.color;
        img7.color = ri.color;
        img8.color = ri.color;
        img9.color = ri.color;
        img10.color = ri.color;
        img11.color = ri.color;
        /*
        if (flag == 1)
            OnMoving2();//����ƻ���
        else if (flag == 2)
            OnMoving();//��ɫ�ʻ���
        else if (flag == 3)
            OnMoving3();
        else
            OnMoving4();

        */
        if(main!=null)
        {
            int flag = main.GetComponent<MainController1>().flag;
            if (flag == 41)
                b1.GetComponent<Image>().color = new Color(97f / 255f, 157f / 255f, 217f / 255f);
            else
                b1.GetComponent<Image>().color = Color.white;
            if (flag == 42)
                b2.GetComponent<Image>().color = new Color(97f / 255f, 157f / 255f, 217f / 255f);
            else
                b2.GetComponent<Image>().color = Color.white;
            if (flag == 43)
                b3.GetComponent<Image>().color = new Color(97f / 255f, 157f / 255f, 217f / 255f);
            else
                b3.GetComponent<Image>().color = Color.white;

        }

    }

    public void Changeflag1()
    {
        flag = 1;
    }
    public void Changeflag2()
    {
        flag = 2;
    }
    public void Changeflag3()
    {
        flag = 3;
    }
    
}