using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class ChangeScenes : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void CutBrain()
    {
        SceneManager.LoadScene("CUT Brain");
    }
    public void CutLung()
    {
        SceneManager.LoadScene("CUT Lung");
    }
    public void MeasureLung()
    {
        SceneManager.LoadScene("measureTumorLung");
    }
    public void MeasureBrain()
    {
        SceneManager.LoadScene("measureTumorBrain");
    }
    public void Hand()
    {
        SceneManager.LoadScene("Hand");
    }
}
