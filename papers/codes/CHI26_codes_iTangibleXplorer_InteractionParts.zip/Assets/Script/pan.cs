using UnityEngine.UI;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Vuforia;
using VolumeViewer;
public class pan : MonoBehaviour
{

    public GameObject navigation;
    public GameObject pann;
    public GameObject view,volume;
    public GameObject brain,cam;
    VirtualButtonBehaviour[] vbs;
    public int flag = 0;
    public int flag2 = 0;
    private Vector3 object2Offset; // ����2���������1��λ��ƫ��
    public Camera mainCamera; // �������

    void Start()
    {
        // ��¼����2��ʼʱ���������1��ƫ����
        object2Offset = view.transform.position - pann.transform.position;
        vbs = GetComponentsInChildren<VirtualButtonBehaviour>();
        for (int i = 0; i < vbs.Length; i++)
        {
            vbs[i].RegisterOnButtonPressed(OnButtonPressed);
            vbs[i].RegisterOnButtonReleased(OnButtonReleased);
        }
    }
    //��ť�ͷ�ʱ
    private void OnButtonReleased(VirtualButtonBehaviour vb)
    {

    }


    private void Update()
    {
        if(flag==3)
        {
            volume.transform.localRotation = navigation.transform.rotation;
            brain.transform.localRotation = navigation.transform.rotation;
        }
        

        if (flag == 1)
        {
            Follow();
        }

        if(flag2 == 0)
        {
            brain.SetActive(false);
            mainCamera.GetComponent<VolumeRenderer>().enabled =false;
            cam.SetActive(false);
            view.SetActive(true);
        }
        else
        {
            brain.SetActive(true);
            mainCamera.GetComponent<VolumeRenderer>().enabled =true;
            view.SetActive(false);
            cam.SetActive(true);
        }
    }

    // ��view����pann����Ļ����
    void FollowObject()
    {
        // ��ȡpann����Ļ����
        Vector3 pannScreenPos = mainCamera.WorldToScreenPoint(pann.transform.position);

        // ����Ļ����ת�����������꣨����view���������Z����뱣�ֲ��䣩
        Vector3 viewWorldPos = mainCamera.ScreenToWorldPoint(new Vector3(pannScreenPos.x, pannScreenPos.y, mainCamera.WorldToScreenPoint(view.transform.position).z));

        // ����view����λ��
        view.transform.position = viewWorldPos;
    }
    public void Follow()
    {
        view.transform.position = pann.transform.position;
        brain.transform.position = pann.transform.position;
    }

    private void OnButtonPressed(VirtualButtonBehaviour vb)
    {
        //ͨ��VirtualButtonBehaviour�µ�VirtualButtonName���Լ������ᵽ��Name���Ի�ȡ��Ӧ�����ⰴť


        if (vb.VirtualButtonName == "s1" )
        {
            if(flag == 1)
                flag = 0;
            else
                flag = 1;
        }
    }

    public void locate()
    {
        if (flag == 1)
            flag = 0;
        else
            flag = 1;
    }
    public void changedata()
    {
        if (flag!=3)
        {
            if (flag2 == 1)
                flag2 = 0;
            else
                flag2 = 1;
        }
       
    }
}
