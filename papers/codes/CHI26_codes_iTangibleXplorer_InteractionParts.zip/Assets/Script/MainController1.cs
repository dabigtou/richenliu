using Vuforia;
using UnityEngine;
using UnityEngine.UI;
using VolumeViewer;
public class MainController1 : MonoBehaviour
{
    public GameObject panel, fc, zoommer, tf,p1,p2,lesion,data,plane,plane2,get,hand,line,line2,line3,brain,volume,Rotate,button,ct,cam,tf2;
    public RaycastHit hit;
    public int flag=0;
    VirtualButtonBehaviour[] vbs;
    public GameObject S1, S2, S3,Histogram;
    public Slider s1;
    public Scrollbar s2,s3;
    //public Text t;
    private void Start()
    {

        vbs = GetComponentsInChildren<VirtualButtonBehaviour>();
        for (int i = 0; i < vbs.Length; i++)
        {
            vbs[i].RegisterOnButtonPressed(OnButtonPressed);
            vbs[i].RegisterOnButtonReleased(OnButtonReleased);
        }
        //Debug.Log(vbs.Length);
        fc.SetActive(false);
        zoommer.SetActive(false);
        tf.SetActive(false); tf2.SetActive(false);
        // sbrain.SetActive(false);
        // mbrain.SetActive(false);
        // splane.SetActive(false);
        plane.SetActive(false);
        lesion.SetActive(false);
        data.SetActive(false);
        hand.SetActive(false);
        line.SetActive(false);
        line2.SetActive(false);
        line3.SetActive(false);
        button.SetActive(false);
        ct.SetActive(false);
        cam.GetComponent<VolumeRenderer>().enabled = false;
        Histogram.SetActive(false);
        Debug.Log(vbs.Length);
    }
    public void Menu()
    {
        flag = 0;
        panel.SetActive(true);
        p1.SetActive(true);
        p2.SetActive(false);
        fc.SetActive(false);
        tf.SetActive(false); tf2.SetActive(false);
        ct.SetActive(false);
        cam.GetComponent<VolumeRenderer>().enabled = false;
        //  sbrain.SetActive(false);
        // mbrain.SetActive(false);
        //   splane.SetActive(false);
        //mplane.SetActive(false);
        lesion.SetActive(false);
        data.SetActive(false);
        zoommer.SetActive(false);
        plane.SetActive(false);
        get.SetActive(false);
        //ok.SetActive(false);
        line.SetActive(false);
        line2.SetActive(false);
        line3.SetActive(false);
        Histogram.SetActive(false);
        button.SetActive(false);
        plane2.SetActive(false);
    }

    private void Update()
    {
        //t.text = flag.ToString();
    }
    //��ť������ʱ
    private void OnButtonPressed(VirtualButtonBehaviour vb)
    {
        //ͨ��VirtualButtonBehaviour�µ�VirtualButtonName���Լ������ᵽ��Name���Ի�ȡ��Ӧ�����ⰴť
            
      
        if (vb.VirtualButtonName == "panel"&&flag!=0)//��ʾ�˵�
        {
            flag=0;
            panel.SetActive(true);
            p1.SetActive(true);
            p2.SetActive(false);
            fc.SetActive(false);
            tf.SetActive(false); tf2.SetActive(false);
            //  sbrain.SetActive(false);
            // mbrain.SetActive(false);
            //   splane.SetActive(false);
            //mplane.SetActive(false);
            lesion.SetActive(false);
            data.SetActive(false);
            zoommer.SetActive(false);
            plane.SetActive(false);
            get.SetActive(false);
            //ok.SetActive(false);
            line.SetActive(false);
            line2.SetActive(false);
            line3.SetActive(false);
            ct.SetActive(false);
            cam.GetComponent<VolumeRenderer>().enabled = false;
            Histogram.SetActive(false);
        }
        else
        {
            if (vb.VirtualButtonName == "3" && (flag == 0 || flag == 2))//������ά��Ƭ����
            {
                if(flag==2)
                {
                    flag = 8;
                    panel.SetActive(false);
                    //plane.transform.localPosition = new Vector3(-34f, 0, 52);
                    //  plane.transform.localPosition = new Vector3(-0.289999992f, 6.03999996f, 55.5f);//����
                    plane.transform.localPosition = new Vector3(-8.72000027f, 3.8900001f, 0);//ê��

                   // plane.SetActive(true);
                    //get.SetActive(true);
                    brain.SetActive(true);
                    volume.SetActive(false);
                    button.SetActive(true);
                    line3.SetActive(true);
                    line.SetActive(true);
                    line2.SetActive(true);
                    ct.SetActive(true);
                    cam.GetComponent<VolumeRenderer>().enabled = true;
                    //mbrain.SetActive(true);
                    //mplane.SetActive(true);
                }
                else//�����Ŵ�
                {
                    flag = 3;
                    panel.SetActive(false);
                    fc.SetActive(true);
                    zoommer.SetActive(true);
                    hand.SetActive(true);
                    brain.SetActive(false);
                    line.SetActive(true);
                    line2.SetActive(true);
                    volume.SetActive(true);
                    button.SetActive(false);
                  //  get.SetActive(false);
                }
                
            }
            else//ȷ�����в��Ĵ�ʱ��ʾ�����ݲ���ʾ
            {
                if (flag != 3)
                {
                    zoommer.SetActive(false);
                    hand.SetActive(false);
                }
                   
                if(flag!=9&&flag!=8&&flag!=7 && flag != 3)
                {
                   // get.SetActive(false);
                    //mbrain.SetActive(false);
                   plane.SetActive(false);
                    line.SetActive(false);
                    line2.SetActive(false);
                    line3.SetActive(false);
                    ct.SetActive(false);
                    cam.GetComponent<VolumeRenderer>().enabled = false;
                }
               
            }
            if (vb.VirtualButtonName == "1"&&(flag==0||flag==2))
            {
                if(flag==2)//������Ƭѡ�����
                {
                    flag=7;
                    get.SetActive(true);
                    //ok.SetActive(true);
                    panel.SetActive(false);
                    plane.SetActive(true);
                    line.SetActive(true);
                    line2.SetActive(true);
                    brain.SetActive(true);
                    volume.SetActive(false);
                    Rotate.SetActive(true);
                   // ct.SetActive(true);
                    button.SetActive(false);
                }
                else//������������
                {
                    flag = 1;
                    get.SetActive(false);
                    //ok.SetActive(false);
                    Rotate.SetActive(false);
                    panel.SetActive(false);
                    fc.SetActive(true);
                    brain.SetActive(false);
                    volume.SetActive(true);
                }
                
            }
            else //ȷ�����в��Ĵ�ʱ��ʾ�����ݲ���ʾ
            {
                if (flag != 3&&flag!=1)
                    fc.SetActive(false);
                if(flag!=7&&flag!=8&& flag != 3&&flag!=9)
                {
                    //sbrain.SetActive(false);
                    //splane.SetActive(false);
                    get.SetActive(false);
                    //ok.SetActive(false);
                    line.SetActive(false);
                    line2.SetActive(false);
                    line3.SetActive(false);
                    plane.SetActive(false);
                    //ct.SetActive(false);
                }
              
            }
            if (vb.VirtualButtonName == "4"&&flag==0)//�������ݺ������
            {
                flag = 4;
                panel.SetActive(false);
                tf.SetActive(true); tf2.SetActive(true);
            }
            else if(flag==0)
            {
                tf.SetActive(false); tf2.SetActive(false);
            }

            if (vb.VirtualButtonName == "2"&&flag == 0)//����CT���
            {
                p1.SetActive(false);
                p2.SetActive(true);
                flag = 2;
                
            }
          
            
            if (vb.VirtualButtonName == "5" && flag == 0)//����ֵͼ��
            {
                flag = 5;
                panel.SetActive(false);
                lesion.SetActive(true);
            }
            else
            {
                if(flag != 5)
                    lesion.SetActive(false);
            }
            if (vb.VirtualButtonName == "6" && flag == 0)//��ֱ��ͼ
            {
                flag = 6;
                panel.SetActive(false);
                data.SetActive(true);
                Histogram.SetActive(true);
            }
            else
            {
                if(flag!=6)
                {
                    data.SetActive(false);
                    Histogram.SetActive(false);
                }
                    
            }
            //����Ϊ���ݺ������Ĳ���
            if (vb.VirtualButtonName == "Preview" && (flag == 4 || flag == 41))
            {
                if (flag == 4)
                {
                    flag = 41;
                    S2.SetActive(false);
                    S3.SetActive(false);
                }
                else
                {
                    flag = 4;
                    S2.SetActive(true);
                    S3.SetActive(true);
                }
            }
            if (vb.VirtualButtonName == "C" && (flag == 4 || flag == 42))
            {
                if (flag == 4)
                {
                    flag = 42;
                    S1.SetActive(false);
                    S3.SetActive(false);
                }
               else
                {
                    flag = 4;
                    S1.SetActive(true);
                    S3.SetActive(true);
                }
            }
            if (vb.VirtualButtonName == "O" && (flag == 4 || flag == 43))
            {
                if (flag == 4)
                {
                    flag = 43;
                    S2.SetActive(false);
                    S1.SetActive(false);
                }
                else
                {
                    flag = 4;
                    S2.SetActive(true);
                    S1.SetActive(true);
                }
            }
            if ( flag == 41)
            {
                if (vb.VirtualButtonName == "p1")
                    s1.value = -3;
                if (vb.VirtualButtonName == "p2")
                    s1.value = -1;
                if (vb.VirtualButtonName == "p3")
                    s1.value = 1;
                if (vb.VirtualButtonName == "p4")
                    s1.value = 3.7f;
            }
            if (flag == 42)
            {
                if (vb.VirtualButtonName == "o0")
                    s2.value = 1;
                if (vb.VirtualButtonName == "c1")
                    s2.value = 0.86f;
                if (vb.VirtualButtonName == "c2")
                    s2.value = 0.72f;
                if (vb.VirtualButtonName == "c3")
                    s2.value = 0.58f;
                if (vb.VirtualButtonName == "c4")
                    s2.value = 0.44f;
                if (vb.VirtualButtonName == "c5")
                    s2.value = 0.3f;
                if (vb.VirtualButtonName == "c6")
                    s2.value = 0.16f;
                if (vb.VirtualButtonName == "c7")
                    s2.value = 0;
            }
            if (flag == 43)
            {
                if (vb.VirtualButtonName == "o0")
                    s3.value = 1;
                if (vb.VirtualButtonName == "o1")
                    s3.value = 0.86f;
                if (vb.VirtualButtonName == "o2")
                    s3.value = 0.72f;
                if (vb.VirtualButtonName == "o3")
                    s3.value = 0.58f;
                if (vb.VirtualButtonName == "o4")
                    s3.value = 0.44f;
                if (vb.VirtualButtonName == "o5")
                    s3.value = 0.3f;
                if (vb.VirtualButtonName == "o6")
                    s3.value = 0.16f;
                if (vb.VirtualButtonName == "o7")
                    s3.value = 0;
            }
        }

     //   Debug.Log(vb.VirtualButtonName);
    }
    //��ť�ͷ�ʱ
    private void OnButtonReleased(VirtualButtonBehaviour vb)
    {
       
    }

   
     public void CutSlices()
    {
        flag = 8;
        clear();
        panel.SetActive(false);
        //plane.transform.localPosition = new Vector3(-34f, 0, 52);
        //  plane.transform.localPosition = new Vector3(-0.289999992f, 6.03999996f, 55.5f);//����
        plane.transform.localPosition = new Vector3(-8.72000027f, 3.8900001f, 0);//ê��
        data.SetActive(false);
        Histogram.SetActive(false);
        // plane.SetActive(true);
        //get.SetActive(true);
        brain.SetActive(true);
        volume.SetActive(false);
        button.SetActive(true);
        line3.SetActive(true);
        line.SetActive(true);
        line2.SetActive(true);
        ct.SetActive(true);
        cam.GetComponent<VolumeRenderer>().enabled = true;
        //mbrain.SetActive(true);
        //mplane.SetActive(true);
        if (flag != 3)
        {
            zoommer.SetActive(false);
            hand.SetActive(false);
        }

        if (flag!=9&&flag != 8 && flag != 7 && flag != 3)
        {
            // get.SetActive(false);
            //mbrain.SetActive(false);
            clear();
            plane.SetActive(false);
            line.SetActive(false);
            line2.SetActive(false);
            line3.SetActive(false);
            ct.SetActive(false);
            cam.GetComponent<VolumeRenderer>().enabled = false;
        }
    }
    public void Navigation()
    {
        flag = 1;
        clear();
        get.SetActive(false);
        //ok.SetActive(false);
        Rotate.SetActive(false);
        panel.SetActive(false);
        fc.SetActive(true);
        brain.SetActive(false);
        volume.SetActive(true);
        data.SetActive(false);
        Histogram.SetActive(false);
    }
    public void Fc()
    {
        flag = 3;
        clear();
        panel.SetActive(false);
        fc.SetActive(true);
        zoommer.SetActive(true);
        hand.SetActive(true);
        brain.SetActive(false);
        line.SetActive(true);
        line2.SetActive(true);
        volume.SetActive(true);
        button.SetActive(false);
        data.SetActive(false);
        Histogram.SetActive(false);
        //  get.SetActive(false);
        if (flag != 3)
        {
            zoommer.SetActive(false);
            hand.SetActive(false);
        }

        if (flag!=9&&flag != 8 && flag != 7 && flag != 3)
        {
            // get.SetActive(false);
            //mbrain.SetActive(false);
            clear();
            plane.SetActive(false);
            line.SetActive(false);
            line2.SetActive(false);
            line3.SetActive(false);
            ct.SetActive(false);
            cam.GetComponent<VolumeRenderer>().enabled = false;
        }
    }

    public void Tf()
    {
        flag = 4;
        clear();
        panel.SetActive(false);
        tf.SetActive(true); tf2.SetActive(true);
        data.SetActive(false);
        Histogram.SetActive(false);
    }

    public void Lesion()
    {
        flag = 5;
        clear();
        panel.SetActive(false);
        lesion.SetActive(true);
        data.SetActive(false);
        Histogram.SetActive(false);
    }
    public void histogram()
    {
        flag = 6;
        clear();
        panel.SetActive(false);
        data.SetActive(true);
        Histogram.SetActive(true);
    }

    public void SelectSlice()
    {
        flag = 7;
        clear();
        get.SetActive(true);
        //ok.SetActive(true);
        panel.SetActive(false);
        plane.SetActive(true);
        line.SetActive(true);
        line2.SetActive(true);
        brain.SetActive(true);
        volume.SetActive(false);
        Rotate.SetActive(true);
        // ct.SetActive(true);
        button.SetActive(false);
    }

    public void clear()
    {
        p1.SetActive(true);
        p2.SetActive(false);
        fc.SetActive(false);
        tf.SetActive(false); tf2.SetActive(false);
        ct.SetActive(false);
        cam.GetComponent<VolumeRenderer>().enabled = false;
        //  sbrain.SetActive(false);
        // mbrain.SetActive(false);
        //   splane.SetActive(false);
        //mplane.SetActive(false);
        lesion.SetActive(false);
        data.SetActive(false);
        zoommer.SetActive(false);
        plane.SetActive(false);
        get.SetActive(false);
        //ok.SetActive(false);
        line.SetActive(false);
        line2.SetActive(false);
        line3.SetActive(false);
        Histogram.SetActive(false);
        button.SetActive(false);
        plane2.SetActive(false);
    }

    public void TF2()
    {
        flag = 9;
        clear();
        panel.SetActive(false);
        //plane.transform.localPosition = new Vector3(-34f, 0, 52);
        //  plane.transform.localPosition = new Vector3(-0.289999992f, 6.03999996f, 55.5f);//����
        plane.transform.localPosition = new Vector3(-8.72000027f, 3.8900001f, 0);//ê��
        data.SetActive(false);
        Histogram.SetActive(false);
        // plane.SetActive(true);
        //get.SetActive(true);
        brain.SetActive(true);
        volume.SetActive(false);
        button.SetActive(true);
        line3.SetActive(true);
        line.SetActive(true);
        line2.SetActive(true);
        ct.SetActive(true);
        cam.GetComponent<VolumeRenderer>().enabled = true;
        //mbrain.SetActive(true);
        //mplane.SetActive(true);
        if (flag != 3)
        {
            zoommer.SetActive(false);
            hand.SetActive(false);
        }

        if (flag != 9 && flag != 8 && flag != 7 && flag != 3)
        {
            // get.SetActive(false);
            //mbrain.SetActive(false);
            clear();
            plane.SetActive(false);
            line.SetActive(false);
            line2.SetActive(false);
            line3.SetActive(false);
            ct.SetActive(false);
            cam.GetComponent<VolumeRenderer>().enabled = false;
        }
    }

}
    
    


