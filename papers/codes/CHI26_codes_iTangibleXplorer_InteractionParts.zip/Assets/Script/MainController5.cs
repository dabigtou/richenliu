using Vuforia;
using UnityEngine;
using UnityEngine.UI;
using Image = UnityEngine.UI.Image;

public class MainController5 : MonoBehaviour
{
   // public GameObject p1;
    public GameObject cut,cut2,cut3;
    public RenderTexture renderTexture;
    public GameObject img1,img2,img3,img4,img5,img6;
    public GameObject line,line2,line3;
    public GameObject volume,A,zoomer;
    public GameObject xx, yy, zz;
    VirtualButtonBehaviour[] vbs;
    public float x, y, z;
    public int f=0;
    int flag;
    int cnt = 0;
    //public Text t;
    private void Start()
    {
        
        vbs = GetComponentsInChildren<VirtualButtonBehaviour>();
        for (int i = 0; i < vbs.Length; i++)
        {
            vbs[i].RegisterOnButtonPressed(OnButtonPressed);
            vbs[i].RegisterOnButtonReleased(OnButtonReleased);
        }
        if(f==0)
        {
            x = line.transform.localPosition.x  * 170 + Random.Range(-1.0f, 1.0f)+5f;
            xx.GetComponent<Text>().text = "x:" + x.ToString("F2") + "mm";
            y = line2.transform.localPosition.z  * 170 + Random.Range(-1.0f, 1.0f)-7;
            yy.GetComponent<Text>().text = "y:" + y.ToString("F2") + "mm";
            z = line3.transform.localPosition.z * 180+5 + Random.Range(-1.0f, 1.0f);
            zz.GetComponent<Text>().text = "z:" + z.ToString("F2") + "mm";
        }
        else
        {
            x = line.transform.localPosition.x *350 + Random.Range(-1.0f, 1.0f)+10;
            xx.GetComponent<Text>().text = "x:" + x.ToString("F2") + "mm";
            y = line2.transform.localPosition.z *350 + Random.Range(-1.0f, 1.0f)-10;
            yy.GetComponent<Text>().text = "y:" + y.ToString("F2") + "mm";
            z = line3.transform.localPosition.z *350 + Random.Range(-1.0f, 1.0f)+10;
            zz.GetComponent<Text>().text = "z:" + z.ToString("F2") + "mm";
        }
        Debug.Log(vbs.Length);
    }
    void ChangePosition1(float tmp)
    {
        float step = 0.01f;
     //   cut.transform.localPosition = Vector3.MoveTowards(cut.transform.localPosition, new Vector3(0, 0, tmp), step);
      
    }
  
    private void Update()
    {
        flag =A.GetComponent<MainController1>().flag;
        
        if(flag==8)
        {
            
            cut.transform.localPosition = new Vector3(line.transform.localPosition.x, 0,0 );
            cut2.transform.localPosition = new Vector3(0, line2.transform.localPosition.z, 0);
            cut3.transform.localPosition = new Vector3(0, 0, line3.transform.localPosition.z);
            cut.SetActive(true);
            cut2.SetActive(true);
            cut3.SetActive(true);
            xx.SetActive(true);
            yy.SetActive(true);
            zz.SetActive(true);
        }
        if(flag!=8)
        {
            cut.SetActive(false);
            cut2.SetActive(false);
            cut3.SetActive(false);
            xx.SetActive(false);
            yy.SetActive(false);
            zz.SetActive(false);
        }

        if (flag==3)//�ԷŴ󾵽���y���ϵĿ���
            zoomer.transform.localPosition = new Vector3(line.transform.localPosition.x * 1.82f -1.4f, line2.transform.localPosition.z * 1.61f , -2.2f);

        


    }
    //��ť������ʱ
    private void OnButtonPressed(VirtualButtonBehaviour vb)
    {
        //ͨ��VirtualButtonBehaviour�µ�VirtualButtonName���Լ������ᵽ��Name���Ի�ȡ��Ӧ�����ⰴť

        Debug.Log(line3.transform.position);
        Debug.Log(vb.VirtualButtonName);
            if (flag==8||flag==3||flag==9)
        {
           
            if (vb.VirtualButtonName == "s1")
            {
                if (flag == 9)
                {
                    if(f==0)
                        volume.GetComponent<VolumeViewer.VolumeComponent>().surfaceThr = 0.15f;
                    else
                        volume.GetComponent<VolumeViewer.VolumeComponent>().surfaceThr = 0.55f;
                }
                line.transform.localPosition = new Vector3(vb.transform.localPosition.x, line.transform.localPosition.y, line.transform.localPosition.z);
                if (f == 0)
                    x = line.transform.localPosition.x * 170 + Random.Range(-1.0f, 1.0f) + 5f;
                else
                    x = line.transform.localPosition.x *350 + Random.Range(-1.0f, 1.0f)+10;
                xx.GetComponent<Text>().text = "x:" + x.ToString("F2") + "mm";
            }


            if (vb.VirtualButtonName == "s2")
            {

                if (flag == 9)
                {
                    if (f == 0)
                        volume.GetComponent<VolumeViewer.VolumeComponent>().surfaceThr = 0.3f;
                    else
                        volume.GetComponent<VolumeViewer.VolumeComponent>().surfaceThr = 0.6f;
                }
                line.transform.localPosition = new Vector3(vb.transform.localPosition.x, line.transform.localPosition.y, line.transform.localPosition.z);
                if(f==0)
                    x = line.transform.localPosition.x  * 170 + Random.Range(-1.0f, 1.0f)+5f;
                else
                    x = line.transform.localPosition.x *350 + Random.Range(-1.0f, 1.0f)+10;
                xx.GetComponent<Text>().text = "x:" + x.ToString("F2") + "mm";
            }

            if (vb.VirtualButtonName == "s3")
            {
   
                line.transform.localPosition = new Vector3(vb.transform.localPosition.x, line.transform.localPosition.y, line.transform.localPosition.z);
                if (flag == 9)
                {
                    if (f == 0)
                        volume.GetComponent<VolumeViewer.VolumeComponent>().surfaceThr = 0.45f;
                    else
                        volume.GetComponent<VolumeViewer.VolumeComponent>().surfaceThr = 0.65f;
                }
                if (f == 0)
                    x = line.transform.localPosition.x  * 170 + Random.Range(-1.0f, 1.0f)+5f;
                else
                    x = line.transform.localPosition.x *350 + Random.Range(-1.0f, 1.0f)+10;
                xx.GetComponent<Text>().text = "x:" + x.ToString("F2") + "mm";
            }

            if (vb.VirtualButtonName == "s4")
            {
             
                line.transform.localPosition = new Vector3(vb.transform.localPosition.x, line.transform.localPosition.y, line.transform.localPosition.z);
                if (flag == 9)
                {
                    if (f == 0)
                        volume.GetComponent<VolumeViewer.VolumeComponent>().surfaceThr = 0.55f;
                    else
                        volume.GetComponent<VolumeViewer.VolumeComponent>().surfaceThr = 0.69f;
                }
                if (f == 0)
                    x = line.transform.localPosition.x  * 170 + Random.Range(-1.0f, 1.0f)+5f;
                else
                    x = line.transform.localPosition.x *350 + Random.Range(-1.0f, 1.0f)+10;
                xx.GetComponent<Text>().text = "x:" + x.ToString("F2") + "mm";
            }

            if (vb.VirtualButtonName == "s5")
            {
        
                line.transform.localPosition = new Vector3(vb.transform.localPosition.x, line.transform.localPosition.y, line.transform.localPosition.z);
                if (flag == 9)
                {
                    if (f == 0)
                        volume.GetComponent<VolumeViewer.VolumeComponent>().surfaceThr = 0.65f;
                    else
                        volume.GetComponent<VolumeViewer.VolumeComponent>().surfaceThr = 0.72f;
                }
                if (f == 0)
                    x = line.transform.localPosition.x  * 170 + Random.Range(-1.0f, 1.0f)+5f;
                else
                    x = line.transform.localPosition.x *350 + Random.Range(-1.0f, 1.0f)+10;
                xx.GetComponent<Text>().text = "x:" + x.ToString("F2") + "mm";
            }

            if (vb.VirtualButtonName == "s6")
            {
               
                line.transform.localPosition = new Vector3(vb.transform.localPosition.x, line.transform.localPosition.y, line.transform.localPosition.z);
                if (flag == 9)
                {
                    volume.GetComponent<VolumeViewer.VolumeComponent>().surfaceThr = 0.75f;
                }
                if (f == 0)
                    x = line.transform.localPosition.x  * 170 + Random.Range(-1.0f, 1.0f)+5f;
                else
                    x = line.transform.localPosition.x *350 + Random.Range(-1.0f, 1.0f)+10;
                xx.GetComponent<Text>().text = "x:" + x.ToString("F2") + "mm";

            }
            if (vb.VirtualButtonName == "ss1")
            {
                if (flag == 9)
                {
                    if (f == 0)
                        volume.GetComponent<VolumeViewer.VolumeComponent>().surfaceAlpha = 0.25f;
                    else
                        volume.GetComponent<VolumeViewer.VolumeComponent>().surfaceAlpha = 0;
                }
                //volume.transform.rotation = new Quaternion(0, 0.707106829f, -0.707106829f, 0);
                line2.transform.localPosition = new Vector3(line2.transform.localPosition.x, line2.transform.localPosition.y, vb.transform.localPosition.z);
                if(f==0)
                    y = line2.transform.localPosition.z  * 170 + Random.Range(-1.0f, 1.0f)-7;
                else
                    y = line2.transform.localPosition.z *350 + Random.Range(-1.0f, 1.0f)-10;
                yy.GetComponent<Text>().text = "y:" + y.ToString("F2") + "mm";
            }
            if (vb.VirtualButtonName == "ss2")
            {
                if (flag == 9)
                {
                    if (f == 0)
                        volume.GetComponent<VolumeViewer.VolumeComponent>().surfaceAlpha = 0.25f;
                    else
                        volume.GetComponent<VolumeViewer.VolumeComponent>().surfaceAlpha = 0.03f;
                }
                // volume.transform.rotation = new Quaternion(0, 0.707106829f, -0.707106829f, 0);
                line2.transform.localPosition = new Vector3(line2.transform.localPosition.x, line2.transform.localPosition.y, vb.transform.localPosition.z);
                if (f == 0)
                    y = line2.transform.localPosition.z  * 170 + Random.Range(-1.0f, 1.0f)-7;
                else
                    y = line2.transform.localPosition.z *350 + Random.Range(-1.0f, 1.0f)-10;
                yy.GetComponent<Text>().text = "y:" + y.ToString("F2") + "mm";
            }
            if (vb.VirtualButtonName == "ss3")
            {
                if (flag == 9)
                {
                    if (f == 0)
                        volume.GetComponent<VolumeViewer.VolumeComponent>().surfaceAlpha = 0.45f;
                    else
                        volume.GetComponent<VolumeViewer.VolumeComponent>().surfaceAlpha = 0.06f;
                }
                //  volume.transform.rotation = new Quaternion(0, 0.707106829f, -0.707106829f, 0);
                line2.transform.localPosition = new Vector3(line2.transform.localPosition.x, line2.transform.localPosition.y, vb.transform.localPosition.z);
                if (f == 0)
                    y = line2.transform.localPosition.z  * 170 + Random.Range(-1.0f, 1.0f)-7;
                else
                    y = line2.transform.localPosition.z *350 + Random.Range(-1.0f, 1.0f)-10;
                yy.GetComponent<Text>().text = "y:" + y.ToString("F2") + "mm";
            }
            if (vb.VirtualButtonName == "ss4")
            {
                if (flag == 9)
                {
                    if (f == 0)
                        volume.GetComponent<VolumeViewer.VolumeComponent>().surfaceAlpha = 0.55f;
                    else
                        volume.GetComponent<VolumeViewer.VolumeComponent>().surfaceAlpha = 0.09f;
                }
                // volume.transform.rotation = new Quaternion(0, 0.707106829f, -0.707106829f, 0);
                line2.transform.localPosition = new Vector3(line2.transform.localPosition.x, line2.transform.localPosition.y, vb.transform.localPosition.z);
                if (f == 0)
                    y = line2.transform.localPosition.z  * 170 + Random.Range(-1.0f, 1.0f)-7;
                else
                    y = line2.transform.localPosition.z *350 + Random.Range(-1.0f, 1.0f)-10;
                yy.GetComponent<Text>().text = "y:" + y.ToString("F2") + "mm";
            }
            if (vb.VirtualButtonName == "ss5")
            {
                if (flag == 9)
                {
                    if (f == 0)
                        volume.GetComponent<VolumeViewer.VolumeComponent>().surfaceAlpha = 0.65f;
                    else
                        volume.GetComponent<VolumeViewer.VolumeComponent>().surfaceAlpha = 0.12f;
                }
                // volume.transform.rotation = new Quaternion(0, 0.707106829f, -0.707106829f, 0);
                line2.transform.localPosition = new Vector3(line2.transform.localPosition.x, line2.transform.localPosition.y, vb.transform.localPosition.z);
                if (f == 0)
                    y = line2.transform.localPosition.z  * 170 + Random.Range(-1.0f, 1.0f)-7;
                else
                    y = line2.transform.localPosition.z *350 + Random.Range(-1.0f, 1.0f)-10;
                yy.GetComponent<Text>().text = "y:" + y.ToString("F2") + "mm";
            }
            if (vb.VirtualButtonName == "ss6")
            {
                if (flag == 9)
                {
                    if (f == 0)
                        volume.GetComponent<VolumeViewer.VolumeComponent>().surfaceAlpha = 0.75f;
                    else
                        volume.GetComponent<VolumeViewer.VolumeComponent>().surfaceAlpha = 0.15f;
                }
                // volume.transform.rotation = new Quaternion(0, 0.707106829f, -0.707106829f, 0);
                line2.transform.localPosition = new Vector3(line2.transform.localPosition.x, line2.transform.localPosition.y, vb.transform.localPosition.z);
                if (f == 0)
                    y = line2.transform.localPosition.z  * 170 + Random.Range(-1.0f, 1.0f)-7;
                else
                    y = line2.transform.localPosition.z *350 + Random.Range(-1.0f, 1.0f)-10;
                yy.GetComponent<Text>().text = "y:" + y.ToString("F2") + "mm";
            }
            if (vb.VirtualButtonName == "a1")
            {
               
                // volume.transform.rotation = new Quaternion(0, 0.707106829f, 0, 0.707106829f);
                line3.transform.localPosition = new Vector3(line3.transform.localPosition.x, line3.transform.localPosition.y, vb.transform.localPosition.z);
                if (f == 0)
                    z = line3.transform.localPosition.z * 180+5 + Random.Range(-1.0f, 1.0f);
                else
                    z = line3.transform.localPosition.z *350 + Random.Range(-1.0f, 1.0f)+10;
                zz.GetComponent<Text>().text = "z:" + z.ToString("F2") + "mm";
            }
            if (vb.VirtualButtonName == "a2")
            {
                
                //volume.transform.rotation = new Quaternion(0, 0.707106829f, 0, 0.707106829f);
                line3.transform.localPosition = new Vector3(line3.transform.localPosition.x, line3.transform.localPosition.y, vb.transform.localPosition.z);
                if (f == 0)
                    z = line3.transform.localPosition.z * 180+5 + Random.Range(-1.0f, 1.0f);
                else
                    z = line3.transform.localPosition.z *350 + Random.Range(-1.0f, 1.0f)+10;
                zz.GetComponent<Text>().text = "z:" + z.ToString("F2") + "mm";
            }
            if (vb.VirtualButtonName == "a3")
            {
                
                //volume.transform.rotation = new Quaternion(0, 0.707106829f, 0, 0.707106829f);
                line3.transform.localPosition = new Vector3(line3.transform.localPosition.x, line3.transform.localPosition.y, vb.transform.localPosition.z);
                if (f == 0)
                    z = line3.transform.localPosition.z * 180+5 + Random.Range(-1.0f, 1.0f);
                else
                    z = line3.transform.localPosition.z *350 + Random.Range(-1.0f, 1.0f)+10;
                zz.GetComponent<Text>().text = "z:" + z.ToString("F2") + "mm";
            }
            if (vb.VirtualButtonName == "a4")
            {
               
                //volume.transform.rotation = new Quaternion(0, 0.707106829f, 0, 0.707106829f);
                line3.transform.localPosition = new Vector3(line3.transform.localPosition.x, line3.transform.localPosition.y, vb.transform.localPosition.z);
                if (f == 0)
                    z = line3.transform.localPosition.z * 180+5 + Random.Range(-1.0f, 1.0f);
                else
                    z = line3.transform.localPosition.z *350 + Random.Range(-1.0f, 1.0f)+10;
                zz.GetComponent<Text>().text = "z:" + z.ToString("F2") + "mm";
            }
            if (vb.VirtualButtonName == "a5")
            {
                
                line3.transform.localPosition = new Vector3(line3.transform.localPosition.x, line3.transform.localPosition.y, vb.transform.localPosition.z);
                if (f == 0)
                    z = line3.transform.localPosition.z * 180+5 + Random.Range(-1.0f, 1.0f);
                else
                    z = line3.transform.localPosition.z *350 + Random.Range(-1.0f, 1.0f)+10;
                zz.GetComponent<Text>().text = "z:" + z.ToString("F2") + "mm";
                // volume.transform.rotation = new Quaternion(0, 0.707106829f, 0, 0.707106829f);
            }
            if (vb.VirtualButtonName == "a6")
            {
                
                line3.transform.localPosition = new Vector3(line3.transform.localPosition.x, line3.transform.localPosition.y,vb.transform.localPosition.z);
                if (f == 0)
                    z = line3.transform.localPosition.z * 180+5 + Random.Range(-1.0f, 1.0f);
                else
                    z = line3.transform.localPosition.z *350 + Random.Range(-1.0f, 1.0f)+10;
                zz.GetComponent<Text>().text = "z:" + z.ToString("F2") + "mm";
                // volume.transform.rotation = new Quaternion(0, 0.707106829f, 0, 0.707106829f);
            }
        }

       
    }
    //��ť�ͷ�ʱ
    private void OnButtonReleased(VirtualButtonBehaviour vb)
    {


    }
}
    
    


