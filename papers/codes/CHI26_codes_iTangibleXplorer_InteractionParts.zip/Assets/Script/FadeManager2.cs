using UnityEngine.UI;
using UnityEngine;

public class FadeManager2 : MonoBehaviour
{
    public Slider slider;
    public GameObject mObj1, mObj2, mObj3, mObj4;

    void Start()
    {

    }
    private void Update()
    {

        float x = slider.value;
        if (x < -4)
        {
            mObj1.SetActive(false);
            mObj2.SetActive(false);
            mObj3.SetActive(false);
            mObj4.SetActive(false);
        }

        if (x > -4 && x < -2)
        {
            mObj1.SetActive(true);
            mObj2.SetActive(false);
            mObj3.SetActive(false);
            mObj4.SetActive(false);
        }
        if (x > -2 && x < 0)
        {
            mObj1.SetActive(false);
            mObj2.SetActive(true);
            mObj3.SetActive(false);
            mObj4.SetActive(false);

        }

        if (x > 0 && x < 2)
        {
            mObj1.SetActive(false);
            mObj2.SetActive(false);
            mObj3.SetActive(true);
            mObj4.SetActive(false);

        }
        if (x > 2 && x < 4)
        {
            mObj1.SetActive(false);
            mObj2.SetActive(false);
            mObj3.SetActive(false);
            mObj4.SetActive(true);


        }


    }

}


