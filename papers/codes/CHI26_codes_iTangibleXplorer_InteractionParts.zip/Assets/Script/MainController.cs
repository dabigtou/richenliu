using Vuforia;
using UnityEngine;
using UnityEngine.UI;
public class MainController : MonoBehaviour
{
    public GameObject panel, fc, zoommer, tf,p1,p2,lesion,data,plane,get,hand,line,line2;
    public RaycastHit hit;
    public int flag=0;
    VirtualButtonBehaviour[] vbs;
    public GameObject S1, S2, S3;
    public Slider s1;
    public Scrollbar s2,s3;
    //public Text t;
    private void Start()
    {

        vbs = GetComponentsInChildren<VirtualButtonBehaviour>();
        for (int i = 0; i < vbs.Length; i++)
        {
            vbs[i].RegisterOnButtonPressed(OnButtonPressed);
            vbs[i].RegisterOnButtonReleased(OnButtonReleased);
        }
        //Debug.Log(vbs.Length);
        fc.SetActive(false);
        zoommer.SetActive(false);
        tf.SetActive(false);
       // sbrain.SetActive(false);
       // mbrain.SetActive(false);
       // splane.SetActive(false);
        plane.SetActive(false);
        lesion.SetActive(false);
        data.SetActive(false);
        hand.SetActive(false);
        line.SetActive(false);
        line2.SetActive(false);
        Debug.Log(vbs.Length);
    }

    private void Update()
    {
        //t.text = flag.ToString();
    }
    //��ť������ʱ
    private void OnButtonPressed(VirtualButtonBehaviour vb)
    {
        //ͨ��VirtualButtonBehaviour�µ�VirtualButtonName���Լ������ᵽ��Name���Ի�ȡ��Ӧ�����ⰴť
            
            
        if (vb.VirtualButtonName == "panel"&&flag!=0)
        {
            flag=0;
            panel.SetActive(true);
            p1.SetActive(true);
            p2.SetActive(false);
            fc.SetActive(false);
            tf.SetActive(false);
          //  sbrain.SetActive(false);
           // mbrain.SetActive(false);
         //   splane.SetActive(false);
            //mplane.SetActive(false);
            lesion.SetActive(false);
            data.SetActive(false);
            zoommer.SetActive(false);
            plane.SetActive(false);
            get.SetActive(false);
            line.SetActive(false);
            line2.SetActive(false);
        }
        else
        {
            if (vb.VirtualButtonName == "3" && (flag == 0 || flag == 2))
            {
                if(flag==2)
                {
                    flag = 8;
                    panel.SetActive(false);
                    plane.transform.localPosition = new Vector3(-34f, 0, 52);
                    plane.SetActive(true);
                    get.SetActive(true);
                  
                    //mbrain.SetActive(true);
                    //mplane.SetActive(true);
                }
                else
                {
                    flag = 3;
                    panel.SetActive(false);
                    fc.SetActive(true);
                    zoommer.SetActive(true);
                    hand.SetActive(true);
                }
                
            }
            else
            {
                if (flag != 3)
                {
                    zoommer.SetActive(false);
                    hand.SetActive(false);
                }
                   
                if(flag!=8&&flag!=7)
                {
                    get.SetActive(false);
                    //mbrain.SetActive(false);
                   plane.SetActive(false);
                }
               
            }
            if (vb.VirtualButtonName == "1"&&(flag==0||flag==2))
            {
                if(flag==2)
                {
                    flag=7;
                    panel.SetActive(false);
                    plane.SetActive(true);
                    line.SetActive(true);
                    line2.SetActive(true);
                }
                else
                {
                    flag = 1;
                    panel.SetActive(false);
                    fc.SetActive(true);
                }
                
            }
            else 
            {
                if (flag != 3&&flag!=1)
                    fc.SetActive(false);
                if(flag!=7&&flag!=8)
                {
                    //sbrain.SetActive(false);
                    //splane.SetActive(false);
                    plane.SetActive(false);
                }
              
            }
            if (vb.VirtualButtonName == "4"&&flag==0)
            {
                flag = 4;
                panel.SetActive(false);
                tf.SetActive(true);
            }
            else if(flag==0)
            {
                tf.SetActive(false);
            }

            if (vb.VirtualButtonName == "2"&&flag == 0)
            {
                p1.SetActive(false);
                p2.SetActive(true);
                flag = 2;
                
            }
          
            
            if (vb.VirtualButtonName == "5" && flag == 0)
            {
                flag = 5;
                panel.SetActive(false);
                lesion.SetActive(true);
            }
            else
            {
                if(flag != 5)
                    lesion.SetActive(false);
            }
            if (vb.VirtualButtonName == "6" && flag == 0)
            {
                flag = 6;
                panel.SetActive(false);
                data.SetActive(true);
            }
            else
            {
                if(flag!=6)
                    data.SetActive(false);
            }

            if (vb.VirtualButtonName == "Preview" && (flag == 4 || flag == 41))
            {
                if (flag == 4)
                {
                    flag = 41;
                    S2.SetActive(false);
                    S3.SetActive(false);
                }
                else
                {
                    flag = 4;
                    S2.SetActive(true);
                    S3.SetActive(true);
                }
            }
            if (vb.VirtualButtonName == "C" && (flag == 4 || flag == 42))
            {
                if (flag == 4)
                {
                    flag = 42;
                    S1.SetActive(false);
                    S3.SetActive(false);
                }
               else
                {
                    flag = 4;
                    S1.SetActive(true);
                    S3.SetActive(true);
                }
            }
            if (vb.VirtualButtonName == "O" && (flag == 4 || flag == 43))
            {
                if (flag == 4)
                {
                    flag = 43;
                    S2.SetActive(false);
                    S1.SetActive(false);
                }
                else
                {
                    flag = 4;
                    S2.SetActive(true);
                    S1.SetActive(true);
                }
            }
            if ( flag == 41)
            {
                if (vb.VirtualButtonName == "p1")
                    s1.value = -3;
                if (vb.VirtualButtonName == "p2")
                    s1.value = -1;
                if (vb.VirtualButtonName == "p3")
                    s1.value = 1;
                if (vb.VirtualButtonName == "p4")
                    s1.value = 3.7f;
            }
            if (flag == 42)
            {
                if (vb.VirtualButtonName == "o0")
                    s2.value = 1;
                if (vb.VirtualButtonName == "c1")
                    s2.value = 0.86f;
                if (vb.VirtualButtonName == "c2")
                    s2.value = 0.72f;
                if (vb.VirtualButtonName == "c3")
                    s2.value = 0.58f;
                if (vb.VirtualButtonName == "c4")
                    s2.value = 0.44f;
                if (vb.VirtualButtonName == "c5")
                    s2.value = 0.3f;
                if (vb.VirtualButtonName == "c6")
                    s2.value = 0.16f;
                if (vb.VirtualButtonName == "c7")
                    s2.value = 0;
            }
            if (flag == 43)
            {
                if (vb.VirtualButtonName == "o0")
                    s3.value = 1;
                if (vb.VirtualButtonName == "o1")
                    s3.value = 0.86f;
                if (vb.VirtualButtonName == "o2")
                    s3.value = 0.72f;
                if (vb.VirtualButtonName == "o3")
                    s3.value = 0.58f;
                if (vb.VirtualButtonName == "o4")
                    s3.value = 0.44f;
                if (vb.VirtualButtonName == "o5")
                    s3.value = 0.3f;
                if (vb.VirtualButtonName == "o6")
                    s3.value = 0.16f;
                if (vb.VirtualButtonName == "o7")
                    s3.value = 0;
            }
        }

     //   Debug.Log(vb.VirtualButtonName);
    }
    //��ť�ͷ�ʱ
    private void OnButtonReleased(VirtualButtonBehaviour vb)
    {
       
    }



}
    
    


