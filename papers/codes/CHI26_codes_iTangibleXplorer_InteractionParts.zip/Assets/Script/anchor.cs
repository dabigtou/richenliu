using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class anchor : MonoBehaviour
{
    bool flag = false;
   public GameObject anchorGameObject;
    // Start is called before the first frame update
    void Start()
    {
       
    }

    // Update is called once per frame
    void Update()
    {
        if (!flag)
        {
            this.transform.position = anchorGameObject.transform.position;
            this.transform.rotation = anchorGameObject.transform.rotation;
        }
    }

    public void changeanchor()
    {
        if(flag)
        {
            flag = false;
        }
        else
        {
            flag = true;
        }
    }

}


