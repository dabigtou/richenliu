using UnityEngine.UI;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class MO : MonoBehaviour
{
    public GameObject panel;
    public GameObject o1;
    public GameObject o2;
    public GameObject o3;
    public GameObject o4;
    public GameObject o5;
    public GameObject o6,o7,o8,p2;
    public Material m1;
    public Material m2;
    public Slider s1, s2,s3;
    public RaycastHit hit;
    public int flag = 0;
    Vector3 lastHandPos = Vector3.zero;


    private void Start()
    {

    }
    private void Update()
    {


        // GameObject.Find("Sphere").transform.position = ManoUtils.Instance.CalculateNewPositionSkeletonPosition(ManomotionManager.Instance.Hand_infos[0].hand_info.tracking_info.palm_center, 1);
        Quaternion q = Quaternion.identity;
        q.SetLookRotation(Camera.main.transform.forward, Camera.main.transform.up);
        panel.transform.rotation = q;






        if (s1.value >= 0 && s1.value < 1 && s2.value >= 0 && s2.value < 1)
        {
            o1.GetComponent<Renderer>().material = m2;
            o1.transform.localPosition = new Vector3(5.38000011f, 5.28000021f, 3);
            flag = 1;
        }
        else
        {
            o1.GetComponent<Renderer>().material = m1;
            o1.transform.localPosition = new Vector3(5.38000011f, 5.28000021f, 0);
        }

        if (s1.value >= 1 && s1.value < 2 && s2.value >= 0 && s2.value < 1)
        {
            o2.GetComponent<Renderer>().material = m2;
            o2.transform.localPosition = new Vector3(-0.180000007f, 5.23999929f, 3);
            flag = 2;
        }
        else
        {
            o2.GetComponent<Renderer>().material = m1;
            o2.transform.localPosition = new Vector3(-0.180000007f, 5.23999929f, 0);
        }
        if (s1.value >= 2 && s1.value < 3 && s2.value >= 0 && s2.value < 1)
        {
            o3.GetComponent<Renderer>().material = m2;
            o3.transform.localPosition = new Vector3(-5.88000011f, 5.21000051f, 3);
            flag = 3;
        }
        else
        {
            o3.GetComponent<Renderer>().material = m1;
            o3.transform.localPosition = new Vector3(-5.88000011f, 5.21000051f, 0);
        }
        if (s1.value >= 0 && s1.value < 1 && s2.value >= 1 && s2.value < 2)
        {
            o4.GetComponent<Renderer>().material = m2;
            o4.transform.localPosition = new Vector3(5.42000008f, -0.649999022f, 3);
            flag = 4;
        }
        else
        {
            o4.GetComponent<Renderer>().material = m1;
            o4.transform.localPosition = new Vector3(5.42000008f, -0.649999022f, 0); ;
        }
        if (s1.value >= 1 && s1.value < 2 && s2.value >= 1 && s2.value < 2)
        {
            o5.GetComponent<Renderer>().material = m2;
            o5.transform.localPosition = new Vector3(-0.270000011f, -0.689999878f, 3);
            flag = 5;
        }
        else
        {
            o5.GetComponent<Renderer>().material = m1;
            o5.transform.localPosition = new Vector3(-0.270000011f, -0.689999878f, 0);
        }
        if (s1.value >= 2 && s1.value < 3 && s2.value >= 1 && s2.value < 2)
        {
            o6.GetComponent<Renderer>().material = m2;
            o6.transform.localPosition = new Vector3(-5.96000004f, -0.769999564f, 3);
            flag = 6;
        }
        else
        {
            o6.GetComponent<Renderer>().material = m1;
            o6.transform.localPosition = new Vector3(-5.96000004f, -0.769999564f, 0);
        }
        if (p2.activeInHierarchy == true)
        {
            if (s3.value < 1.5)
            {
                o7.GetComponent<Renderer>().material = m2;
                o8.GetComponent<Renderer>().material = m1;
                o7.transform.localPosition = new Vector3(-3.53000045f, 2.06999993f, 3);
                o8.transform.localPosition = new Vector3(3.11000252f, 2.04999995f, 0);
                flag = 7;
            }
            else
            {
                o7.GetComponent<Renderer>().material = m1;
                o8.GetComponent<Renderer>().material = m2;
                o7.transform.localPosition = new Vector3(-3.53000045f, 2.06999993f, 0);
                o8.transform.localPosition = new Vector3(3.11000252f, 2.04999995f, 3);
                flag = 8;
            }
        }
    }
    }



