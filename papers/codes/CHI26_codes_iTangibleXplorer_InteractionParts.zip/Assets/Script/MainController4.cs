using Vuforia;
using UnityEngine;
using UnityEngine.UI;
using Image = UnityEngine.UI.Image;

public class MainController4 : MonoBehaviour
{
   // public GameObject p1;
    public GameObject cut,cut2,cut3;
    public RenderTexture renderTexture;
    public GameObject img1,img2,img3,img4,img5,img6;
    public GameObject line,line2,line3;
    public GameObject MT,volume,A,zoomer;
    VirtualButtonBehaviour[] vbs;
    int flag,f=0;
    int cnt = 0;
    //public Text t;
    private void Start()
    {
        
        vbs = GetComponentsInChildren<VirtualButtonBehaviour>();
        for (int i = 0; i < vbs.Length; i++)
        {
            vbs[i].RegisterOnButtonPressed(OnButtonPressed);
            vbs[i].RegisterOnButtonReleased(OnButtonReleased);
        }
        Debug.Log(vbs.Length);
    }
    void ChangePosition1(float tmp)
    {
        float step = 0.01f;
     //   cut.transform.localPosition = Vector3.MoveTowards(cut.transform.localPosition, new Vector3(0, 0, tmp), step);
      
    }
    /*
    public void Comfirm()
    {
        cnt++;
        int width = renderTexture.width;
        int height = renderTexture.height;
        Texture2D texture2D = new Texture2D(width, height, TextureFormat.ARGB32, false);
        RenderTexture.active = renderTexture;
        texture2D.ReadPixels(new Rect(0, 0, width, height), 0, 0);
        texture2D.Apply();
        switch (cnt)
        {
            case 1:
                img1.GetComponent<RawImage>().texture = texture2D;
                img1.SetActive(true);
                break;
            case 2:
                img2.GetComponent<RawImage>().texture = texture2D;
                img2.SetActive(true);
                break;
            case 3:
                img3.GetComponent<RawImage>().texture = texture2D;
                img3.SetActive(true);
                break;
            case 4:
                img4.GetComponent<RawImage>().texture = texture2D;
                img4.SetActive(true);
                break;
            case 5:
                img5.GetComponent<RawImage>().texture = texture2D;
                img5.SetActive(true);
                break;
            case 6:
                img6.GetComponent<RawImage>().texture = texture2D;
                img6.SetActive(true);
                break;
        }
     }*/
    private void Update()
    {
        flag =A.GetComponent<MainController1>().flag;
        
        if(flag==8)
        {
           /* if (f == 1)
            {
                ChangePosition1(0.75f);
            }
            if (f == 2)
            {
                ChangePosition1(0.9f);
            }
            if (f == 3)
            {
                ChangePosition1(1.05f);
            }
            if (f == 4)
            {
                ChangePosition1(1.20f);
            }
            if (f == 5)
            {
                ChangePosition1(1.35f);
            }
            if (f == 6)
            {
                ChangePosition1(1.5f);
            }*/
            cut.transform.localPosition=new Vector3(0, 0, -line.transform.localPosition.x * 1f + 1.125f);//new
            cut2.transform.localPosition = new Vector3(line2.transform.localPosition.z*(-1.4f)+0.52f, 0, 0);
            cut3.transform.localPosition = new Vector3(0, -line3.transform.localPosition.z* 0.7f+0.55f, 0);
            
        }
        if(flag==3)//�ԷŴ󾵽���y���ϵĿ���
            zoomer.transform.localPosition = new Vector3(line.transform.localPosition.x * 1.82f -1.4f, line2.transform.localPosition.z * 1.61f , -2.2f);
        if (flag != 8)
        {
            //cnt = 0;

            //p1.transform.localPosition = new Vector3(0, 4.30000019f, 8.03999996f);//����
            //p1.transform.localPosition = new Vector3(-0.289999992f, 6.03999996f, 55.5f);//����
           // p1.transform.localPosition = new Vector3(0, 3.8900001f, 0);//ê��
          //  img1.SetActive(false);
        //    img2.SetActive(false);
         //  img3.SetActive(false);
          //  img4.SetActive(false);
        //    img5.SetActive(false);
          //  img6.SetActive(false);
        }
      
    }
    //��ť������ʱ
    private void OnButtonPressed(VirtualButtonBehaviour vb)
    {
        //ͨ��VirtualButtonBehaviour�µ�VirtualButtonName���Լ������ᵽ��Name���Ի�ȡ��Ӧ�����ⰴť

        Debug.Log(line3.transform.position);
        Debug.Log(vb.VirtualButtonName);
            if (flag==8||flag==3)
        {
           
            if (vb.VirtualButtonName == "s1")
            {
                f = 1;
                line.transform.localPosition = new Vector3(vb.transform.localPosition.x, line.transform.localPosition.y, line.transform.localPosition.z);
            }


            if (vb.VirtualButtonName == "s2")
            {
                f = 2;

                line.transform.localPosition = new Vector3(vb.transform.localPosition.x, line.transform.localPosition.y, line.transform.localPosition.z);
            }

            if (vb.VirtualButtonName == "s3")
            {
                f = 3;
                line.transform.localPosition = new Vector3(vb.transform.localPosition.x, line.transform.localPosition.y, line.transform.localPosition.z);
               
            }

            if (vb.VirtualButtonName == "s4")
            {
                f = 4;
                line.transform.localPosition = new Vector3(vb.transform.localPosition.x, line.transform.localPosition.y, line.transform.localPosition.z);
               
            }

            if (vb.VirtualButtonName == "s5")
            {
                f = 5;
                line.transform.localPosition = new Vector3(vb.transform.localPosition.x, line.transform.localPosition.y, line.transform.localPosition.z);
               
            }

            if (vb.VirtualButtonName == "s6")
            {
                f = 6;
                line.transform.localPosition = new Vector3(vb.transform.localPosition.x, line.transform.localPosition.y, line.transform.localPosition.z);
               
            }
            if (vb.VirtualButtonName == "ss1")
            {
                f = 1;
                //volume.transform.rotation = new Quaternion(0, 0.707106829f, -0.707106829f, 0);
                line2.transform.localPosition = new Vector3(line2.transform.localPosition.x, line2.transform.localPosition.y, vb.transform.localPosition.z);
            }
            if (vb.VirtualButtonName == "ss2")
            {
                f = 2;
               // volume.transform.rotation = new Quaternion(0, 0.707106829f, -0.707106829f, 0);
                line2.transform.localPosition = new Vector3(line2.transform.localPosition.x, line2.transform.localPosition.y, vb.transform.localPosition.z);
            }
            if (vb.VirtualButtonName == "ss3")
            {
                f = 3;
              //  volume.transform.rotation = new Quaternion(0, 0.707106829f, -0.707106829f, 0);
                line2.transform.localPosition = new Vector3(line2.transform.localPosition.x, line2.transform.localPosition.y, vb.transform.localPosition.z);
            }
            if (vb.VirtualButtonName == "ss4")
            {
                f = 4;
               // volume.transform.rotation = new Quaternion(0, 0.707106829f, -0.707106829f, 0);
                line2.transform.localPosition = new Vector3(line2.transform.localPosition.x, line2.transform.localPosition.y, vb.transform.localPosition.z);
            }
            if (vb.VirtualButtonName == "ss5")
            {
                f = 5;
               // volume.transform.rotation = new Quaternion(0, 0.707106829f, -0.707106829f, 0);
                line2.transform.localPosition = new Vector3(line2.transform.localPosition.x, line2.transform.localPosition.y, vb.transform.localPosition.z);
            }
            if (vb.VirtualButtonName == "ss6")
            {
                f = 6;
               // volume.transform.rotation = new Quaternion(0, 0.707106829f, -0.707106829f, 0);
                line2.transform.localPosition = new Vector3(line2.transform.localPosition.x, line2.transform.localPosition.y, vb.transform.localPosition.z);
            }
            if (vb.VirtualButtonName == "a1")
            {
                f = 1;
               // volume.transform.rotation = new Quaternion(0, 0.707106829f, 0, 0.707106829f);
                line3.transform.localPosition = new Vector3(line3.transform.localPosition.x, line3.transform.localPosition.y, vb.transform.localPosition.z);
            }
            if (vb.VirtualButtonName == "a2")
            {
                f = 2;
                //volume.transform.rotation = new Quaternion(0, 0.707106829f, 0, 0.707106829f);
                line3.transform.localPosition = new Vector3(line3.transform.localPosition.x, line3.transform.localPosition.y, vb.transform.localPosition.z);
            }
            if (vb.VirtualButtonName == "a3")
            {
                f = 3;
                //volume.transform.rotation = new Quaternion(0, 0.707106829f, 0, 0.707106829f);
                line3.transform.localPosition = new Vector3(line3.transform.localPosition.x, line3.transform.localPosition.y, vb.transform.localPosition.z);
            }
            if (vb.VirtualButtonName == "a4")
            {
                f = 4;
                //volume.transform.rotation = new Quaternion(0, 0.707106829f, 0, 0.707106829f);
                line3.transform.localPosition = new Vector3(line3.transform.localPosition.x, line3.transform.localPosition.y, vb.transform.localPosition.z);
            }
            if (vb.VirtualButtonName == "a5")
            {
                f = 5;
               // volume.transform.rotation = new Quaternion(0, 0.707106829f, 0, 0.707106829f);
                line3.transform.localPosition = new Vector3(line3.transform.localPosition.x, line3.transform.localPosition.y, vb.transform.localPosition.z);
            }
            if (vb.VirtualButtonName == "a6")
            {
                f = 6;
               // volume.transform.rotation = new Quaternion(0, 0.707106829f, 0, 0.707106829f);
                line3.transform.localPosition = new Vector3(line3.transform.localPosition.x, line3.transform.localPosition.y,vb.transform.localPosition.z);
            }
        }

       
    }
    //��ť�ͷ�ʱ
    private void OnButtonReleased(VirtualButtonBehaviour vb)
    {


    }
}
    
    


