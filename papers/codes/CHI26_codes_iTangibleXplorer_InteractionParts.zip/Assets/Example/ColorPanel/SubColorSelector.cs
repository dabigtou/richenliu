using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class SubColorSelector : MonoBehaviour,  IPointerDownHandler, IDragHandler
{

    //显示板
    public Image ColorPlate;
    //最终颜色
    public Color FinalColor;
    //调色板
    public RawImage m_ColorPickPanel;
    //选择图标
    public RectTransform m_SelectorWheel;
    public RectTransform RectTrans;

    private RawImage m_SelectorWheelImage;
    //记录之前的位置
    Vector3 oldposition;


    void Awake()
    {
        RectTrans = transform as RectTransform;
        oldposition = m_SelectorWheel.position;
        m_SelectorWheelImage = m_SelectorWheel.GetComponent<RawImage>();
    }

    

    public void OnPointerDown(PointerEventData eventData)
    {
        OnDrag(eventData);
    }
    

    public void OnDrag(PointerEventData eventData)
    {

        //需要将背景调色板的中心点改为左下角（0，0）
        //PointerEventData.position返回的是当前指针的位置，左下角为原点（0,0），右上角（屏幕宽，屏幕高），根据分辨率来算
        Vector3 selectorWheelPos = transform.InverseTransformPoint(eventData.position);
        
        selectorWheelPos.x = Mathf.Clamp(selectorWheelPos.x,0,m_ColorPickPanel.rectTransform.rect.width - 1);
        selectorWheelPos.y = Mathf.Clamp(selectorWheelPos.y,0,m_ColorPickPanel.rectTransform.rect.height - 1);
        m_SelectorWheel.localPosition = selectorWheelPos;

        //获取调色板图片
        Texture2D tex = (Texture2D)m_ColorPickPanel.texture;
        //获取鼠标（smallIcon）在调色板上的x，y轴上的比例
        float xtemp = m_SelectorWheel.localPosition.x / m_ColorPickPanel.rectTransform.rect.width;
        float ytemp = m_SelectorWheel.localPosition.y / m_ColorPickPanel.rectTransform.rect.height;
        
        //设置圆圈颜色分类
        if (ytemp <= 0.5f || xtemp >= 0.5f) m_SelectorWheelImage.color = Color.white;
        else m_SelectorWheelImage.color = Color.black;
        
        //通过鼠标在调色板的位置比例，获取鼠标在调色板上的具体(X,Y)坐标
        int x = (int)(xtemp * tex.width);
        int y = (int)(ytemp * tex.height);

        //通过Texture2D.GetPixel这个方法来获取该位置下的像素的颜色值
        Color color = tex.GetPixel(x, y);
        //设置颜色
        FinalColor = color;
        ColorPlate.color = FinalColor;
    }

    /// <summary>
    /// 更新颜色
    /// </summary>
    /// <param name="eventData"></param>
    public void UpdateColor(PointerEventData eventData = null)
    {
        //获取调色板图片
        Texture2D tex = (Texture2D)m_ColorPickPanel.texture;
        float xtemp = m_SelectorWheel.localPosition.x / m_ColorPickPanel.rectTransform.rect.width;
        float ytemp = m_SelectorWheel.localPosition.y / m_ColorPickPanel.rectTransform.rect.height;
        int x = (int)(xtemp * tex.width);
        int y = (int)(ytemp * tex.height);
        Color color = tex.GetPixel(x, y);
        FinalColor = color;
        ColorPlate.color = FinalColor;
    }
}